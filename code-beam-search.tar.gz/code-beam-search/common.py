import re

path_sum_pic = '/home/test/sum-pic'
path_code_dir=path_sum_pic + '/code-hie'

path_parser="/home/test/eclipse/libs/stanford-parser/stanford-parser.jar"

path_corpus = path_sum_pic + '/dailymail'
path_test = path_sum_pic + '/test'
path_images=path_corpus + '/images'
path_image_features=path_corpus + '/image-features'
path_image_features_split=path_corpus + '/image-features-split'
path_stories=path_corpus+'/stories'
path_story_summaries=path_corpus+'/story-summaries'
path_story_texts=path_corpus+'/story-texts'

path_caption_summaries=path_corpus+'/caption-summaries'
path_caption_summaries_text=path_corpus+'/caption-summaries-text'

path_word_embedding=path_corpus+'/word-embeddings-tkde'
path_word_embedding_corpus=path_word_embedding+'/corpus'
path_word_embedding_billion_orign=path_sum_pic+'/billion/training'
path_word_embedding_billion=path_word_embedding+'/billion'
path_word_embedding_source_all=path_word_embedding+'/source_all'
path_word_embedding_target=path_word_embedding+'/target.bin'

path_captions=path_corpus+'/captions'
path_image_list=path_corpus+'/image-list-split'

path_caffe = path_sum_pic + '/caffe'
path_model=path_caffe + '/models/19-layer/VGG_ILSVRC_19_layers.caffemodel'
path_proto=path_caffe + '/models/19-layer/VGG_ILSVRC_19_layers_deploy.prototxt'
path_mean=path_caffe + '/python/caffe/imagenet/ilsvrc_2012_mean.npy'

path_model_dir_text=path_corpus + '/abs-sum-pic/attT'
path_model_dir_caption=path_corpus + '/abs-sum-pic/attTC'
path_model_dir_image=path_corpus + '/abs-sum-pic/attTI'
path_model_dir_image_caption=path_corpus + '/abs-sum-pic/attTIC'
path_model_dir_image_caption_2=path_corpus + '/abs-sum-pic/attTIC_2-4'

path_vocab=path_corpus+"/vocab-tkde"#'/vocab-new'
path_vocab_embedding=path_word_embedding+"/vocab_embedding_tkde"#'/vocab_embedding_new'

path_train_file=path_corpus+'/trains'
path_dev_file=path_corpus+'/devs'
path_test_file=path_corpus+'/test-tests'

bigram_award=3
search_sents_num=3
max_sent_len=50

def preprocess_line(tokenizer,line=''):
    line=line.lower()
    line=' '.join(tokenizer.tokenize(line)).replace('`','\'')
    line=re.sub(r'[^\x00-\x7F]','', line, 0)
    line=re.sub(r'([0-9]+(,[0-9]{3})*)(.[0-9]{1,2})?','NUM', line, 0)
    return line
