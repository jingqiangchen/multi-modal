
import numpy as np
import os, sys, threading, time
import matplotlib.pyplot as plt
import pylab

from multiprocessing.pool import Pool
from multiprocessing.pool import ThreadPool
from itertools import izip
from itertools import repeat

import random

import collections
import re

import common
from tensorboard import summary

from rouge import Rouge
rouge=Rouge()

def build_ext_gold_standard():
    import rouge
    import struct
    
    rouge=rouge.Rouge()
    def rouge_score(scores):
        return scores['rouge-1']['f']
    def greedy(text, ref_summary):
        lines=text.split('\n')
        summary=''
        summary_lines=[]
        summary_indice=[]
        summary_score=0
        finished=False
        while not finished:
            finished=True
            max_increment=0
            max_line=''
            max_summary_score=0
            max_i=0
            
            for i in range(len(lines)):
                line=lines[i]
                if line=='':
                    continue
                tmp_summary=summary+line
                tmp_summary_score=rouge_score(rouge.get_scores(tmp_summary,ref_summary)[0])
                if max_increment<tmp_summary_score-summary_score:
                    max_increment=tmp_summary_score-summary_score
                    max_line=line
                    max_summary_score=tmp_summary_score
                    max_i=i
                    finished=False
                    
            if not finished:
                summary+=max_line
                summary_lines.append(max_line)
                summary_indice.append(max_i)
                summary_score=max_summary_score
                lines[max_i]=''

        return summary, summary_lines, summary_score, summary_indice
    
    def Mapper(t):
        file_name,n=t
        with open(common.path_story_summaries+'-bak/'+file_name) as file:
            abs_summary=file.read().replace('\n','. ')
        with open(common.path_story_texts+'/'+file_name) as file:
            text=file.read().strip('\n')
        summary, summary_lines, summary_score, summary_indice=greedy(text,abs_summary)
        
        lines=text.split('\n')
        labels=[]
        with open(common.path_stroy_summaries_ext+'/'+file_name,'w') as wfile:
            wfile.write('\n'.join(summary_lines))
        with open(common.path_stroy_summaries_label+'/'+file_name,'wb') as wfile:
            for i in range(len(lines)):
                labels.append(0)
            for item in summary_indice:
                labels[item]=1
            for label in labels:
                wfile.write(struct.pack('f',label))
                
        #print(text)
        print(n, file_name,'-----------------------------%s----------------------------' % file_name, summary_indice)
                                
        #print()
        return True
    
    def Build(request_parallelism=10):
        abs_summaries=os.listdir(common.path_story_summaries+'-bak')
        exist_summaries=os.listdir(common.path_stroy_summaries_ext)
        abs_summaries=[file_name for file_name in abs_summaries if file_name not in exist_summaries]
        print(len(abs_summaries))
        p = ThreadPool(request_parallelism)
        results = p.imap_unordered(Mapper, izip(abs_summaries, range(len(abs_summaries))))
        i=0
        try:
            for ok in results:
                i=i+1
        except KeyboardInterrupt:
            print 'Interrupted by user'
                    
    Build()

def build_gold_image_summary():
    import rouge
    import struct
    rouge=rouge.Rouge()
    
    def rouge_score(scores):
        return scores['rouge-1']['f']
    
    def greedy(lines, ref_summary):
        summary=''
        summary_lines=[]
        summary_indice=[]
        summary_score=0
        finished=False
        while not finished:
            finished=True
            max_increment=0
            max_line=''
            max_summary_score=0
            max_i=0
            
            for i in range(len(lines)):
                line=lines[i]
                if line=='':
                    continue
                tmp_summary=summary+line
                tmp_summary_score=rouge_score(rouge.get_scores(tmp_summary,ref_summary)[0])
                if max_increment<tmp_summary_score-summary_score:
                    max_increment=tmp_summary_score-summary_score
                    max_line=line
                    max_summary_score=tmp_summary_score
                    max_i=i
                    finished=False
                    
            if not finished:
                summary+=max_line
                summary_lines.append(max_line)
                summary_indice.append(max_i)
                summary_score=max_summary_score
                lines[max_i]=''

        return summary, summary_lines, summary_score, summary_indice
    
    def Mapper(t):
        file_name, n = t
        with open(common.path_story_summaries+"/"+file_name) as file_summary:
            ref_summary=file_summary.read()
            ref_summary=ref_summary.replace("\n","")
                
        captions=[]
        with open(common.path_captions+"/"+file_name) as file_caption: 
            for line in file_caption.readlines():
                line=line.strip("\n")
                captions.append(line)
                
        summary, summary_lines, summary_score, summary_indice=greedy(captions,ref_summary)
        
        labels=[]
        if not os.path.exists(common.path_caption_summaries):
            os.mkdir(common.path_caption_summaries)
        with open(common.path_caption_summaries+'/'+file_name,'w') as wfile:
            wfile.write(' '.join([str(index) for index in summary_indice]))
                
        #print(text)
        print(n, file_name,'-----------------------------%s----------------------------' % file_name, summary_indice)

        return True
    
    def Build(request_parallelism=10):
        file_names=[]
        with open(common.path_test_file) as test_file:
            for file_name in test_file.readlines():
                file_name=file_name.strip("\n")
                file_names.append(file_name)
                
        print(len(file_names))
        p = ThreadPool(request_parallelism)
        results = p.imap_unordered(Mapper, izip(file_names, range(len(file_names))))
        i=0
        try:
            for ok in results:
                i=i+1
        except KeyboardInterrupt:
            print 'Interrupted by user'  
    
    def Merge():
        wfile = open(common.path_caption_summaries+"-cover","w")
        with open(common.path_test_file) as test_file:
            for file_name in test_file.readlines():
                file_name=file_name.strip("\n")
                with open(common.path_caption_summaries+"/"+file_name) as caption_summary_file:
                    text = caption_summary_file.read()
                    #text = text.strip("\n")
                    wfile.write(text+"\n")
        wfile.close()            
    
    #Build()      
    Merge()

def process(dt_file_dir, dt_file_name):
    wfile=open(dt_file_dir+"/"+dt_file_name+"-summary","w")
    with open(dt_file_dir+"/"+dt_file_name) as dt_file:
        tmp_lines=[]
        for line in dt_file.readlines():
            line=line.strip('\n')
            ma=re.match("^\[?(\d+)\]?$",line)
            
            if ma:
                record_no=ma.group(0)
                lines_image_scores=[]
                lines_caption_scores=[]
                lines_text_scores=[]
                lines_unk=[]
                lines_rep=[]
                lines_target=[]
                lines_full_unk=[]
                lines_75_unk=[]
                lines_full_rep=[]
                lines_75_rep=[]
            elif line=="-------------------image_scores---------------------":
                tmp_lines=lines_image_scores
            elif line=="-------------------caption_scores---------------------":
                tmp_lines=lines_caption_scores
            elif line=="-------------------text_scores---------------------":
                tmp_lines=lines_text_scores
            elif line=="------------------unk---summary----------------":
                tmp_lines=lines_unk
            elif line=="------------------rep---summary----------------":
                tmp_lines=lines_rep
            elif line=="------------------target---summary----------------":
                tmp_lines=lines_target
            elif line=="-------------------full---unk---------------":
                tmp_lines=lines_full_unk
            elif line=="-------------------75---unk---------------":
                tmp_lines=lines_75_unk
            elif line=="-------------------full---rep---------------":
                tmp_lines=lines_full_rep
            elif line=="-------------------75---rep---------------":
                tmp_lines=lines_75_rep
            elif line=="-------------------------------------":
                image_num=0
                #print(lines_image_scores)
                if len(lines_image_scores)>0:
                    image_num = len(lines_image_scores[0].split(" "))
                
                image_scores=np.zeros([image_num])
                select_image_num=0
                for i in range(len(lines_rep)):
                    if lines_rep[i].strip(" ")=="":
                        continue
                    select_image_num+=1
                    line_image_scores = lines_image_scores[i]
                    tmp_image_scores = line_image_scores.split(" ")
                    tmp_image_scores = [float(score) for score in tmp_image_scores]
                    image_scores=image_scores+np.array(tmp_image_scores)
                    
                    line_caption_scores = lines_caption_scores[i]
                    tmp_caption_scores = line_caption_scores.split(" ")
                    tmp_caption_scores = [float(score) for score in tmp_caption_scores]
                    image_scores=image_scores+np.array(tmp_caption_scores)
                    
                ix, = np.unravel_index(image_scores.argsort(axis=0), dims=image_scores.shape)
                ix = ix[::-1]
                #print("image-scores:",image_scores)
                #print("order",ix)
                #print("reverse",ix[::-1],)
                wfile.write("%d " % select_image_num)
                wfile.write(" ".join([str(item) for item in ix]))
                wfile.write("\n")
                    
            else:
                tmp_lines.append(line)
    
    wfile.close()
    
def compare(ref_file_path, summary_file_path, summary_len=1, fixed=True):
    ref_file = open(ref_file_path)
    summary_file = open(summary_file_path)
    
    ref_lines = ref_file.read()
    ref_lines = ref_lines.strip("\n")
    ref_lines = ref_lines.split("\n")
    summary_lines = summary_file.read()
    summary_lines = summary_lines.strip("\n")
    summary_lines = summary_lines.split("\n")
    
    ps=0.
    rs=0.
    fs=0.
    ref_line_num = len(ref_lines)
    for i in range(ref_line_num):
        ref = ref_lines[i]
        ref = ref.strip("\n")
        ref = ref.split(" ")
        ref_len = len(ref)
        if ref_len == 0:
            ref_line_num-=1
            continue

        summary = summary_lines[i]
        summary = summary.strip("\n")
        summary = summary.split(" ")
        
        summary = summary[1:1+summary_len]
        
        count=0.
        for ref_1 in ref:
            if ref_1 in summary:
                count+=1
        p=count/int(summary_len)
        #print(count, summary_len)
        r=count/ref_len
        #print(p)
        if p+r == 0:
            continue
        f=p*r*2/(p+r)
        ps+=p
        rs+=r
        fs+=f
    print(ps/ref_line_num, rs/ref_line_num, fs/ref_line_num)
    
    ref_file.close()
    summary_file.close()
    
def build_order_image_summary(ref_file_path):
    ref_file = open(ref_file_path)
    summary_file = open(ref_file_path+"-order", "w")
    
    ref_lines = ref_file.read()
    ref_lines = ref_lines.split("\n")
    for ref_line in ref_lines:
        ref_line_len = len(ref_line)
        order = range(10)
        order = " ".join([str(item) for item in order])
        summary_file.write("%d " % ref_line_len)
        summary_file.write(order)
        summary_file.write("\n")
    
    ref_file.close()
    summary_file.close()
    
def build_random_image_summary(ref_file_path):
    test_file = open(common.path_test_file)
    summary_file = open(ref_file_path+"-random", "w")
    
    for file_name in test_file.readlines():
        file_name=file_name.strip("\n")
        caption_file=open(common.path_captions+"/"+file_name)
        captions=caption_file.read()
        captions=captions.strip("\n")
        captions=captions.split("\n")
        ref_line_len = len(captions)
        order = range(ref_line_len)
        random.shuffle(order)
        random.shuffle(order)
        random.shuffle(order)
        order = " ".join([str(item) for item in order])
        summary_file.write("%d " % ref_line_len)
        summary_file.write(order)
        summary_file.write("\n")

        caption_file.close()
        
    test_file.close()
    summary_file.close()
    
def count_avg_corpus_img():
    test_file = open(common.path_test_file)
    total_img=0.
    file_count=0.
    for line in test_file.readlines():
        line=line.strip("\n")
        caption_file=open(common.path_captions+"/"+line)
        captions=caption_file.read()
        captions=captions.strip("\n")
        if captions!="":
            captions=captions.split("\n")
            total_img+=len(captions)
        file_count+=1
        caption_file.close()
    test_file.close()
    avg_img=total_img/file_count
    print(avg_img)
    
def count_avg_summary_img():
    test_file = open(common.path_caption_summaries+"-cover")
    total_img=0.
    file_count=0.
    for line in test_file.readlines():
        line=line.strip("\n").strip(" ")
        if line!="":
            line=line.split(" ")
            total_img+=len(line)
        file_count+=1
    test_file.close()
    avg_img=total_img/file_count
    print(avg_img)
    
def merge_rouge_files(file_path1,file_path2,file_path3):
    wfile=open(file_path3,"w")
    tmp_lines=[]
    with open(file_path1) as dt_file:
        for line in dt_file.readlines():
            line=line.strip('\n')
            ma=re.match("^\[(\d+)\]$",line)
            
            wfile.write(line)
            wfile.write("\n")
            
            if ma:
                record_no=int(ma.group(1))
                lines_full_unk=[]
                lines_75_unk=[]
                lines_full_rep=[]
                lines_75_rep=[]
            elif line=="-------------------full---unk---------------":
                tmp_lines=lines_full_unk
            elif line=="-------------------75---unk---------------":
                tmp_lines=lines_75_unk
            elif line=="-------------------full---rep---------------":
                tmp_lines=lines_full_rep
            elif line=="-------------------75---rep---------------":
                tmp_lines=lines_75_rep
            elif line=="-------------------------------------":
                rouge_full_unk=[]
                for line in lines_full_unk:
                    line=line.split(" ")
                    tmp=[float(item)*record_no for item in line]
                    rouge_full_unk.append(tmp)
                    
                rouge_75_unk=[]
                for line in lines_75_unk:
                    line=line.split(" ")
                    tmp=[float(item)*record_no for item in line]
                    rouge_75_unk.append(tmp)
                    
                rouge_full_rep=[]
                for line in lines_full_rep:
                    line=line.split(" ")
                    tmp=[float(item)*record_no for item in line]
                    rouge_full_rep.append(tmp)
                    
                rouge_75_rep=[]
                for line in lines_75_rep:
                    line=line.split(" ")
                    tmp=[float(item)*record_no for item in line]
                    rouge_75_rep.append(tmp)
            else:
                tmp_lines.append(line)
                
    with open(file_path2) as dt_file:
        for line in dt_file.readlines():
            line=line.strip('\n')
            ma=re.match("^\[?(\d+)\]?$",line)
            
            if ma:
                record_no2=int(ma.group(1))
                lines_full_unk=[]
                lines_75_unk=[]
                lines_full_rep=[]
                lines_75_rep=[]
                line="["+str(record_no+record_no2)+"]"
            elif line=="-------------------full---unk---------------":
                tmp_lines=lines_full_unk
            elif line=="-------------------75---unk---------------":
                tmp_lines=lines_75_unk
            elif line=="-------------------full---rep---------------":
                tmp_lines=lines_full_rep
            elif line=="-------------------75---rep---------------":
                tmp_lines=lines_75_rep
            else:
                tmp_lines.append(line)
                if tmp_lines==lines_full_unk:
                    line=line.split(" ")
                    items=rouge_full_unk[len(tmp_lines)-1]
                    tmp=[str((float(item)*record_no2+item2)/(record_no+record_no2)) for item,item2 in zip(line,items)]
                    line=" ".join(tmp)
                if tmp_lines==lines_75_unk:    
                    line=line.split(" ")
                    items=rouge_75_unk[len(tmp_lines)-1]
                    tmp=[str((float(item)*record_no2+item2)/(record_no+record_no2)) for item,item2 in zip(line,items)]
                    line=" ".join(tmp)
                if tmp_lines==lines_full_rep:
                    line=line.split(" ")
                    items=rouge_full_rep[len(tmp_lines)-1]
                    tmp=[str((float(item)*record_no2+item2)/(record_no+record_no2)) for item,item2 in zip(line,items)]
                    line=" ".join(tmp)
                if tmp_lines==lines_75_rep:    
                    line=line.split(" ")
                    items=rouge_75_rep[len(tmp_lines)-1]
                    tmp=[str((float(item)*record_no2+item2)/(record_no+record_no2)) for item,item2 in zip(line,items)]
                    line=" ".join(tmp)
                    if len(tmp_lines)==3:
                        tmp_lines=[]
            
            wfile.write(line)
            wfile.write("\n")
            
    wfile.close()
    
def caption_summary():
    file_names=os.listdir(common.path_caption_summaries)
    for file_name in file_names:
        with open(common.path_caption_summaries+"/"+file_name) as file:
            indices=file.read()
            indices=indices.strip("\n").strip(" ")
            if indices != "":
                indices=indices.split(" ")
                indices=[int(index) for index in indices]
            
        with open(common.path_captions+"/"+file_name) as file:
            captions=file.readlines()
        
        with open(common.path_caption_summaries_text+"/"+file_name, "w") as wfile:
            for index in indices:
                wfile.write(captions[index])

def caption_summary_rouge():
    with open(common.path_test_file) as file:
        file_names=file.readlines()
        file_names=[file_name.strip("\n") for file_name in file_names]
        
    rouge_1=0
    rouge_2=0
    rouge_l=0
    count=0
    for file_name in file_names:
        with open(common.path_caption_summaries_text+"/"+file_name) as file:
            lines=file.readlines()
            summary=[line.strip("\n").strip(" ") for line in lines]
            summary=" ".join(summary)

        with open(common.path_story_summaries+"/"+file_name) as file:
            lines=file.readlines()
            target=[line.strip("\n").strip(" ") for line in lines]
            target=" ".join(target)
        
        if summary!="" and target!="":
            scores = rouge.get_scores([summary], [target])
            rouge_1+=scores[0]["rouge-1"]["f"]
            rouge_2+=scores[0]["rouge-2"]["f"]
            rouge_l+=scores[0]["rouge-l"]["f"]
        count+=1
    
    print(rouge_1/count, rouge_2/count, rouge_l/count)

def main():
    ref_file_path = common.path_caption_summaries+"-cover"
    summary_len=1
    
    def process_test(s):
        process("/home/test/sum-pic/dailymail/abs-sum-pic/image-attention-hie512-256-DOCNOTEND-4/pred", "test-full-%s-pellet-img" % s)
        #process("/home/test/sum-pic/dailymail/abs-sum-pic/image-attention-hie512-256-DOCNOTEND-4/pred", "test-full-%s-img" % s)
        #process("/home/test/sum-pic/dailymail/abs-sum-pic/image-attention-hie512-256-DOCNOTEND-4/pred", "test-full-%s-img-test" %s)
        #process("/home/test/sum-pic/dailymail/abs-sum-pic/caption-attention-hie512-256-DOCNOTEND-4/pred", "test-full-%s-img" % s)
        #process("/home/test/sum-pic/dailymail/abs-sum-pic/image-caption-attention-hie512-256-DOCNOTEND-4/pred", "test-full-%s-img" % s)
        
    def compare_test(s):
        compare(ref_file_path,ref_file_path+"-random", summary_len=summary_len)
        #compare(ref_file_path,"/home/test/sum-pic/dailymail/abs-sum-pic/image-attention-hie512-256-DOCNOTEND-4/pred/test-full-%s-img-test-summary" % s, summary_len=summary_len, fixed=True)
        #compare(ref_file_path,"/home/test/sum-pic/dailymail/abs-sum-pic/image-attention-hie512-256-DOCNOTEND-4/pred/test-full-%s-img-summary" % s, summary_len=summary_len, fixed=True)
        #compare(ref_file_path,"/home/test/sum-pic/dailymail/abs-sum-pic/caption-attention-hie512-256-DOCNOTEND-4/pred/test-full-%s-img-summary" % s, summary_len=summary_len, fixed=True)
        compare(ref_file_path,"/home/test/sum-pic/dailymail/abs-sum-pic/image-caption-attention-hie512-256-DOCNOTEND-4/pred/test-full-%s-img-summary" % s, summary_len=summary_len, fixed=True)
        
    #process_test("nobigram")
    process_test("5")
    
    #compare_test("10")
    #compare_test("3")
    #build_gold_image_summary()
    #process("/home/test/sum-pic/dailymail/abs-sum-pic/image-attention-hie512-256-DOCNOTEND-4/pred", "test-full-3-img-test")
    #
    #build_order_image_summary(ref_file_path)
    #build_random_image_summary(ref_file_path)
    
    #compare(ref_file_path,"/home/test/sum-pic/dailymail/abs-sum-pic/image-caption-attention-hie512-256-DOCNOTEND-4/pred/test-full-3-img-summary", summary_len=summary_len, fixed=True)
    #count_avg_corpus_img()
    #count_avg_summary_img()
    '''merge_rouge_files("/home/test/sum-pic/dailymail/abs-sum-pic/image-attention-hie512-256-DOCNOTEND-4/pred/test-full-3-img",
                      "/home/test/sum-pic/dailymail/abs-sum-pic/image-attention-hie512-256-DOCNOTEND-4/pred/test-full-3-img-5804",
                      "/home/test/sum-pic/dailymail/abs-sum-pic/image-attention-hie512-256-DOCNOTEND-4/pred/test-full-3-img-all")'''
    '''merge_rouge_files("/home/test/sum-pic/dailymail/abs-sum-pic/text-attention-hie512-256-DOCNOTEND-4/pred/test-full-3-img",
                      "/home/test/sum-pic/dailymail/abs-sum-pic/text-attention-hie512-256-DOCNOTEND-4/pred/test-full-3-img-5072",
                      "/home/test/sum-pic/dailymail/abs-sum-pic/text-attention-hie512-256-DOCNOTEND-4/pred/test-full-3-img-all")'''


def cal_rouge(in_file_path):
    #in_file_path=common.path_model_dir_image+"/pred/test-full-10-img"
    #wfile=open(in_file_path,"w")
    def pp(text, l=275):
        tmp=[]
        length=0
        for ch in text:
            if length>l: 
                break
            if ch!=' ':
                length+=1
            tmp.append(ch)
        return ''.join(tmp)
    
    tmp_lines=[]
    sign=0
    score_1=[0.,0.,0.]
    score_2=[0.,0.,0.]
    score_l=[0.,0.,0.]
    count=0.
    with open(in_file_path) as dt_file:
        for line in dt_file.readlines():
            line=line.strip('\n')
            ma=re.match("^\[(\d+)\]$",line)
            
            if ma:
                record_no=int(ma.group(1))
                summary=[]
                target=[]
            elif line=="------------------rep---summary----------------":
                sign=1
                tmp_lines=summary
            elif line=="------------------target---summary----------------":
                sign=1
                tmp_lines=target
            elif line=="-------------------full---unk---------------":
                sign=0
                text_summary=" ".join(summary)
                text_target=" ".join(target)
                scores = rouge.get_scores([text_summary], [text_target])
                score_1[0]+=float(scores[0]['rouge-1']['r'])
                score_1[1]+=float(scores[0]['rouge-1']['p'])
                score_1[2]+=float(scores[0]['rouge-1']['f'])
                
                score_2[0]+=float(scores[0]['rouge-2']['r'])
                score_2[1]+=float(scores[0]['rouge-2']['p'])
                score_2[2]+=float(scores[0]['rouge-2']['f'])
                
                score_l[0]+=float(scores[0]['rouge-l']['r'])
                score_l[1]+=float(scores[0]['rouge-l']['p'])
                score_l[2]+=float(scores[0]['rouge-l']['f'])
                
                count+=1.
            elif sign==1:
                #print(line)
                tmp_lines.append(line)
    
    print(count)
    print()
    print(score_1[0]/count, score_1[1]/count, score_1[2]/count)
    print()
    print(score_2[0]/count, score_2[1]/count, score_2[2]/count)
    print()
    print(score_l[0]/count, score_l[1]/count, score_l[2]/count)

def test():

    ''''a=np.array([4,1,3,7])
    ix, = np.unravel_index(a.argsort(axis=0), dims=a.shape)
    ix = ix[::-1]
    print(" ".join([str(item) for item in ix]))'''
    #s="5 7 8 1 9 15 11 12 10 16 2 4 14 6 13 3 0 5"
    #print(s.split(" "))
    ''''a=[1,2,3,4]
    random.shuffle(a)
    print(a)'''
    print((0.239846455603*5803+0.220567916107*4594)/10397)
    print((0.239846455603*5803+0.220567916107*4594)/10397)
    print((0.258974532134*5803+0.235219454331*4594)/10397)
    

if __name__=='__main__':
    #main()
    #test()
    #caption_summary()
    #caption_summary_rouge()
    cal_rouge(common.path_model_dir_caption+"/pred/test-full-10-img")
    

    
    








