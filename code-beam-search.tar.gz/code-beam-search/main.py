# -*- coding: utf-8 -*-

import os
import common
import argparse
import re

def get_last_num(filename):
        f = open(filename)
        f.seek(0, 2)
        last_position = f.tell()
        #print(last_position)
        while True:
            line = f.readline()
            current_position = f.tell()
            #print(current_position)
            i = 1
            while current_position == last_position:
                if len(line) == current_position:
                    #print line
                    return
                i += 0.5
                f.seek(max(int(-72 * i), -current_position), 1)
                line = f.readline()
                current_position = f.tell()
    
            while current_position != last_position:
                line = f.readline()
                current_position = f.tell()
                #print(line)
            mo=re.match("(\d)*\n", line)
            if mo:
                return int(mo.group(0))
            else:
                return 0
                
            #print line
            last_position = last_position - len(line)
            f.seek(max(-72, -last_position) - len(line), 1)

def train_text(batch_size=4, gpu=None):
    if gpu is None:
        gpu = 0
        
    VOCAB_SOURCE=common.path_vocab
    VOCAB_TARGET=common.path_vocab
    TRAIN_SOURCES=common.path_train_file
    TRAIN_TARGETS=common.path_train_file
    DEV_SOURCES=common.path_dev_file
    DEV_TARGETS=common.path_dev_file
    MODEL_DIR=common.path_model_dir_text
    
    MODEL_CONFIG=common.path_code_dir+'/configs/abs_sum_pic_hie.yml,'\
                + common.path_code_dir+'/configs/train_seq2seq.yml,'\
                + common.path_code_dir+'/configs/text_metrics_bpe.yml'
    #--train_steps $TRAIN_STEPS \ 
    os.system('''
        export CUDA_VISIBLE_DEVICES=%d
        
        export VOCAB_SOURCE=%s
        export VOCAB_TARGET=%s
        export TRAIN_SOURCES=%s
        export TRAIN_TARGETS=%s
        export DEV_SOURCES=%s
        export DEV_TARGETS=%s
        export TRAIN_STEPS=1000
        export MODEL_DIR=%s
        export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
        
        mkdir -p $MODEL_DIR
            
        python -m bin.train \
              --config_paths="%s" \
              --model_params "
                  vocab_source: $VOCAB_SOURCE 
                  vocab_target: $VOCAB_TARGET" \
              --input_pipeline_train " 
                class: ParallelTextInputPipeline_Text 
                params: 
                  source_files: 
                    - $TRAIN_SOURCES 
                  target_files: 
                    - $TRAIN_TARGETS" \
              --input_pipeline_dev "
                class: ParallelTextInputPipeline_Text 
                params:
                   source_files: 
                    - $DEV_SOURCES 
                   target_files: 
                    - $DEV_TARGETS" \
              --batch_size %d \
              --eval_every_n_steps 5000 \
              --output_dir $MODEL_DIR
    ''' % (gpu, VOCAB_SOURCE, VOCAB_TARGET, TRAIN_SOURCES,TRAIN_TARGETS,DEV_SOURCES,DEV_TARGETS,MODEL_DIR,MODEL_CONFIG,batch_size))

def train_image(batch_size=3, gpu=1):
    
    if gpu is None:
        gpu=1
        
    VOCAB_SOURCE=common.path_vocab
    VOCAB_TARGET=common.path_vocab
    TRAIN_SOURCES=common.path_train_file#common.path_story_texts+'/*'
    TRAIN_TARGETS=common.path_train_file#common.path_story_summaries+'/*'
    TRAIN_IMAGES=common.path_train_file#common.path_image_features+'/*'
    DEV_SOURCES=common.path_dev_file#common.path_story_texts+'/*'
    DEV_TARGETS=common.path_dev_file#common.path_story_summaries+'/*'
    DEV_IMAGES=common.path_dev_file#common.path_image_features+'/*'
    MOFRL_DIR=common.path_model_dir_image 
    
    MODEL_CONFIG=common.path_code_dir+'/configs/abs_sum_pic_image_hie.yml,'\
                + common.path_code_dir+'/configs/train_seq2seq.yml,'\
                + common.path_code_dir+'/configs/text_metrics_bpe.yml'
    #--train_steps $TRAIN_STEPS \ 
    os.system('''
        export CUDA_VISIBLE_DEVICES=%d
        
        export VOCAB_SOURCE=%s
        export VOCAB_TARGET=%s
        export TRAIN_SOURCES=%s
        export TRAIN_TARGETS=%s
        export TRAIN_IMAGES=%s
        export DEV_SOURCES=%s
        export DEV_TARGETS=%s
        export DEV_IMAGES=%s
        export TRAIN_STEPS=1000
        export MODEL_DIR=%s
        
        mkdir -p $MODEL_DIR
            
        python -m bin.train \
              --config_paths="%s" \
              --model_params "
                  vocab_source: $VOCAB_SOURCE 
                  vocab_target: $VOCAB_TARGET" \
              --input_pipeline_train " 
                class: ParallelTextInputPipeline_Image_Caption 
                params: 
                  source_files: 
                    - $TRAIN_SOURCES 
                  target_files: 
                    - $TRAIN_TARGETS
                  image_files:
                    - $TRAIN_IMAGES" \
              --input_pipeline_dev "
                class: ParallelTextInputPipeline_Image_Caption 
                params:
                   source_files: 
                    - $DEV_SOURCES 
                   target_files: 
                    - $DEV_TARGETS
                   image_files:
                    - $DEV_IMAGES" \
              --batch_size %d \
              --eval_every_n_steps 10000 \
              --output_dir $MODEL_DIR
    ''' % (gpu, VOCAB_SOURCE, VOCAB_TARGET, TRAIN_SOURCES,TRAIN_TARGETS,TRAIN_IMAGES,
           DEV_SOURCES,DEV_TARGETS,DEV_IMAGES,MOFRL_DIR,MODEL_CONFIG,batch_size))

def train_caption(batch_size=4, gpu=0):
    
    if gpu is None:
        gpu=0
        
    VOCAB_SOURCE=common.path_vocab
    VOCAB_TARGET=common.path_vocab
    TRAIN_SOURCES=common.path_train_file
    TRAIN_TARGETS=common.path_train_file
    TRAIN_CAPTIONS=common.path_train_file
    DEV_SOURCES=common.path_dev_file
    DEV_TARGETS=common.path_dev_file
    DEV_CAPTIONS=common.path_dev_file
    MOFRL_DIR=common.path_model_dir_caption 
    
    MODEL_CONFIG=common.path_code_dir+'/configs/abs_sum_pic_caption_hie.yml,'\
                + common.path_code_dir+'/configs/train_seq2seq.yml,'\
                + common.path_code_dir+'/configs/text_metrics_bpe.yml'
    #--train_steps $TRAIN_STEPS \ 
    os.system('''
        export CUDA_VISIBLE_DEVICES=%d
        
        export VOCAB_SOURCE=%s
        export VOCAB_TARGET=%s
        export TRAIN_SOURCES=%s
        export TRAIN_TARGETS=%s
        export TRAIN_CAPTIONS=%s
        export DEV_SOURCES=%s
        export DEV_TARGETS=%s
        export DEV_CAPTIONS=%s
        export TRAIN_STEPS=1000
        export MODEL_DIR=%s
        
        mkdir -p $MODEL_DIR
            
        python -m bin.train \
              --config_paths="%s" \
              --model_params "
                  vocab_source: $VOCAB_SOURCE 
                  vocab_target: $VOCAB_TARGET" \
              --input_pipeline_train " 
                class: ParallelTextInputPipeline_Image_Caption 
                params: 
                  source_files: 
                    - $TRAIN_SOURCES 
                  target_files: 
                    - $TRAIN_TARGETS
                  caption_files:
                    - $TRAIN_CAPTIONS" \
              --input_pipeline_dev "
                class: ParallelTextInputPipeline_Image_Caption 
                params:
                   source_files: 
                    - $DEV_SOURCES 
                   target_files: 
                    - $DEV_TARGETS
                   caption_files:
                    - $DEV_CAPTIONS" \
              --batch_size %d \
              --eval_every_n_steps 5000 \
              --output_dir $MODEL_DIR
    ''' % (gpu, VOCAB_SOURCE, VOCAB_TARGET, TRAIN_SOURCES,TRAIN_TARGETS,TRAIN_CAPTIONS,
           DEV_SOURCES,DEV_TARGETS,DEV_CAPTIONS,MOFRL_DIR,MODEL_CONFIG,batch_size))
  
def train_image_caption(batch_size=3, gpu=0):
        
    if gpu is None:
        gpu=0
        
    VOCAB_SOURCE=common.path_vocab
    VOCAB_TARGET=common.path_vocab
    TRAIN_SOURCES=common.path_train_file
    TRAIN_TARGETS=common.path_train_file
    TRAIN_CAPTIONS=common.path_train_file
    TRAIN_IMAGES=common.path_train_file
    DEV_SOURCES=common.path_dev_file
    DEV_TARGETS=common.path_dev_file
    DEV_CAPTIONS=common.path_dev_file
    DEV_IMAGES=common.path_dev_file
    MOFRL_DIR=common.path_model_dir_image_caption 
    
    MODEL_CONFIG=common.path_code_dir+'/configs/abs_sum_pic_image_caption_hie.yml,'\
                + common.path_code_dir+'/configs/train_seq2seq.yml,'\
                + common.path_code_dir+'/configs/text_metrics_bpe.yml'
    #--train_steps $TRAIN_STEPS \ 
    #export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
    os.system('''
        export CUDA_VISIBLE_DEVICES=%d
        
        export VOCAB_SOURCE=%s
        export VOCAB_TARGET=%s
        export TRAIN_SOURCES=%s
        export TRAIN_TARGETS=%s
        export TRAIN_CAPTIONS=%s
        export TRAIN_IMAGES=%s
        export DEV_SOURCES=%s
        export DEV_TARGETS=%s
        export DEV_CAPTIONS=%s
        export DEV_IMAGES=%s
        export TRAIN_STEPS=1000
        export MODEL_DIR=%s
        
        
        mkdir -p $MODEL_DIR
            
        python -m bin.train \
              --config_paths="%s" \
              --model_params "
                  vocab_source: $VOCAB_SOURCE 
                  vocab_target: $VOCAB_TARGET" \
              --input_pipeline_train " 
                class: ParallelTextInputPipeline_Image_Caption 
                params: 
                  source_files: 
                    - $TRAIN_SOURCES 
                  target_files: 
                    - $TRAIN_TARGETS
                  caption_files:
                    - $TRAIN_CAPTIONS
                  image_files:
                    - $TRAIN_IMAGES " \
              --input_pipeline_dev "
                class: ParallelTextInputPipeline_Image_Caption 
                params:
                   source_files: 
                    - $DEV_SOURCES 
                   target_files: 
                    - $DEV_TARGETS
                   caption_files:
                    - $DEV_CAPTIONS
                   image_files:
                    - $DEV_IMAGES" \
              --batch_size %d \
              --eval_every_n_steps 10000 \
              --output_dir $MODEL_DIR
    ''' % (gpu, VOCAB_SOURCE, VOCAB_TARGET, TRAIN_SOURCES,TRAIN_TARGETS,TRAIN_CAPTIONS,TRAIN_IMAGES,
           DEV_SOURCES,DEV_TARGETS,DEV_CAPTIONS,DEV_IMAGES,MOFRL_DIR,MODEL_CONFIG,batch_size))

    
def beam_search(mode, gpu=1, prediction=None):
    if mode=="image":
        MOFRL_DIR=common.path_model_dir_image
    elif mode=="caption":
        MOFRL_DIR=common.path_model_dir_caption
    elif mode=="image-caption":
        MOFRL_DIR=common.path_model_dir_image_caption 
    elif mode=="text":
        MOFRL_DIR=common.path_model_dir_text 
        
    if prediction is None:
        prediction = 'predictions-beam-search.txt'
        
    TEST_SOURCES=common.path_test_file
    
    if gpu is None:
        gpu=0
    
    os.system('''
        export CUDA_VISIBLE_DEVICES=%d
        
        export MODEL_DIR=%s
        export TEST_SOURCES=%s
        export PRED_DIR=$MODEL_DIR/pred
        mkdir -p ${PRED_DIR}
        
        python -m bin.infer \
          --tasks "
            - class: DecodeText
            - class: DumpBeams
              params:
                file: ${PRED_DIR}/beams.npz" \
          --model_dir $MODEL_DIR \
          --model_params "
            inference.beam_search.beam_width: 5" \
          --input_pipeline "
            class: ParallelTextInputPipeline_Image_Caption
            params:
              source_files:
                - $TEST_SOURCES
              target_files: 
                - $TEST_SOURCES
              image_files:
                - $TEST_SOURCES
              caption_files:
                - $TEST_SOURCES" \
          > ${PRED_DIR}/%s
        ''' % (gpu, MOFRL_DIR, TEST_SOURCES, prediction))
    
def beam_search_2(mode, gpu=1 , prediction=None, bigram_award=3, search_sents_num=3, max_sent_len=50):
    if mode=="image":
        MOFRL_DIR=common.path_model_dir_image
    elif mode=="caption":
        MOFRL_DIR=common.path_model_dir_caption
    elif mode=="image-caption":
        MOFRL_DIR=common.path_model_dir_image_caption 
    elif mode=="image-caption-2":
        MOFRL_DIR=common.path_model_dir_image_caption_2  
    elif mode=="text":
        MOFRL_DIR=common.path_model_dir_text 
        
    if mode=="text":
        decode_text="DecodeText_2_Text"
    else:
        decode_text="DecodeText_2"
    
    if prediction is None:
        prediction = 'predictions-beam-search.txt'
    
    if os.path.exists(MOFRL_DIR+"/pred/"+prediction):
        file=open(MOFRL_DIR+"/pred/"+prediction)
    
    common.bigram_award=bigram_award, 
    common.search_sents_num=search_sents_num, 
    common.max_sent_len=max_sent_len
    
    TEST_SOURCES=common.path_test_file
    
    if gpu is None:
        gpu=0
    
    os.system('''
        export CUDA_VISIBLE_DEVICES=%d
        
        export MODEL_DIR=%s
        export TEST_SOURCES=%s
        export PRED_DIR=$MODEL_DIR/pred
        mkdir -p ${PRED_DIR}
        
        python -m bin.infer \
          --tasks "
            - class: %s" \
          --model_dir $MODEL_DIR \
          --model_params "
              inference.beam_search.beam_width: 5 
              inference.beam_search.beam_width_doc: 2" \
          --input_pipeline "
            class: ParallelTextInputPipeline_Image_Caption
            params:
              source_files:
                - $TEST_SOURCES
              target_files: 
                - $TEST_SOURCES
              image_files:
                - $TEST_SOURCES
              caption_files:
                - $TEST_SOURCES" \
          > ${PRED_DIR}/%s
        ''' % (gpu, MOFRL_DIR, TEST_SOURCES, decode_text, prediction))
    
def main():
    
    parser = argparse.ArgumentParser(description='sum-pic args')
    parser.add_argument('--action', choices=['train', 'infer', 'beam-search', 'beam-search-2', 'text'], default='train')
    parser.add_argument('--mode', choices=['caption', 'image', 'image-caption', 'image-caption-2', 'text'], default='caption')
    parser.add_argument('--batch_size', type=int, default=4)
    parser.add_argument('--gpu', type=int, default=None)
    parser.add_argument('--prediction', type=str, default='predictions-beam-search.txt')
    parser.add_argument('--bigram_award', type=int, default=3)
    parser.add_argument('--search_sents_num', type=int, default=3)
    parser.add_argument('--max_sent_len', type=int, default=50)
    args = parser.parse_args()
    #print(args.prediction)
    if args.action == 'train':
        if args.mode == 'image':
            train_image(args.batch_size, args.gpu)
        elif args.mode == 'caption':
            train_caption(args.batch_size, args.gpu)
        elif args.mode == 'image-caption':
            train_image_caption(args.batch_size, args.gpu)
        elif args.mode == 'text':
            train_text(args.batch_size, args.gpu)
    elif args.action == 'beam-search':
        beam_search(args.mode, args.gpu, args.prediction)
    elif args.action == 'beam-search-2':
        beam_search_2(args.mode, args.gpu, args.prediction,args.bigram_award,args.search_sents_num,args.max_sent_len)

if __name__=='__main__':
    main()
    










