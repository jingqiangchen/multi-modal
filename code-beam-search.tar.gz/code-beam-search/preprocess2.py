# -*- coding: utf-8 -*-
import numpy as np
import os, sys, threading, time
# display plots in this notebook
#%matplotlib inline
import caffe

from multiprocessing.pool import Pool
from multiprocessing.pool import ThreadPool
from itertools import izip
from itertools import repeat

import collections
import re
import common
from nltk.tokenize.stanford import StanfordTokenizer
import nltk


def extract_image_features_batch(image_names, net, transformer):
    batch_size=len(image_names)
    for i in range(batch_size):
        try:
            image_name=image_names[i]
            image_dir_name=image_name.split('-')[0]
            image = caffe.io.load_image(common.path_images+'/'+image_name)
            transformed_image = transformer.preprocess('data', image)
            net.blobs['data'].data[i,...] = transformed_image
        except ValueError:
            print('error0: '+common.path_images+'/'+image_name)
        
    output = net.forward()
    fc=output['conv5_4']
        
    for i in range(batch_size):
        try:
            image_name=image_names[i]
            image_dir_name=image_name.split('-')[0]
            fc[i].tofile(common.path_image_features+'/'+image_name)
        except ValueError:
            print('error1: '+common.path_images+'/'+image_name)


def extract_image_features_batch_ftp(batch_size=10):
    from ftplib import FTP
    net, transformer=load_caffe(batch_size)
    
    with open(common.path_image_list+'-0','r') as file:
        image_names=file.readlines()
    with open(common.path_image_list+'-0-u','r') as file:
        image_names_u=file.readlines()
    image_names=[line.replace('\n','') for line in image_names]
    image_names_u=[line.replace('\n','') for line in image_names_u]
    image_names=[image_name for image_name in image_names if image_name not in image_names_u]
    
    list_len=len(image_names)
    batch_num=list_len/batch_size
    ftp_download_dir='/home/cjq/sum-pic/dailymail/images'
    ftp_upload_dir='/home/cjq/sum-pic/dailymail/image-features-split-2'
    
    ftp=FTP()   
    ftp.connect("192.168.0.183")
    ftp.login("cjq","qwertyui")
    for batch_index in range(batch_num):
        ftp.cwd(ftp_download_dir)
        batch_image_names=image_names[batch_size*batch_index:batch_size*(batch_index+1)]
        for image_name in batch_image_names:
            image_dir_name=image_name.split('-')[0]
            ftp.retrbinary('RETR %s/%s' % (image_dir_name,image_name), open(common.path_images+'/'+image_name, 'wb').write)
        print(batch_image_names)
        
        extract_image_features_batch(batch_image_names,net,transformer)
        
        ftp.cwd(ftp_upload_dir)
        u_file_image_list_w=open(common.path_image_list+'-0-u','a')
        for image_name in batch_image_names:
            image_dir_name=image_name.split('-')[0]
            try:
                ftp.mkd(image_dir_name)
            except:
                pass
            ftp.storbinary('STOR %s/%s' % (image_dir_name,image_name), open(common.path_image_features+'/'+image_name, 'rb'))
            u_file_image_list_w.write(image_name+'\n')
        u_file_image_list_w.close()
            
        for image_name in batch_image_names:
            image_dir_name=image_name.split('-')[0]
            os.remove(common.path_image_features+'/'+image_name)
            os.remove(common.path_images+'/'+image_name)
            print('%d: %s' % (batch_index,image_name))

    ftp.quit()


def extract_image_features_ftp():
    from ftplib import FTP
    net, transformer=load_caffe()
    
    common.path_image_list=common.path_corpus+'/image-dirs'
    file_image_list=open(common.path_image_list+'-0','r')
    u_file_image_list=open(common.path_image_list+'-0-u','r')
    image_list_lines=file_image_list.readlines()
    image_list=[line.replace('\n','') for line in image_list_lines]
    u_image_list_lines=u_file_image_list.readlines()
    u_image_list=[line.replace('\n','') for line in u_image_list_lines]
    print(u_image_list)
    image_list=[image_name for image_name in image_list if image_name not in u_image_list]
    batch_size=1
    list_len=len(image_list)
    batch_num=1#list_len/batch_size
    ftp_download_dir='/home/cjq/sum-pic/dailymail/images'
    ftp_upload_dir='/home/cjq/sum-pic/dailymail/image-features-2'
    
    ftp=FTP()   
    ftp.connect("192.168.0.183")
    ftp.login("cjq","qwertyui")
    for batch_index in range(batch_num):
        ftp.cwd(ftp_download_dir)
        for image_name in image_list[batch_size*batch_index:batch_size*(batch_index+1)]:
            print(image_name)
            image_name=os.path.basename(image_name)
            if not os.path.exists(common.path_images+'/'+image_name):
                os.mkdir(common.path_images+'/'+image_name)
            file_list=ftp.nlst(image_name)
            for file in file_list:
                ftp.retrbinary('RETR %s' % file, open(common.path_images+'/'+file, 'wb').write)
        print(image_list[batch_size*batch_index:batch_size*(batch_index+1)-1])
        file_names=[os.path.basename(file_name) for file_name in image_list[batch_size*batch_index:batch_size*(batch_index+1)]]
        extract_image_features(file_names,net,transformer)
        
        ftp.cwd(ftp_upload_dir)
        u_file_image_list_w=open(common.path_image_list+'-0-u','a')
        for image_name in image_list[batch_size*batch_index:batch_size*(batch_index+1)]:
            image_name_base=os.path.basename(image_name)
            try:
                ftp.mkd(image_name_base)
            except:
                pass
            file_list=os.listdir(common.path_image_features+'/'+image_name_base)
            for file in file_list:
                ftp.storbinary('STOR '+image_name_base+'/'+file, open(common.path_image_features+'/'+image_name_base+'/'+file, 'rb'))
            u_file_image_list_w.write(image_name+'\n')
        u_file_image_list_w.close()
            
        for image_name in image_list[batch_size*batch_index:batch_size*(batch_index+1)]:
            image_name_base=os.path.basename(image_name)
            file_list=os.listdir(common.path_image_features+'/'+image_name_base)
            for file in file_list:
                os.remove(common.path_image_features+'/'+image_name_base+'/'+file)
                os.remove(common.path_images+'/'+image_name_base+'/'+file)
            os.removedirs(common.path_image_features+'/'+image_name_base)
            os.removedirs(common.path_images+'/'+image_name_base)

    ftp.quit()
    
    
def load_caffe(batch_size=1):
    if not os.path.exists(common.path_image_features):
        os.mkdir(common.path_image_features)
    
    if os.path.isfile(common.path_model):
        print 'CaffeNet found.'
    else:
        print 'Downloading pre-trained CaffeNet model...'
    
    caffe.set_mode_cpu()
    model_def = common.path_proto
    model_weights = common.path_model
    net = caffe.Net(model_def,      # defines the structure of the model
                    model_weights,  # contains the trained weights
                    caffe.TEST)     # use test mode (e.g., don't perform dropout)
    
    # load the mean ImageNet image (as distributed with Caffe) for subtraction
    mu = np.load(common.path_mean)
    mu = mu.mean(1).mean(1)  # average over pixels to obtain the mean (BGR) pixel values
    print 'mean-subtracted values:', zip('BGR', mu)
    # create transformer for the input called 'data'
    transformer = caffe.io.Transformer({'data': net.blobs['data'].data.shape})
    transformer.set_transpose('data', (2,0,1))  # move image channels to outermost dimension
    transformer.set_mean('data', mu)            # subtract the dataset-mean value in each channel
    transformer.set_raw_scale('data', 255)      # rescale from [0, 1] to [0, 255]
    transformer.set_channel_swap('data', (2,1,0))  # swap channels from RGB to BGR
    
    # set the size of the input (we can skip this if we're happy
    #  with the default; we can also change it later, e.g., for different batch sizes)
    net.blobs['data'].reshape(batch_size,        # batch size
                              3,         # 3-channel (BGR) images
                              224, 224)  # image size is 227x227
    return net,transformer
    
def extract_image_features(image_name_list, net, transformer):
    count=0
    count2=0
    for image_file_subdir in image_name_list:
        count2=count2+1
        if not os.path.exists(common.path_image_features+'/'+image_file_subdir):
            os.mkdir(common.path_image_features+'/'+image_file_subdir)
            
        image_file_names=os.listdir(common.path_images+'/'+image_file_subdir)
        for image_file_name in image_file_names:
            count=count+1
            if os.path.exists(common.path_image_features+'/'+image_file_subdir+'/'+image_file_name):
                print(count2, count, image_file_name)
                continue
            
            try:
                image = caffe.io.load_image(common.path_images+'/'+image_file_subdir+'/'+image_file_name)
                transformed_image = transformer.preprocess('data', image)
                #print(transformed_image)
                #plt.imshow(image)
                
                # copy the image data into the memory allocated for the net
                net.blobs['data'].data[...] = transformed_image
                ### perform classification
                output = net.forward()
                #output_prob = output['prob'][0]  # the output probability vector for the first image in the batch
                fc=output['conv5_4']
                #print 'predicted class is:', output_prob.argmax()
                #print(output)
                print(count2, count, image_file_name, len(fc), len(fc[0]))
                fc.tofile(common.path_image_features+'/'+image_file_subdir+'/'+image_file_name)
            except ValueError:
                print(common.path_images+'/'+image_file_subdir+'/'+image_file_name)
    
        
def generate_image_list():
    image_file_subdirs=os.listdir(common.path_images)
    print(len(image_file_subdirs))
        

def extract_feature_test():
    if not os.path.exists(common.path_image_features):
        os.mkdir(common.path_image_features)
    
    if os.path.isfile(common.path_model):
        print 'CaffeNet found.'
    else:
        print 'Downloading pre-trained CaffeNet model...'
    
    caffe.set_mode_cpu()
    model_def = common.path_proto
    model_weights = common.path_model
    net = caffe.Net(model_def,      # defines the structure of the model
                    model_weights,  # contains the trained weights
                    caffe.TEST)     # use test mode (e.g., don't perform dropout)
    
    # load the mean ImageNet image (as distributed with Caffe) for subtraction
    mu = np.load(common.path_mean)
    mu = mu.mean(1).mean(1)  # average over pixels to obtain the mean (BGR) pixel values
    print 'mean-subtracted values:', zip('BGR', mu)
    # create transformer for the input called 'data'
    transformer = caffe.io.Transformer({'data': net.blobs['data'].data.shape})
    transformer.set_transpose('data', (2,0,1))  # move image channels to outermost dimension
    transformer.set_mean('data', mu)            # subtract the dataset-mean value in each channel
    transformer.set_raw_scale('data', 255)      # rescale from [0, 1] to [0, 255]
    transformer.set_channel_swap('data', (2,1,0))  # swap channels from RGB to BGR
    
    # set the size of the input (we can skip this if we're happy
    #  with the default; we can also change it later, e.g., for different batch sizes)
    net.blobs['data'].reshape(1,        # batch size
                              3,         # 3-channel (BGR) images
                              224, 224)  # image size is 227x227

            
    try:
        for i in range(3):
            image = caffe.io.load_image('/home/cjq/sum-pic/dailymail/test/images/%d' % i)
            transformed_image = transformer.preprocess('data', image)
            net.blobs['data'].data[i,...] = transformed_image
        output = net.forward()
        #output_prob = output['prob'][0]  # the output probability vector for the first image in the batch
        fc=output['conv5_4']
        #print 'predicted class is:', output_prob.argmax()
        print(fc)
        #fc.tofile(common.path_image_features+'/'+image_file_subdir+'/'+image_file_name)
    except ValueError:
        #print(common.path_images+'/'+image_file_subdir+'/'+image_file_name)
        pass
    
    
if __name__=='__main__':
    extract_image_features_batch_ftp(batch_size=50)
    #print(np.fromfile('/home/cjq/sum-pic/dailymail/image-features/test/index.jpg'))









