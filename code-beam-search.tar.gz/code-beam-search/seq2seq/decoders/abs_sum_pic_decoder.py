
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from collections import namedtuple
import tensorflow as tf
from seq2seq.decoders.rnn_decoder import RNNDecoder
from seq2seq.contrib.seq2seq.decoder import dynamic_decode_hie

from seq2seq.contrib.seq2seq.helper import CustomHelper
from seq2seq.training import utils as training_utils


class AbsSumPicDecoderOutput(
    namedtuple("DecoderOutput", [
        "logits", "predicted_ids", "text_scores", "image_scores", "caption_scores"
    ])):
  pass



class AbsSumPicDecoder_Caption_Hie(RNNDecoder):
  def __init__(self,
               params,
               mode,
               vocab_size,
               attention_keys,
               attention_values,
               attention_values_length,
               attention_fn,
               reverse_scores_lengths=None,
               name="AbsSumPicDecoder"):
    super(AbsSumPicDecoder_Caption_Hie, self).__init__(params, mode, name)
    self.doc_cell1 = training_utils.get_rnn_cell(**self.params["rnn_cell"])
    self.doc_cell2 = training_utils.get_rnn_cell(**self.params["rnn_cell"])
    self.vocab_size = vocab_size
    self.attention_keys = attention_keys
    self.attention_values = attention_values
    self.attention_values_length = attention_values_length
    self.attention_fn = attention_fn
    self.reverse_scores_lengths = reverse_scores_lengths

  @property
  def output_size(self):
    return AbsSumPicDecoderOutput(
        logits=self.vocab_size,
        predicted_ids=tf.TensorShape([]),
        text_scores=tf.shape(self.attention_values[0])[1:-1],
        image_scores=tf.shape(self.attention_values[1])[1:-1],
        caption_scores=tf.shape(self.attention_values[1])[1:-1])

  @property
  def output_dtype(self):
    return AbsSumPicDecoderOutput(
        logits=tf.float32,
        predicted_ids=tf.int32,
        text_scores=tf.float32,
        image_scores=tf.float32,
        caption_scores=tf.float32)

  def initialize(self, name=None):
    finished, first_inputs = self.helper.initialize()
    is_new_sent = tf.constant(True)

    '''attention_context = (
        tf.zeros([
            tf.shape(first_inputs)[0],
            self.attention_values[0].get_shape().as_list()[-1]
        ]), 
        tf.zeros([
            tf.shape(first_inputs)[0],
            self.attention_values[1].get_shape().as_list()[-1]
        ]))
    first_inputs = tf.concat([first_inputs, attention_context], 1)'''

    return (finished[0], finished[1], is_new_sent), first_inputs, (self.initial_state, tf.zeros(tf.shape(self.initial_state)))

  def _setup(self, initial_state, helper):
    self.initial_state = initial_state 
    self.zero_logits = tf.zeros([tf.shape(initial_state)[0],self.vocab_size],tf.float32)
    #print("initial_state", initial_state)
    def att_next_inputs(time, outputs, state, sample_ids, name=None):

      finished, next_inputs, next_state = helper.next_inputs(
          time=time,
          outputs=outputs,
          state=state,
          sample_ids=sample_ids,
          name=name)
      #next_inputs = tf.concat([next_inputs, outputs.attention_context], 1)
      return (finished, next_inputs, next_state)

    '''self.helper = CustomHelper(
        initialize_fn=helper.initialize,
        sample_fn=helper.sample,
        next_inputs_fn=att_next_inputs)'''
    self.helper=helper
  
  def compute_sent_output(self, inputs, sent_state):

    '''text_scores, text_context, pic_scores, pic_context = self.attention_fn(
        query=cell_output,
        keys=self.attention_keys,
        values=self.attention_values,
        values_length=self.attention_values_length)

    attention_context=tf.concat([text_context,pic_context],1)

    cell_output_2, cell_state_2 = self.cell2(attention_context, cell_state, "decode_cell_2")'''

    sent_output, new_sent_state = self.cell(inputs, sent_state, "decode_sent_cell_1")
    logits = tf.contrib.layers.fully_connected(
        inputs=sent_output,
        num_outputs=self.vocab_size,
        activation_fn=None,
        scope="logits", reuse=tf.AUTO_REUSE)

    return logits, new_sent_state

  def compute_doc_output(self, doc_state, sent_state):
    
    doc_cell_output, doc_cell_state = self.doc_cell1(sent_state, doc_state, "decode_doc_cell_1")
    
    text_scores, text_context, pic_scores, pic_context = self.attention_fn(
        query=doc_cell_output,
        keys=self.attention_keys,
        values=self.attention_values,
        values_length=self.attention_values_length)
    
    attention_context=tf.concat([text_context,pic_context],1)

    cell_doc_output_2, cell_doc_state_2 = self.doc_cell2(attention_context, doc_cell_state, "decode_doc_cell_2")

    return cell_doc_state_2, cell_doc_state_2, text_scores, pic_scores

  def step(self, time_, inputs, state, finished, name=None):
    
    doc_finished, sent_finished, is_new_sent = finished 
    all_sent_finished = tf.reduce_all(sent_finished)
    doc_state, sent_state = state
    
    def true_fn():
        new_doc_state, new_sent_state, text_scores, pic_scores = self.compute_doc_output(doc_state, sent_state)
        logits, new_sent_state = self.compute_sent_output(inputs, new_sent_state)
        return logits, new_doc_state, new_sent_state, text_scores, pic_scores
                                                
    def false_fn():
        def false_true_fn():
            return tf.zeros([tf.shape(sent_state)[0],self.vocab_size],tf.float32), sent_state
        
        def false_false_fn():
            return self.compute_sent_output(inputs, sent_state)
        
        logits, new_sent_state=tf.cond(all_sent_finished,false_true_fn,false_false_fn)
        source_tokens,caption_tokens=self.attention_values
        
        return logits, doc_state, new_sent_state, tf.zeros(tf.shape(source_tokens)[:-1]), tf.zeros(tf.shape(caption_tokens)[:-1])
    
    
    logits, new_doc_state, new_sent_state, text_scores, pic_scores = tf.cond(is_new_sent, true_fn=true_fn, false_fn=false_fn)

    '''if self.reverse_scores_lengths is not None:
      attention_scores = tf.reverse_sequence(
          input=attention_scores,
          seq_lengths=self.reverse_scores_lengths,
          seq_dim=1,
          batch_dim=0)'''

    sample_ids = self.helper.sample(
        time=time_, outputs=logits, state=(new_doc_state, new_sent_state))
    
    outputs = AbsSumPicDecoderOutput(
        logits=logits,
        predicted_ids=sample_ids,
        text_scores=text_scores,
        image_scores=pic_scores,
        caption_scores=pic_scores)

    finished, next_inputs, next_state = self.helper.next_inputs(
        time=time_, outputs=outputs, state=(new_doc_state, new_sent_state), sample_ids=sample_ids)

    return (outputs, (new_doc_state, new_sent_state), next_inputs, finished)

  def _build(self, initial_state, helper):
    if not self.initial_state:
      self._setup(initial_state, helper)

    scope = tf.get_variable_scope()
    scope.set_initializer(tf.random_uniform_initializer(
        -self.params["init_scale"],
        self.params["init_scale"]))

    maximum_iterations = None
    if self.mode == tf.contrib.learn.ModeKeys.INFER:
      maximum_iterations = self.params["max_decode_length"]
    
    outputs, final_state = dynamic_decode_hie(
        decoder=self,
        output_time_major=True,
        impute_finished=True,
        maximum_iterations=maximum_iterations)
    
    return self.finalize(outputs, final_state)


class AbsSumPicDecoder_Image_Hie(AbsSumPicDecoder_Caption_Hie):
    pass

class AbsSumPicDecoder_Hie(AbsSumPicDecoder_Caption_Hie):
  def __init__(self,
               params,
               mode,
               vocab_size,
               attention_keys,
               attention_values,
               attention_values_length,
               attention_fn,
               reverse_scores_lengths=None,
               name="AbsSumPicDecoder_Hie"):
    super(AbsSumPicDecoder_Hie, self).__init__(params,
               mode,vocab_size, attention_keys,attention_values,
               attention_values_length,attention_fn,reverse_scores_lengths,name)

  @property
  def output_size(self):
    return AbsSumPicDecoderOutput(
        logits=self.vocab_size,
        predicted_ids=tf.TensorShape([]),
        text_scores=tf.shape(self.attention_values[0])[1:-1],
        image_scores=tf.shape(self.attention_values[0])[1:-1],
        caption_scores=tf.shape(self.attention_values[0])[1:-1])

  def compute_doc_output(self, doc_state, sent_state):
    
    doc_cell_output, doc_cell_state = self.doc_cell1(sent_state, doc_state, "decode_doc_cell_1")
    
    text_scores, text_context = self.attention_fn(
        query=doc_cell_output,
        keys=self.attention_keys,
        values=self.attention_values,
        values_length=self.attention_values_length)

    cell_doc_output_2, cell_doc_state_2 = self.doc_cell2(text_context, doc_cell_state, "decode_doc_cell_2")

    return cell_doc_state_2, cell_doc_state_2, text_scores

  def step(self, time_, inputs, state, finished, name=None):
    
    doc_finished, sent_finished, is_new_sent = finished 
    all_sent_finished = tf.reduce_all(sent_finished)
    doc_state, sent_state = state
    
    def true_fn():
        new_doc_state, new_sent_state, text_scores = self.compute_doc_output(doc_state, sent_state)
        logits, new_sent_state = self.compute_sent_output(inputs, new_sent_state)
        return logits, new_doc_state, new_sent_state, text_scores
                                                
    def false_fn():
        def false_true_fn():
            return self.zero_logits, sent_state
        
        def false_false_fn():
            return self.compute_sent_output(inputs, sent_state)
        
        logits, new_sent_state=tf.cond(all_sent_finished,false_true_fn,false_false_fn)
        
        return logits, doc_state, new_sent_state, tf.zeros(tf.shape(self.attention_values)[:-1])
    
    
    logits, new_doc_state, new_sent_state, text_scores = tf.cond(is_new_sent, true_fn=true_fn, false_fn=false_fn)

    sample_ids = self.helper.sample(
        time=time_, outputs=logits, state=(new_doc_state, new_sent_state))
    
    outputs = AbsSumPicDecoderOutput(
        logits=logits,
        predicted_ids=sample_ids,
        text_scores=text_scores,
        image_scores=text_scores,
        caption_scores=text_scores)

    finished, next_inputs, next_state = self.helper.next_inputs(
        time=time_, outputs=outputs, state=(new_doc_state, new_sent_state), sample_ids=sample_ids)

    return (outputs, (new_doc_state, new_sent_state), next_inputs, finished)


class AbsSumPicDecoder_Image_Caption_Hie(RNNDecoder):
    
  def __init__(self,
               params,
               mode,
               vocab_size,
               attention_keys,
               attention_values,
               attention_values_length,
               attention_fn,
               reverse_scores_lengths=None,
               name="AbsSumPicDecoder"):
    super(AbsSumPicDecoder_Image_Caption_Hie, self).__init__(params, mode, name)
    self.doc_cell1 = training_utils.get_rnn_cell(**self.params["rnn_cell"])
    self.doc_cell2 = training_utils.get_rnn_cell(**self.params["rnn_cell"])
    self.vocab_size = vocab_size
    self.attention_keys = attention_keys
    self.attention_values = attention_values
    self.attention_values_length = attention_values_length
    self.attention_fn = attention_fn
    self.reverse_scores_lengths = reverse_scores_lengths

  @property
  def output_size(self):
    return AbsSumPicDecoderOutput(
        logits=self.vocab_size,
        predicted_ids=tf.TensorShape([]),
        text_scores=tf.shape(self.attention_values[0])[1:-1],
        image_scores=tf.shape(self.attention_values[1])[1:-1],
        caption_scores=tf.shape(self.attention_values[2])[1:-1])

  @property
  def output_dtype(self):
    return AbsSumPicDecoderOutput(
        logits=tf.float32,
        predicted_ids=tf.int32,
        text_scores=tf.float32,
        image_scores=tf.float32,
        caption_scores=tf.float32)

  def initialize(self, name=None):
    finished, first_inputs = self.helper.initialize()
    is_new_sent = tf.constant(True)

    '''attention_context = (
        tf.zeros([
            tf.shape(first_inputs)[0],
            self.attention_values[0].get_shape().as_list()[-1]
        ]), 
        tf.zeros([
            tf.shape(first_inputs)[0],
            self.attention_values[1].get_shape().as_list()[-1]
        ]))
    first_inputs = tf.concat([first_inputs, attention_context], 1)'''

    return (finished[0], finished[1], is_new_sent), first_inputs, (self.initial_state, tf.zeros(tf.shape(self.initial_state)))

  def _setup(self, initial_state, helper):
    self.initial_state = initial_state
    self.zero_logits = tf.zeros([tf.shape(initial_state)[0],self.vocab_size],tf.float32)
    self.helper=helper

    '''def att_next_inputs(time, outputs, state, sample_ids, name=None):

      finished, next_inputs, next_state = helper.next_inputs(
          time=time,
          outputs=outputs,
          state=state,
          sample_ids=sample_ids,
          name=name)
      #next_inputs = tf.concat([next_inputs, outputs.attention_context], 1)
      return (finished, next_inputs, next_state)

    self.helper = CustomHelper(
        initialize_fn=helper.initialize,
        sample_fn=helper.sample,
        next_inputs_fn=att_next_inputs)'''
  
  def compute_sent_output(self, inputs, sent_state):

    '''text_scores, text_context, pic_scores, pic_context = self.attention_fn(
        query=cell_output,
        keys=self.attention_keys,
        values=self.attention_values,
        values_length=self.attention_values_length)

    attention_context=tf.concat([text_context,pic_context],1)

    cell_output_2, cell_state_2 = self.cell2(attention_context, cell_state, "decode_cell_2")'''

    sent_output, new_sent_state = self.cell(inputs, sent_state, "decode_sent_cell_1")
    logits = tf.contrib.layers.fully_connected(
        inputs=sent_output,
        num_outputs=self.vocab_size,
        activation_fn=None,
        scope="logits", reuse=tf.AUTO_REUSE) 

    return logits, new_sent_state

  def compute_doc_output(self, doc_state, sent_state):
    
    doc_cell_output, doc_cell_state = self.doc_cell1(sent_state, doc_state, "decode_doc_cell_1")
    
    text_scores, text_context, image_scores, image_context, caption_scores, caption_context = self.attention_fn(
        query=doc_cell_output,
        keys=self.attention_keys,
        values=self.attention_values,
        values_length=self.attention_values_length)
    
    attention_context=tf.concat([text_context, image_context, caption_context],1)

    cell_doc_output_2, cell_doc_state_2 = self.doc_cell2(attention_context, doc_cell_state, "decode_doc_cell_2")

    return cell_doc_state_2, cell_doc_state_2, text_scores, image_scores, caption_scores

  def step(self, time_, inputs, state, finished, name=None):
    
    doc_finished, sent_finished, is_new_sent = finished
    all_sent_finished = tf.reduce_all(sent_finished)
    doc_state, sent_state = state
    
    def true_fn():
        new_doc_state, new_sent_state, text_scores, image_scores, caption_scores = self.compute_doc_output(doc_state, sent_state)
        logits, new_sent_state = self.compute_sent_output(inputs, new_sent_state)
        return logits, new_doc_state, new_sent_state, text_scores, image_scores, caption_scores
                                                
    def false_fn():
        def false_true_fn():
            return self.zero_logits, sent_state
        
        def false_false_fn():
            return self.compute_sent_output(inputs, sent_state)
        
        logits, new_sent_state=tf.cond(all_sent_finished,false_true_fn,false_false_fn)
        source_tokens, image_tokens, caption_tokens=self.attention_values
        
        return logits, doc_state, new_sent_state, tf.zeros(tf.shape(source_tokens)[:-1]), tf.zeros(tf.shape(image_tokens)[:-1]), tf.zeros(tf.shape(caption_tokens)[:-1])
    
    
    logits, new_doc_state, new_sent_state, text_scores, image_scores, caption_scores = tf.cond(is_new_sent, true_fn=true_fn, false_fn=false_fn)

    '''if self.reverse_scores_lengths is not None:
      attention_scores = tf.reverse_sequence(
          input=attention_scores,
          seq_lengths=self.reverse_scores_lengths,
          seq_dim=1,
          batch_dim=0)'''

    sample_ids = self.helper.sample(
        time=time_, outputs=logits, state=(new_doc_state, new_sent_state))
    
    outputs = AbsSumPicDecoderOutput(
        logits=logits,
        predicted_ids=sample_ids,
        text_scores=text_scores,
        image_scores=image_scores,
        caption_scores=caption_scores)

    finished, next_inputs, next_state = self.helper.next_inputs(
        time=time_, outputs=outputs, state=(new_doc_state, new_sent_state), sample_ids=sample_ids)

    return (outputs, (new_doc_state, new_sent_state), next_inputs, finished)

  def _build(self, initial_state, helper):
    if not self.initial_state:
      self._setup(initial_state, helper)

    scope = tf.get_variable_scope()
    scope.set_initializer(tf.random_uniform_initializer(
        -self.params["init_scale"],
        self.params["init_scale"]))

    maximum_iterations = None
    if self.mode == tf.contrib.learn.ModeKeys.INFER:
      maximum_iterations = self.params["max_decode_length"]
    
    outputs, final_state = dynamic_decode_hie(
        decoder=self,
        output_time_major=True,
        impute_finished=True,
        maximum_iterations=maximum_iterations)
    
    return self.finalize(outputs, final_state)


class AbsSumPicDecoder_Image_Caption_2_Hie(RNNDecoder):
    
  def __init__(self,
               params,
               mode,
               vocab_size,
               attention_keys,
               attention_values,
               attention_values_length,
               attention_fn,
               reverse_scores_lengths=None,
               name="AbsSumPicDecoder"):
    super(AbsSumPicDecoder_Image_Caption_2_Hie, self).__init__(params, mode, name)
    self.doc_cell1 = training_utils.get_rnn_cell(**self.params["rnn_cell"])
    self.doc_cell2 = training_utils.get_rnn_cell(**self.params["rnn_cell"])
    self.vocab_size = vocab_size
    self.attention_keys = attention_keys
    self.attention_values = attention_values
    self.attention_values_length = attention_values_length
    self.attention_fn = attention_fn
    self.reverse_scores_lengths = reverse_scores_lengths

  @property
  def output_size(self):
    return AbsSumPicDecoderOutput(
        logits=self.vocab_size,
        predicted_ids=tf.TensorShape([]),
        text_scores=tf.shape(self.attention_values[0])[1:-1],
        image_scores=tf.shape(self.attention_values[1])[1:-1],
        caption_scores=tf.shape(self.attention_values[1])[1:-1])

  @property
  def output_dtype(self):
    return AbsSumPicDecoderOutput(
        logits=tf.float32,
        predicted_ids=tf.int32,
        text_scores=tf.float32,
        image_scores=tf.float32,
        caption_scores=tf.float32)

  def initialize(self, name=None):
    finished, first_inputs = self.helper.initialize()
    is_new_sent = tf.constant(True)

    '''attention_context = (
        tf.zeros([
            tf.shape(first_inputs)[0],
            self.attention_values[0].get_shape().as_list()[-1]
        ]), 
        tf.zeros([
            tf.shape(first_inputs)[0],
            self.attention_values[1].get_shape().as_list()[-1]
        ]))
    first_inputs = tf.concat([first_inputs, attention_context], 1)'''

    return (finished[0], finished[1], is_new_sent), first_inputs, (self.initial_state, tf.zeros(tf.shape(self.initial_state)))

  def _setup(self, initial_state, helper):
    self.initial_state = initial_state
    self.zero_logits = tf.zeros([tf.shape(initial_state)[0],self.vocab_size],tf.float32)
    self.helper=helper

    '''def att_next_inputs(time, outputs, state, sample_ids, name=None):

      finished, next_inputs, next_state = helper.next_inputs(
          time=time,
          outputs=outputs,
          state=state,
          sample_ids=sample_ids,
          name=name)
      #next_inputs = tf.concat([next_inputs, outputs.attention_context], 1)
      return (finished, next_inputs, next_state)

    self.helper = CustomHelper(
        initialize_fn=helper.initialize,
        sample_fn=helper.sample,
        next_inputs_fn=att_next_inputs)'''
  
  def compute_sent_output(self, inputs, sent_state):

    '''text_scores, text_context, pic_scores, pic_context = self.attention_fn(
        query=cell_output,
        keys=self.attention_keys,
        values=self.attention_values,
        values_length=self.attention_values_length)

    attention_context=tf.concat([text_context,pic_context],1)

    cell_output_2, cell_state_2 = self.cell2(attention_context, cell_state, "decode_cell_2")'''

    sent_output, new_sent_state = self.cell(inputs, sent_state, "decode_sent_cell_1")
    logits = tf.contrib.layers.fully_connected(
        inputs=sent_output,
        num_outputs=self.vocab_size,
        activation_fn=None,
        scope="logits", reuse=tf.AUTO_REUSE) 

    return logits, new_sent_state

  def compute_doc_output(self, doc_state, sent_state):
    
    doc_cell_output, doc_cell_state = self.doc_cell1(sent_state, doc_state, "decode_doc_cell_1")
    
    text_scores, text_context, image_scores, image_context = self.attention_fn(
        query=doc_cell_output,
        keys=self.attention_keys,
        values=self.attention_values,
        values_length=self.attention_values_length)
    
    attention_context=tf.concat([text_context, image_context],1)

    cell_doc_output_2, cell_doc_state_2 = self.doc_cell2(attention_context, doc_cell_state, "decode_doc_cell_2")

    return cell_doc_state_2, cell_doc_state_2, text_scores, image_scores

  def step(self, time_, inputs, state, finished, name=None):
    
    doc_finished, sent_finished, is_new_sent = finished
    all_sent_finished = tf.reduce_all(sent_finished)
    doc_state, sent_state = state
    
    def true_fn():
        new_doc_state, new_sent_state, text_scores, image_scores = self.compute_doc_output(doc_state, sent_state)
        logits, new_sent_state = self.compute_sent_output(inputs, new_sent_state)
        return logits, new_doc_state, new_sent_state, text_scores, image_scores
                                                
    def false_fn():
        def false_true_fn():
            return self.zero_logits, sent_state
        
        def false_false_fn():
            return self.compute_sent_output(inputs, sent_state)
        
        logits, new_sent_state=tf.cond(all_sent_finished,false_true_fn,false_false_fn)
        source_tokens, image_tokens=self.attention_values
        
        return logits, doc_state, new_sent_state, tf.zeros(tf.shape(source_tokens)[:-1]), tf.zeros(tf.shape(image_tokens)[:-1])
    
    
    logits, new_doc_state, new_sent_state, text_scores, image_scores = tf.cond(is_new_sent, true_fn=true_fn, false_fn=false_fn)

    '''if self.reverse_scores_lengths is not None:
      attention_scores = tf.reverse_sequence(
          input=attention_scores,
          seq_lengths=self.reverse_scores_lengths,
          seq_dim=1,
          batch_dim=0)'''

    sample_ids = self.helper.sample(
        time=time_, outputs=logits, state=(new_doc_state, new_sent_state))
    
    outputs = AbsSumPicDecoderOutput(
        logits=logits,
        predicted_ids=sample_ids,
        text_scores=text_scores,
        image_scores=image_scores,
        caption_scores=image_scores)

    finished, next_inputs, next_state = self.helper.next_inputs(
        time=time_, outputs=outputs, state=(new_doc_state, new_sent_state), sample_ids=sample_ids)

    return (outputs, (new_doc_state, new_sent_state), next_inputs, finished)

  def _build(self, initial_state, helper):
    if not self.initial_state:
      self._setup(initial_state, helper)

    scope = tf.get_variable_scope()
    scope.set_initializer(tf.random_uniform_initializer(
        -self.params["init_scale"],
        self.params["init_scale"]))

    maximum_iterations = None
    if self.mode == tf.contrib.learn.ModeKeys.INFER:
      maximum_iterations = self.params["max_decode_length"]
    
    outputs, final_state = dynamic_decode_hie(
        decoder=self,
        output_time_major=True,
        impute_finished=True,
        maximum_iterations=maximum_iterations)
    
    return self.finalize(outputs, final_state)





    
