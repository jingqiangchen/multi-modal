
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from collections import namedtuple

import tensorflow as tf
from tensorflow.python.util import nest  # pylint: disable=E0611

from seq2seq.inference import beam_search
from seq2seq.decoders.rnn_decoder import RNNDecoder

from tensorflow.python.ops import math_ops

from seq2seq.contrib.seq2seq.decoder import dynamic_decode_beam_search


class FinalBeamDecoderOutput(
    namedtuple("FinalBeamDecoderOutput",
               ["predicted_ids", "beam_search_output"])):
  pass


class BeamDecoderOutput(
    namedtuple("BeamDecoderOutput", [
        "logits", "predicted_ids", "log_probs", "scores", "beam_parent_ids",
        "original_outputs", "attention_index"
    ])):
  pass


class BeamSearchDecoder(RNNDecoder):

  def __init__(self, decoder, config):
    super(BeamSearchDecoder, self).__init__(decoder.params, decoder.mode,
                                            decoder.name)
    self.decoder = decoder
    self.config = config

  def __call__(self, *args, **kwargs):
    with self.decoder.variable_scope():
      return self._build(*args, **kwargs)

  @property
  def output_size(self):
    return BeamDecoderOutput(
        logits=self.decoder.vocab_size,
        predicted_ids=tf.TensorShape([]),
        log_probs=tf.TensorShape([]),
        scores=tf.TensorShape([]),
        beam_parent_ids=tf.TensorShape([]),
        original_outputs=self.decoder.output_size,
        attention_index=tf.TensorShape([]))

  @property
  def output_dtype(self):
    return BeamDecoderOutput(
        logits=tf.float32,
        predicted_ids=tf.int64,
        log_probs=tf.float32,
        scores=tf.float32,
        beam_parent_ids=tf.int32,
        original_outputs=self.decoder.output_dtype,
        attention_index=tf.int32)

  @property
  def batch_size(self):
    return self.config.beam_width

  def initialize(self, name=None):
    finished, first_inputs, initial_state = self.decoder.initialize()
    f1, f2, f3 = finished
    
    # Create beam state
    beam_state = beam_search.create_initial_beam_state(
        config=self.config)
    
    return (f1, f2, f3, tf.constant(False)), first_inputs, (initial_state, beam_state)

  def finalize(self, outputs, final_state):
    # Gather according to beam search result
    predicted_ids = beam_search.gather_tree(outputs.predicted_ids,
                                            outputs.beam_parent_ids)

    outputs = nest.map_structure(lambda x: tf.expand_dims(x, 1), outputs)

    final_outputs = FinalBeamDecoderOutput(
        predicted_ids=tf.expand_dims(predicted_ids, 1),
        beam_search_output=outputs)

    return final_outputs, final_state

  def _build(self, initial_state, helper):
    # Tile initial state
    
    initial_state = nest.map_structure(
        lambda x: tf.tile(x, [self.config.beam_width, 1]), initial_state)
    initial_state.set_shape([self.config.beam_width,None])
    self.decoder._setup(initial_state, helper)  #pylint: disable=W0212
    
    if not self.initial_state:
      self._setup(initial_state, helper)

    scope = tf.get_variable_scope()
    scope.set_initializer(tf.random_uniform_initializer(
        -self.params["init_scale"],
        self.params["init_scale"]))

    maximum_iterations = None
    if self.mode == tf.contrib.learn.ModeKeys.INFER:
      maximum_iterations = self.params["max_decode_length"]

    outputs, final_state = dynamic_decode_beam_search(
        decoder=self,
        output_time_major=True,
        impute_finished=True,
        maximum_iterations=maximum_iterations)
    
    return self.finalize(outputs, final_state)
    #return super(BeamSearchDecoder, self)._build(self.decoder.initial_state, self.decoder.helper)

  def step(self, time_, inputs, state, finished, name=None):
    decoder_state, beam_state = state
    _, _, is_new_sent, is_new_start = finished
    
    (decoder_output, decoder_state, _, _) = self.decoder.step(time_, inputs,
                                                              decoder_state, finished[0:3])
    
    # Perform a step of beam search
    def beam_true_fn():
        text_scores = decoder_output.text_scores[0] * (1 - beam_state.source_visited)
        image_scores = decoder_output.image_scores[0] * (1 - beam_state.image_visited)
        caption_scores = decoder_output.caption_scores[0] * (1 - beam_state.image_visited)
        scores = tf.concat([text_scores, image_scores, caption_scores], 0)
        
        _, indices = tf.nn.top_k(scores, k=1)
        index=indices[0]
        
        def beam_true_true_fn():
            source_visited = beam_state.source_visited + tf.one_hot(
                index, tf.shape(beam_state.source_visited)[0], on_value=1., off_value=0.)
            return self.config.source_ids[index], source_visited, beam_state.image_visited
        
        def beam_true_false_fn():
            mod_index=tf.mod(index-tf.shape(text_scores)[0], tf.shape(image_scores)[0])
            image_visited = beam_state.image_visited + tf.one_hot(
                mod_index, tf.shape(beam_state.image_visited)[0], on_value=1., off_value=0.)
            return self.config.caption_ids[mod_index], beam_state.source_visited, image_visited
        
        ref_ids, source_visited, image_visited=tf.cond(index<tf.shape(text_scores)[0], 
                                                       beam_true_true_fn, beam_true_false_fn)
        source_visited.set_shape([None])
        image_visited.set_shape([None])
        
        new_beam_state = beam_search.BeamSearchState(
              log_probs=beam_state.log_probs,
              lengths=beam_state.lengths,
              prev_word_ids=beam_state.prev_word_ids,
              finished=beam_state.finished,
              ref_ids=ref_ids,
              ref_id_visiteds=tf.fill([self.config.beam_width,tf.shape(ref_ids)[0]],False),
              source_visited=source_visited,
              image_visited=image_visited)
        return new_beam_state,tf.fill([self.config.beam_width],index)
    
    def beam_false_fn():
        return beam_state,tf.fill([self.config.beam_width],-1)
    
    beam_state, attention_index = tf.cond(is_new_sent, beam_true_fn, beam_false_fn)
    
    bs_output, beam_state = beam_search.beam_search_step(
        is_new_start=is_new_start,
        logits=decoder_output.logits,
        inputs=inputs,
        beam_state=beam_state,
        config=self.config)

    # Shuffle everything according to beam search result
    decoder_state = nest.map_structure(
        lambda x: tf.gather(x, bs_output.beam_parent_ids), decoder_state)
    decoder_output = nest.map_structure(
        lambda x: tf.gather(x, bs_output.beam_parent_ids), decoder_output)

    next_state = (decoder_state, beam_state)

    outputs = BeamDecoderOutput(
        logits=tf.zeros([self.config.beam_width, self.config.vocab_size]),
        predicted_ids=bs_output.predicted_ids,
        log_probs=beam_state.log_probs,
        scores=bs_output.scores,
        beam_parent_ids=bs_output.beam_parent_ids,
        original_outputs=decoder_output,
        attention_index=attention_index)

    finished, next_inputs, next_state = self.decoder.helper.next_inputs(
        time=time_,
        outputs=decoder_output,
        state=next_state,
        sample_ids=bs_output.predicted_ids)
    next_inputs.set_shape([self.config.beam_width, None])
    
    #----------------------------------------------------------------------------#
    _, sent_finished, is_new_sent, is_new_start = finished
    all_sent_finished = tf.reduce_all(sent_finished)
    

    def true_fn():
        _, indices = tf.nn.top_k(bs_output.scores, k=1)
        index=indices[0]
        
        doc_state, sent_state = decoder_state
        #new_sent_state=sent_state
        new_sent_state=tf.tile(sent_state[index:index+1,:],[self.config.beam_width,1])
        new_sent_state.set_shape([self.config.beam_width, None])
        doc_state.set_shape([self.config.beam_width, None])
        log_probs=tf.tile(beam_state.log_probs[index:index+1],[self.config.beam_width])
        log_probs.set_shape([self.config.beam_width])
        new_beam_state = beam_search.BeamSearchState(
              log_probs = log_probs,
              lengths = tf.fill([self.config.beam_width],0),
              finished = tf.fill([self.config.beam_width],False),
              prev_word_ids = tf.fill([self.config.beam_width], self.config.sos_token),
              ref_ids = beam_state.ref_ids,
              ref_id_visiteds=beam_state.ref_id_visiteds,
              source_visited = beam_state.source_visited,
              image_visited = beam_state.image_visited)
        
        new_outputs = BeamDecoderOutput(
                logits=outputs.logits,
                predicted_ids=tf.fill([self.config.beam_width], outputs.predicted_ids[index]),
                log_probs=tf.fill([self.config.beam_width], outputs.log_probs[index]),
                scores=tf.fill([self.config.beam_width], outputs.scores[index]),
                beam_parent_ids=tf.fill([self.config.beam_width], outputs.beam_parent_ids[index]),
                original_outputs=outputs.original_outputs,
                attention_index=outputs.attention_index)
        
        return new_outputs, ((doc_state, new_sent_state), new_beam_state), next_inputs, finished
        #return outputs, next_state, next_inputs, finished
    
    def false_fn():
        return outputs, next_state, next_inputs, finished
    
    outputs, next_state, next_inputs, finished = tf.cond(all_sent_finished, true_fn, false_fn)
    
    #-----------------------------------------------------------------------------#

    return (outputs, next_state, next_inputs, finished)









