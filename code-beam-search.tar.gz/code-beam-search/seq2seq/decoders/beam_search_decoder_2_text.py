
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from collections import namedtuple

import tensorflow as tf
from tensorflow.python.util import nest  # pylint: disable=E0611

from seq2seq.inference import beam_search_2_text as beam_search
from seq2seq.decoders.rnn_decoder import RNNDecoder

from tensorflow.python.ops import math_ops
from tensorflow.python.framework import tensor_shape, tensor_util, ops
from tensorflow.python.ops import tensor_array_ops
from tensorflow.python.framework import tensor_shape

from seq2seq.contrib.seq2seq.decoder import dynamic_decode_beam_search_doc ,\
    _transpose_batch_time
from seq2seq.contrib.seq2seq.decoder import dynamic_decode_beam_search_sent

class FinalBeamDecoderOutput_Doc(
    namedtuple("FinalBeamDecoderOutput_Doc",
               ["predicted_ids", "original_outputs", "attention_index"])):
  pass
  
  
class FinalBeamDecoderOutput_Sent(
    namedtuple("FinalBeamDecoderOutput_Sent",
               ["predicted_ids", "sent_state", "log_probs", "scores", "attention_index"])):
  pass


class BeamDecoderOutput_Sent(
    namedtuple("BeamDecoderOutput_Sent", [
        "logits", "predicted_ids", "log_probs", "scores", "beam_parent_ids"
    ])):
  pass
  

class BeamDecoderOutput_Doc(
    namedtuple("BeamDecoderOutput_Doc", [
        "predicted_ids", "log_probs", "scores", "beam_parent_ids",
        "original_outputs", "attention_index"
    ])):
  pass


class BeamSearchDecoder_2_Text(RNNDecoder):

  def __init__(self, decoder, config):
    super(BeamSearchDecoder_2_Text, self).__init__(decoder.params, decoder.mode,
                                            decoder.name)
    self.decoder = decoder
    self.config = config
    self.start_ids_doc = tf.fill([config.beam_width_doc],config.sos_token)

  def __call__(self, *args, **kwargs):
    with self.decoder.variable_scope():
      return self._build(*args, **kwargs)

  @property
  def final_output_size_sent(self):
    return FinalBeamDecoderOutput_Sent(
        predicted_ids=tf.TensorShape([self.config.max_sent_len]),
        sent_state=tf.TensorShape([512]),
        log_probs=tf.TensorShape([]),
        scores=tf.TensorShape([]),
        attention_index=tf.TensorShape([]))
    
  @property
  def final_output_type_sent(self):
    return FinalBeamDecoderOutput_Sent(
        predicted_ids=tf.int64,
        sent_state=tf.float32,
        log_probs=tf.float32,
        scores=tf.float32,
        attention_index=tf.int32)

  @property
  def output_size_sent(self):
    return BeamDecoderOutput_Sent(
        logits=self.decoder.vocab_size,
        predicted_ids=tf.TensorShape([]),
        log_probs=tf.TensorShape([]),
        scores=tf.TensorShape([]),
        beam_parent_ids=tf.TensorShape([]))

  @property
  def output_size_doc(self):
    return BeamDecoderOutput_Doc(
        predicted_ids=self.config.max_sent_len,
        log_probs=tf.TensorShape([]),
        scores=tf.TensorShape([]),
        beam_parent_ids=tf.TensorShape([]),
        original_outputs=self.decoder.output_size,
        attention_index=tf.TensorShape([]))

  @property
  def output_dtype_sent(self):
    return BeamDecoderOutput_Sent(
        logits=tf.float32,
        predicted_ids=tf.int64,
        log_probs=tf.float32,
        scores=tf.float32,
        beam_parent_ids=tf.int32)

  @property
  def output_dtype_doc(self):
    return BeamDecoderOutput_Doc(
        predicted_ids=tf.int64,
        log_probs=tf.float32,
        scores=tf.float32,
        beam_parent_ids=tf.int32,
        original_outputs=self.decoder.output_dtype,
        attention_index=tf.int32)

  @property
  def batch_size_sent(self):
    return self.config.beam_width_sent

  @property
  def batch_size_doc(self):
    return self.config.beam_width_doc

  def initialize(self):
      pass
  
  def step(self):
      pass

  def initialize_sent(self, name=None):
    doc_finished = tf.fill([self.batch_size_sent], False)
    sent_finished = tf.fill([self.batch_size_sent], False)
    is_new_sent = tf.constant(False)
    is_new_start = tf.constant(True)
    
    first_inputs = tf.fill([self.config.beam_width_sent], self.config.neod_token)
    first_inputs = self.helper.embedding_fn(first_inputs)
    
    beam_state = beam_search.create_initial_beam_state_sent(config=self.config)

    return (doc_finished, sent_finished, is_new_sent, is_new_start), first_inputs, beam_state

  def initialize_doc(self, name=None):
    #first_inputs = self.decoder.helper.embedding_fn(self.start_ids_doc)
    
    doc_finished = tf.fill([self.batch_size_doc], False)
    sent_finished = tf.fill([self.batch_size_doc], False)
    is_new_sent = tf.constant(True)
    is_new_start = tf.constant(False)
    
    initial_doc_state = self.initial_state
    initial_sent_state = tf.zeros(tf.shape(self.initial_state))
    beam_state = beam_search.create_initial_beam_state_doc(config=self.config)

    return (doc_finished, sent_finished, is_new_sent, is_new_start), \
                ((initial_doc_state, initial_sent_state), beam_state)

  def finalize_doc(self, outputs, final_state):
    # Gather according to beam search result
    predicted_ids = beam_search.gather_tree_doc(outputs.predicted_ids,
                                            outputs.beam_parent_ids)

    outputs = nest.map_structure(lambda x: tf.expand_dims(x, 1), outputs)

    final_outputs = FinalBeamDecoderOutput_Doc(
        predicted_ids=tf.expand_dims(predicted_ids, 1),
        original_outputs=outputs.original_outputs,
        attention_index=outputs.attention_index)

    return final_outputs, final_state

  def finalize_sent(self, outputs, final_state): 
    predicted_ids = beam_search.gather_tree_sent(outputs.predicted_ids,
                                            outputs.beam_parent_ids)
    predicted_ids = _transpose_batch_time(predicted_ids)
    return predicted_ids, outputs.scores, final_state

  def _build(self, initial_state, helper): 
    # Tile initial state
    
    initial_state = nest.map_structure(
        lambda x: tf.tile(x, [self.config.beam_width_doc, 1]), initial_state)
    initial_state.set_shape([self.config.beam_width_doc, None])
    self.decoder._setup(initial_state, helper)  #pylint: disable=W0212
    
    if not self.initial_state:
      self._setup(initial_state, helper)

    scope = tf.get_variable_scope()
    scope.set_initializer(tf.random_uniform_initializer(
        -self.params["init_scale"],
        self.params["init_scale"]))

    maximum_iterations = None
    if self.mode == tf.contrib.learn.ModeKeys.INFER:
      maximum_iterations = self.params["max_decode_length"]

    outputs, final_state = dynamic_decode_beam_search_doc(
        decoder=self,
        output_time_major=True)
    
    return self.finalize_doc(outputs, final_state)
    #return super(BeamSearchDecoder, self)._build(self.decoder.initial_state, self.decoder.helper)

  def _ref_ids(self,ref_ids,depth):
    u_ref_ids,_=tf.unique(ref_ids)
    ref_ids_len=tf.shape(ref_ids)[0]
    u_ref_ids_len=tf.shape(u_ref_ids)[0]
    
    def body(time,indices):
        return time+1, indices+tf.one_hot(indices=u_ref_ids[time], depth=depth, on_value=time+1, off_value=0)
    _,ref_id_indices=tf.while_loop(cond=lambda time,_: time<tf.shape(u_ref_ids)[0], 
                                body=body, 
                                loop_vars=[0,tf.zeros([depth],dtype=tf.int32)])
    
    def out_body(out_time,ta):
        u_ref_id=u_ref_ids[out_time]
        def body(time, occur):
            
            def true_fn():
                return occur+tf.one_hot(indices=ref_ids[time+1], depth=depth, on_value=1, off_value=0)
                
            def false_fn():
                return occur+tf.zeros([depth],dtype=tf.int32)
            
            #occur=tf.cond(tf.equal(ref_ids[time], u_ref_id),true_fn,false_fn)
            '''occur=tf.cond(tf.logical_and(tf.equal(ref_ids[time], u_ref_id), 
                                         tf.logical_and(tf.not_equal(ref_ids[time+1], self.config.unk_token), 
                                                        tf.not_equal(u_ref_id, self.config.unk_token))),
                                         true_fn,false_fn)'''
            unk=self.config.unk_token
            occur=tf.cond(tf.logical_or(tf.not_equal(ref_ids[time], u_ref_id), tf.logical_and(tf.equal(ref_ids[time+1], unk), tf.equal(u_ref_id, unk))),false_fn,true_fn)
                                    #tf.logical_and(tf.not_equal(y[out_time],unk),tf.not_equal(ref_ids[time+1],unk)), 
            
            return time+1,occur
        
        time,occur=tf.while_loop(cond=lambda time,_: time<ref_ids_len-1, 
                                body=body, 
                                loop_vars=[0,tf.zeros([depth],dtype=tf.int32)])
        
        ta=ta.write(out_time, occur)
        
        return out_time+1,ta
    
    ta = tensor_array_ops.TensorArray(
          dtype=tf.int32,
          size=0,
          dynamic_size=True,
          element_shape=tensor_shape.TensorShape(depth))
    
    time, ta=tf.while_loop(cond=lambda time,ta: time<u_ref_ids_len, 
                              body=out_body, 
                              loop_vars=[0,ta])
    occurs=ta.stack()
    occurs.set_shape([None, depth])
    occurs=tf.tile(tf.expand_dims(occurs,0),[self.config.beam_width_sent,1,1])
    
    return ref_id_indices,occurs

  def step_doc(self, time_, state_doc, finished, name=None):
    decoder_state, beam_state_doc = state_doc
    doc_finished, sent_finished, is_new_sent, is_new_start = finished
    
    (decoder_output, decoder_state, _, _) = self.decoder.step(time_, self.decoder.helper.embedding_fn(self.start_ids_doc),
                                                              decoder_state, finished[0:3])
    doc_state_doc, sent_state_doc = decoder_state
    sample_ids = self.decoder.helper.sample(time_, decoder_output.logits, decoder_state)
    
    def _shape(from_shape):
      if not isinstance(from_shape, tensor_shape.TensorShape):
        return tensor_shape.TensorShape(None)
      else:
        return from_shape
    
    def _create_ta(s, d):
      return tensor_array_ops.TensorArray(
          dtype=d,
          size=0,
          dynamic_size=True,
          element_shape=_shape(s))
    
    outputs_ta_doc=nest.map_structure(_create_ta, self.output_size_doc, self.output_dtype_doc)
    
    doc_state_ta_doc = tensor_array_ops.TensorArray(
          dtype=tf.float32,
          size=0,
          dynamic_size=True,
          element_shape=_shape(tf.shape(doc_state_doc)[1]))
    sent_state_ta_doc = tensor_array_ops.TensorArray(
          dtype=tf.float32,
          size=0,
          dynamic_size=True,
          element_shape=_shape(tf.shape(sent_state_doc)[1]))
    beam_state_ta_doc = nest.map_structure(_create_ta,
                                           beam_search.BeamSearchState_Doc(
                                              log_probs=tf.TensorShape([]),
                                              source_visited=_shape(tf.shape(beam_state_doc.source_visited)[1])),
                                           beam_search.BeamSearchState_Doc(
                                                              log_probs=tf.float32,
                                                              source_visited=tf.float32)
                                           )
    doc_finished_ta = tensor_array_ops.TensorArray(
          dtype=tf.bool,
          size=0,
          dynamic_size=True,
          element_shape=tf.TensorShape([]))

    outputs_ta_sent=nest.map_structure(_create_ta, self.final_output_size_sent, self.final_output_type_sent)
    
    def body(time_, outputs_ta_sent, doc_finished_ta):
        sample_id = sample_ids[time_]
        doc_state_doc_1 = doc_state_doc[time_:time_+1]
        sent_state_doc_1 = sent_state_doc[time_:time_+1]
        
        def true_fn():
            output_max=FinalBeamDecoderOutput_Sent(predicted_ids=tf.fill([self.config.max_sent_len], self.config.eod_token), 
                                               sent_state=doc_state_doc[time_], 
                                               log_probs=beam_state_doc.log_probs[time_], 
                                               scores=beam_state_doc.log_probs[time_], 
                                               attention_index=0)
            output_min=FinalBeamDecoderOutput_Sent(predicted_ids=output_max.predicted_ids, 
                                               sent_state=output_max.sent_state, 
                                               log_probs=tf.float32.min, 
                                               scores=tf.float32.min, 
                                               attention_index=output_max.attention_index)
            outputs_ta_sent2=nest.map_structure(lambda ta, output:ta.write(time_ * self.config.search_sents_num , output), outputs_ta_sent, output_max)
            def true_body(time_k, outputs_ta_sent):
                outputs_ta_sent=nest.map_structure(lambda ta, output:ta.write(time_ * self.config.search_sents_num + time_k, output), outputs_ta_sent, output_min)
                return time_k + 1, outputs_ta_sent
            _, outputs_ta_sent3 = tf.while_loop(lambda time_k, _:time_k < self.config.search_sents_num, true_body, loop_vars=[1, outputs_ta_sent2])
            doc_finished_ta2 = doc_finished_ta.write(time_, True)
            
            return time_ + 1, outputs_ta_sent3, doc_finished_ta2
        
        def false_fn():
            source_visited = beam_state_doc.source_visited[time_]
            
            def body_sent(time_k, outputs_ta_sent, source_visited):
                text_scores = decoder_output.text_scores[0] * (1 - source_visited)
                scores = text_scores
                
                _, indices = tf.nn.top_k(scores, k=1)
                index=indices[0]
                
                ref_ids = self.config.source_ids[index]
                source_visited = source_visited + tf.one_hot(index, tf.shape(source_visited)[0], on_value=1., off_value=0.)
                source_visited.set_shape([None])

                ref_id_indices, occurs=self._ref_ids(ref_ids, self.config.vocab_size)
                
                initial_finished, initial_inputs, initial_beam_state = self.initialize_sent()
                initial_beam_state = beam_search.BeamSearchState_Sent(
                      log_probs=tf.fill([self.config.beam_width_sent], beam_state_doc.log_probs[time_]),
                      finished=initial_beam_state.finished,
                      lengths=initial_beam_state.lengths,
                      prev_word_ids=initial_beam_state.prev_word_ids,
                      ref_id_indices=ref_id_indices,
                      occurs=occurs)
                
                outputs, final_state = dynamic_decode_beam_search_sent(
                       decoder=self,
                       output_time_major=True,
                       initial_finished=initial_finished,
                       initial_state=((tf.tile(doc_state_doc_1, [self.config.beam_width_sent, 1]), 
                                       tf.tile(sent_state_doc_1, [self.config.beam_width_sent, 1])), 
                                       initial_beam_state),
                       initial_inputs=initial_inputs)
                
                def extend_ids(predicted_ids):
                    ext=tf.fill([self.config.max_sent_len-tf.shape(predicted_ids)[0]],self.config.sos_token)
                    return tf.concat([predicted_ids, ext], 0)
                    
                predicted_ids, scores, final_state = self.finalize_sent(outputs, final_state)
                decoder_state, beam_state = final_state
                doc_state_sent, sent_state_sent = decoder_state
                output=FinalBeamDecoderOutput_Sent(predicted_ids=extend_ids(predicted_ids[0]), sent_state=sent_state_sent[0], log_probs=beam_state.log_probs[0], 
                                                   scores=beam_state.log_probs[0], attention_index=index)
                
                outputs_ta_sent=nest.map_structure(lambda ta, output:ta.write(time_ * self.config.search_sents_num + time_k, output), outputs_ta_sent, output)
                
                return time_k + 1, outputs_ta_sent, source_visited
            
            _, outputs_ta_sent2, _= tf.while_loop(lambda time_k, _1, _2: time_k<self.config.search_sents_num, 
                                                      body=body_sent, 
                                                      loop_vars=[0, outputs_ta_sent, source_visited])
            
            doc_finished_ta2 = doc_finished_ta.write(time_, False)
            
            return time_ + 1, outputs_ta_sent2, doc_finished_ta2
        
        time_, outputs_ta_sent, doc_finished_ta = \
                tf.cond(tf.logical_or(doc_finished[time_], tf.equal(sample_id, self.config.eod_token)), true_fn, false_fn)
        
        return time_, outputs_ta_sent, doc_finished_ta
    
    _, outputs_ta_sent, doc_finished_ta = tf.while_loop(lambda time_, _0, _1: tf.less(time_, self.config.beam_width_doc), 
                                       body, 
                                       loop_vars=[0, outputs_ta_sent, doc_finished_ta])
    
    sent_outputs = nest.map_structure(lambda ta: ta.stack(), outputs_ta_sent)
    _, indices = tf.nn.top_k(sent_outputs.scores, k = self.config.beam_width_doc)
    
    def body_final(k, outputs_ta_doc, doc_state_ta_doc, sent_state_ta_doc, beam_state_ta_doc):
        decoder_state, beam_state_doc = state_doc
        index=indices[k]
        beam_index=tf.div(index, self.config.search_sents_num)
        output = BeamDecoderOutput_Doc(
            predicted_ids=sent_outputs.predicted_ids[index],
            log_probs=sent_outputs.log_probs[index],
            scores=sent_outputs.scores[index],
            beam_parent_ids=beam_index,
            original_outputs=nest.map_structure(lambda decoder_output: decoder_output[beam_index], decoder_output),
            attention_index=sent_outputs.attention_index[index])
        
        doc_state_ta_doc = doc_state_ta_doc.write(k, doc_state_doc[beam_index])
        sent_state_ta_doc = sent_state_ta_doc.write(k, sent_outputs.sent_state[index])
        outputs_ta_doc = nest.map_structure(lambda outputs_ta_doc, output: outputs_ta_doc.write(k, output), outputs_ta_doc, output)
        
        source_visited = beam_state_doc.source_visited[beam_index]                
        source_visited2 =source_visited + tf.one_hot(index, tf.shape(source_visited)[0], on_value=1., off_value=0.)
        source_visited2.set_shape([None])

        beam_state_doc = beam_search.BeamSearchState_Doc(
                log_probs = sent_outputs.log_probs[index],
                source_visited = source_visited2)
        beam_state_ta_doc2 = nest.map_structure(lambda ta, out: ta.write(k,out), beam_state_ta_doc, beam_state_doc)
        
        return k + 1, outputs_ta_doc, doc_state_ta_doc, sent_state_ta_doc, beam_state_ta_doc2

    _, outputs_ta_doc, doc_state_ta_doc, sent_state_ta_doc, beam_state_ta_doc = tf.while_loop(
                            lambda k, _1, _2, _3, _4: k < self.config.beam_width_doc,
                            body=body_final, 
                            loop_vars=[0, outputs_ta_doc, doc_state_ta_doc, sent_state_ta_doc, beam_state_ta_doc])
    doc_outputs = nest.map_structure(lambda ta: ta.stack(), outputs_ta_doc)
    doc_state_doc = doc_state_ta_doc.stack()
    doc_state_doc.set_shape([self.config.beam_width_doc,None])
    sent_state_doc = sent_state_ta_doc.stack()
    sent_state_doc.set_shape([self.config.beam_width_doc,None])
    beam_state_doc = nest.map_structure(lambda ta: ta.stack(), beam_state_ta_doc)
    beam_state_doc.log_probs.set_shape([self.config.beam_width_doc])
    beam_state_doc.source_visited.set_shape([self.config.beam_width_doc,None])
    doc_finished = doc_finished_ta.stack()
    doc_finished.set_shape([self.config.beam_width_doc])
    
    return doc_outputs, ((doc_state_doc, sent_state_doc), beam_state_doc), \
            (doc_finished, sent_finished, is_new_sent, is_new_start)


  def step_sent(self, time_, inputs, state, finished, name=None):
    decoder_state, beam_state = state
    _, _, is_new_sent, is_new_start = finished
    
    (decoder_output, decoder_state, _, _) = self.decoder.step(time_, inputs,
                                                              decoder_state, finished[0:3])
    
    bs_output, beam_state = beam_search.beam_search_step_sent(
        is_new_start=is_new_start,
        logits=decoder_output.logits,
        inputs=inputs,
        beam_state=beam_state,
        config=self.config)

    decoder_state = nest.map_structure(
        lambda x: tf.gather(x, bs_output.beam_parent_ids), decoder_state)
    decoder_output = nest.map_structure(
        lambda x: tf.gather(x, bs_output.beam_parent_ids), decoder_output)

    next_state = (decoder_state, beam_state)

    outputs = BeamDecoderOutput_Sent(
        logits=decoder_output.logits,
        predicted_ids=bs_output.predicted_ids,
        log_probs=beam_state.log_probs,
        scores=bs_output.scores,
        beam_parent_ids=bs_output.beam_parent_ids)

    finished, next_inputs, next_state = self.decoder.helper.next_inputs(
        time=time_,
        outputs=decoder_output,
        state=next_state,
        sample_ids=bs_output.predicted_ids)
    
    next_inputs.set_shape([self.config.beam_width_sent, None])

    return (outputs, next_state, next_inputs, finished)



