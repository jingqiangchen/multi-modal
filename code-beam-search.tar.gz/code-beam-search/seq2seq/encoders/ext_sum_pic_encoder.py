from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import copy
import tensorflow as tf
from tensorflow.contrib.rnn.python.ops import rnn

from seq2seq.encoders.encoder import Encoder, EncoderOutput
from seq2seq.training import utils as training_utils
from tensorflow.contrib.rnn.python.ops.rnn import stack_bidirectional_dynamic_rnn
import seq2seq.encoders.encoder


def _unpack_cell(cell):
  if isinstance(cell, tf.contrib.rnn.MultiRNNCell):
    return cell._cells  #pylint: disable=W0212
  else:
    return [cell]


def _default_rnn_cell_params():
  return {
      "cell_class": "BasicLSTMCell",
      "cell_params": {
          "num_units": 128
      },
      "dropout_input_keep_prob": 1.0,
      "dropout_output_keep_prob": 1.0,
      "num_layers": 1,
      "residual_connections": False,
      "residual_combiner": "add",
      "residual_dense": False
  }


def _toggle_dropout(cell_params, mode):
  cell_params = copy.deepcopy(cell_params)
  if mode != tf.contrib.learn.ModeKeys.TRAIN:
    cell_params["dropout_input_keep_prob"] = 1.0
    cell_params["dropout_output_keep_prob"] = 1.0
  return cell_params
    
    
class ExtSumPicRNNEncoder(Encoder):
  def __init__(self, params, mode, name="ext_sum_pic_rnn_encoder"):
    super(ExtSumPicRNNEncoder, self).__init__(params, mode, name)
    self.params["sent_rnn_cell"] = _toggle_dropout(self.params["sent_rnn_cell"], mode)
    self.params["doc_rnn_cell"] = _toggle_dropout(self.params["doc_rnn_cell"], mode)

  @staticmethod
  def default_params():
    return {
        "sent_rnn_cell": _default_rnn_cell_params(),
        "doc_rnn_cell": _default_rnn_cell_params(),
        "init_scale": 0.04,
    }

  def encode(self, source_embedded, features, **kwargs):
    sent_length=features['source_sents_length']
    doc_length=features['source_doc_length']
    sent_hidden_size=self.params['sent_rnn_cell']['cell_params']['num_units']
    doc_hidden_size=self.params['doc_rnn_cell']['cell_params']['num_units']
    
    scope = tf.get_variable_scope()
    scope.set_initializer(tf.random_uniform_initializer(
        -self.params["init_scale"],
        self.params["init_scale"]))

    sent_cell_fw = training_utils.get_rnn_cell(**self.params["sent_rnn_cell"])
    sent_cell_bw = training_utils.get_rnn_cell(**self.params["sent_rnn_cell"])
    
    shape=tf.shape(source_embedded)
    source_embedded=tf.reshape(source_embedded,[-1,shape[2],sent_hidden_size])
    sent_length_reshape=tf.reshape(sent_length,[-1])
    sent_outputs,sent_fw,sent_bw=stack_bidirectional_dynamic_rnn(
        [sent_cell_fw],[sent_cell_bw],
        source_embedded,
        sequence_length=sent_length_reshape,
        dtype=tf.float32,
        scope='sent_encoder')
    
    sent_final_state_concat = tf.concat([sent_fw, sent_bw], 2)
    
    doc_cell_fw = training_utils.get_rnn_cell(**self.params["doc_rnn_cell"])
    doc_cell_bw = training_utils.get_rnn_cell(**self.params["doc_rnn_cell"])
    
    doc_input=tf.reshape(sent_final_state_concat,[shape[0],-1,doc_hidden_size])
    doc_outputs,doc_fw,doc_bw=stack_bidirectional_dynamic_rnn(
        [doc_cell_fw],[doc_cell_bw],
        doc_input,
        sequence_length=doc_length,
        dtype=tf.float32,
        scope='doc_encoder')
    doc_final_state_concat = tf.concat([doc_fw,doc_bw], 2)
    
    return EncoderOutput(
        outputs=sent_final_state_concat,
        final_state=doc_final_state_concat,
        attention_values=sent_final_state_concat,
        attention_values_length=doc_length,
        image_tokens=features['image_tokens'],
        image_len=features['image_len'])




