
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from collections import namedtuple
import numpy as np

from tensorflow.python.framework import tensor_shape
from tensorflow.python.ops import tensor_array_ops

import tensorflow as tf
from tensorflow.python.util import nest  # pylint: disable=E0611


class BeamSearchState(
    namedtuple("BeamSearchState", ["log_probs", "finished", "lengths", 
                                   "prev_word_ids", "ref_ids", "ref_id_visiteds", "source_visited", "image_visited"])):
  """State for a single step of beam search.

  Args:
    log_probs: The current log probabilities of all beams
    finished: A boolean vector that specifies which beams are finished
    lengths: Lengths of all beams
  """
  pass


class BeamSearchStepOutput(
    namedtuple("BeamSearchStepOutput",
               ["scores", "predicted_ids", "beam_parent_ids"])):
  """Outputs for a single step of beam search.

  Args:
    scores: Score for each beam, a float32 vector
    predicted_ids: predictions for this step step, an int32 vector
    beam_parent_ids: an int32 vector containing the beam indices of the
      continued beams from the previous step
  """
  pass


class BeamSearchConfig(
    namedtuple("BeamSearchConfig", [
        "beam_width", "vocab_size", "eos_token", "eod_token", "neod_token", "unk_token", "sos_token",
        "length_penalty_weight", "choose_successors_fn", "source_ids", "caption_ids", "bigram_award"
    ])):
  """Configuration object for beam search.

  Args:
    beam_width: Number of beams to use, an integer
    vocab_size: Output vocabulary size
    eos_token: The id of the EOS token, used to mark beams as "done"
    length_penalty_weight: Weight for the length penalty factor. 0.0 disables
      the penalty.
    choose_successors_fn: A function used to choose beam successors based
      on their scores. Maps from (scores, config) => (chosen scores, chosen_ids)
  """
  pass


def gather_tree_py(values, parents):
  """Gathers path through a tree backwards from the leave nodes. Used
  to reconstruct beams given their parents."""
  beam_length = values.shape[0]
  num_beams = values.shape[1]
  res = np.zeros_like(values)
  res[-1, :] = values[-1, :]
  for beam_id in range(num_beams):
    parent = parents[-1][beam_id]
    for level in reversed(range(beam_length - 1)):
      res[level, beam_id] = values[level][parent]
      parent = parents[level][parent]
  return np.array(res).astype(values.dtype)


def gather_tree(values, parents):
  """Tensor version of gather_tree_py"""
  res = tf.py_func(
      func=gather_tree_py, inp=[values, parents], Tout=values.dtype)
  res.set_shape(values.get_shape().as_list())
  return res


def create_initial_beam_state(config):
  """Creates an instance of `BeamState` that can be used on the first
  call to `beam_step`.

  Args:
    config: A BeamSearchConfig

  Returns: 
    An instance of `BeamState`.
  """
  source_shape=tf.shape(config.source_ids)
  caption_shape=tf.shape(config.caption_ids)

  return BeamSearchState(
      log_probs=tf.zeros([config.beam_width]),
      finished=tf.zeros([config.beam_width], dtype=tf.bool),
      lengths=tf.zeros([config.beam_width], dtype=tf.int32),
      prev_word_ids=tf.fill([config.beam_width], config.sos_token),
      ref_ids=tf.zeros([source_shape[1]], tf.int64),
      ref_id_visiteds=tf.fill([config.beam_width,source_shape[1]], False),
      source_visited=tf.zeros([source_shape[0]], dtype=tf.float32),
      image_visited=tf.zeros([caption_shape[0]], dtype=tf.float32))


def length_penalty(sequence_lengths, penalty_factor):
  """Calculates the length penalty according to
  https://arxiv.org/abs/1609.08144

   Args:
    sequence_lengths: The sequence length of all hypotheses, a tensor
      of shape [beam_size, vocab_size].
    penalty_factor: A scalar that weights the length penalty.

  Returns:
    The length penalty factor, a tensor fo shape [beam_size].
   """
  return tf.div((5. + tf.to_float(sequence_lengths))**penalty_factor, (5. + 1.)
                **penalty_factor)


def has_bigram(ref_ids, prev_word_ids,vocab_size,unk_token):
    
    def out_body(out_time,ta):
        def body(time, sign):
            def true_fn():
                return tf.one_hot(indices=ref_ids[time+1], depth=vocab_size, on_value=1., off_value=0.)
            def false_fn():
                return tf.zeros([vocab_size])
            new_sign=tf.cond(tf.logical_and(
                                    tf.logical_and(tf.not_equal(prev_word_ids[out_time],unk_token),tf.not_equal(ref_ids[time+1],unk_token)), 
                                    tf.equal(ref_ids[time], prev_word_ids[out_time])),
                                true_fn,false_fn)
            return time+1,sign+new_sign
            
        _,sign=tf.while_loop(cond=lambda time,sign: time<tf.shape(ref_ids)[0]-1, 
                                body=body, 
                                loop_vars=[0,tf.zeros([vocab_size])])
        
        ta=ta.write(out_time, sign)
        return out_time+1,ta
    
    ta = tensor_array_ops.TensorArray(
          dtype=tf.float32,
          size=0,
          dynamic_size=True,
          element_shape=tensor_shape.TensorShape(vocab_size))
    prev_word_count=tf.shape(prev_word_ids)[0]
    _,ta=tf.while_loop(cond=lambda time,ta:time<prev_word_count, 
                              body=out_body, 
                              loop_vars=[0,ta])
    output=ta.stack()
    shape=tf.shape(output)
    output=tf.where(output>0, tf.ones(shape), tf.zeros(shape))
    return output

def hyp_score(log_probs, sequence_lengths, ref_ids, prev_word_ids, config):
  """Calculates scores for beam search hypotheses.
  """

  # Calculate the length penality
  '''length_penality_ = length_penalty(
      sequence_lengths=sequence_lengths,
      penalty_factor=config.length_penalty_weight)

  score = log_probs * length_penality_'''
  
  def true_fn():
      return 0.
  def false_fn():
      return has_bigram(ref_ids, prev_word_ids, config.vocab_size, config.unk_token) * config.bigram_award
  
  bigram_awards=tf.cond(tf.equal(prev_word_ids[0],config.sos_token), true_fn, false_fn)

  score = log_probs + bigram_awards
  #score.set_shape([config.beam_width, None])
  
  return score

def has_bigram_2(ref_ids, prev_word_ids,vocab_size,unk_token,eos_token,ref_id_visiteds):
    
    def out_body(out_time,ta,visited_ta):
        ref_id_visited=ref_id_visiteds[out_time]
        def body(time, sign, found, ref_id_visited):
            
            def true_fn():
                return tf.one_hot(indices=ref_ids[time+1], depth=vocab_size, on_value=1., off_value=0.), tf.constant(True), \
                            tf.logical_or(ref_id_visited,tf.one_hot(indices=time+1, depth=tf.shape(ref_id_visited)[0], on_value=True, off_value=False))
            
            def false_fn():
                return tf.zeros([vocab_size]), tf.constant(False), ref_id_visited
            
            new_sign, found, ref_id_visited=tf.cond(tf.logical_and(
                                    tf.logical_and(tf.not_equal(prev_word_ids[out_time],unk_token),tf.not_equal(ref_ids[time+1],unk_token)), 
                                    tf.logical_and(tf.logical_not(ref_id_visited[time+1]),
                                    tf.equal(ref_ids[time], prev_word_ids[out_time]))),
                             true_fn,false_fn)
            
            return time+1,sign+new_sign,found,ref_id_visited
            
        time,sign,_,ref_id_visited=tf.while_loop(cond=lambda time,sign,found,_: tf.logical_and(
            tf.logical_and(time<tf.shape(ref_ids)[0]-1,tf.logical_not(found)), 
            tf.not_equal(ref_ids[time],eos_token)
            ), 
                                body=body, 
                                loop_vars=[0,tf.zeros([vocab_size]),tf.constant(False),ref_id_visited])
        
        ta=ta.write(out_time, sign)
        visited_ta=visited_ta.write(out_time, ref_id_visited)
        return out_time+1,ta,visited_ta
    
    ta = tensor_array_ops.TensorArray(
          dtype=tf.float32,
          size=0,
          dynamic_size=True,
          element_shape=tensor_shape.TensorShape(vocab_size))
    visited_ta = tensor_array_ops.TensorArray(
          dtype=tf.bool,
          size=0,
          dynamic_size=True,
          element_shape=ref_ids.get_shape())
    prev_word_count=tf.shape(prev_word_ids)[0]
    time, ta, visited_ta=tf.while_loop(cond=lambda time,ta,_:time<prev_word_count, 
                              body=out_body, 
                              loop_vars=[0,ta,visited_ta])
    '''time, ta, visited_ta=tf.while_loop(cond=lambda time,ta,_: time<tf.shape(ref_ids)[0]-1, 
                              body=out_body, 
                              loop_vars=[0,ta,visited_ta])'''
    output=ta.stack()
    visited=visited_ta.stack()
    visited.set_shape([5, None])
    return output, visited

def hyp_score_2(log_probs, sequence_lengths, ref_ids, prev_word_ids, config, ref_id_visiteds):
  
  def true_fn():
      return 0.,ref_id_visiteds
  
  def false_fn():
      output, visited = has_bigram_2(ref_ids, prev_word_ids, config.vocab_size, config.unk_token,config.eos_token,ref_id_visiteds)
      return output * config.bigram_award, visited
  
  bigram_awards,ref_id_visiteds=tf.cond(tf.equal(prev_word_ids[0],config.sos_token), true_fn, false_fn)

  score = log_probs + bigram_awards
  #score.set_shape([config.beam_width, None])
  
  return score, ref_id_visiteds

def choose_top_k(scores_flat, config):
  """Chooses the top-k beams as successors.
  """
  next_beam_scores, word_indices = tf.nn.top_k(scores_flat, k=config.beam_width)
  return next_beam_scores, word_indices


def nest_map(inputs, map_fn, name=None):
  """Applies a function to (possibly nested) tuple of tensors.
  """
  if nest.is_sequence(inputs):
    inputs_flat = nest.flatten(inputs)
    y_flat = [map_fn(_) for _ in inputs_flat]
    outputs = nest.pack_sequence_as(inputs, y_flat)
  else:
    outputs = map_fn(inputs)
  if name:
    outputs = tf.identity(outputs, name=name)
  return outputs


def mask_probs(probs, eos_token, finished):
  """Masks log probabilities such that finished beams
  allocate all probability mass to eos. Unfinished beams remain unchanged.

  Args:
    probs: Log probabiltiies of shape `[beam_width, vocab_size]`
    eos_token: An int32 id corresponding to the EOS token to allocate
      probability to
    finished: A boolean tensor of shape `[beam_width]` that specifies which
      elements in the beam are finished already.

  Returns:
    A tensor of shape `[beam_width, vocab_size]`, where unfinished beams
    stay unchanged and finished beams are replaced with a tensor that has all
    probability on the EOS token.
  """
  vocab_size = tf.shape(probs)[1]
  finished_mask = tf.expand_dims(tf.to_float(1. - tf.to_float(finished)), 1)
  # These examples are not finished and we leave them
  non_finished_examples = finished_mask * probs
  # All finished examples are replaced with a vector that has all
  # probability on EOS
  finished_row = tf.one_hot(
      eos_token,
      vocab_size,
      dtype=tf.float32,
      on_value=0.,
      off_value=tf.float32.min)
  finished_examples = (1. - finished_mask) * finished_row
  return finished_examples + non_finished_examples


def beam_search_step(is_new_start, inputs, logits, beam_state, config):
  """Performs a single step of Beam Search Decoding.

  Args:
    time_: Beam search time step, should start at 0. At time 0 we assume
      that all beams are equal and consider only the first beam for
      continuations.
    logits: Logits at the current time step. A tensor of shape `[B, vocab_size]`
    beam_state: Current state of the beam search. An instance of `BeamState`
    config: An instance of `BeamSearchConfig`

  Returns:
    A new beam state.
  """

  # Calculate the current lengths of the predictions
  prediction_lengths = beam_state.lengths
  previously_finished = beam_state.finished

  # Calculate the total log probs for the new hypotheses
  # Final Shape: [beam_width, vocab_size]
  '''scores_mask = tf.sequence_mask(
        lengths=tf.constant([40003,40003,40003,40003,40003],tf.int32),
        maxlen=40004,
        dtype=tf.float32)
  logits = logits * scores_mask'''
  
  probs = tf.nn.log_softmax(logits)
  
  probs = mask_probs(probs, config.eos_token, previously_finished)
  total_probs = tf.expand_dims(beam_state.log_probs, 1) + probs

  # Calculate the continuation lengths
  # We add 1 to all continuations that are not EOS and were not
  # finished previously
  lengths_to_add = tf.one_hot([config.eos_token] * config.beam_width,
                              config.vocab_size, 0, 1)
  add_mask = (1 - tf.to_int32(previously_finished))
  lengths_to_add = tf.expand_dims(add_mask, 1) * lengths_to_add
  new_prediction_lengths = tf.expand_dims(prediction_lengths, 1) + lengths_to_add

  # Calculate the scores for each beam
  scores, ref_id_visiteds = hyp_score_2(
      log_probs=total_probs,
      sequence_lengths=new_prediction_lengths,
      ref_ids=beam_state.ref_ids,
      prev_word_ids=beam_state.prev_word_ids, 
      config=config,
      ref_id_visiteds=beam_state.ref_id_visiteds)
  #print(is_new_start)
  scores_flat = tf.reshape(scores, [-1])
  # During the first time step we only consider the initial beam
  scores_flat = tf.cond(
      is_new_start, lambda: scores[0], lambda: scores_flat)

  # Pick the next beams according to the specified successors function
  next_beam_scores, word_indices = config.choose_successors_fn(scores_flat,
                                                               config)
  next_beam_scores.set_shape([config.beam_width])
  word_indices.set_shape([config.beam_width])

  # Pick out the probs, beam_ids, and states according to the chosen predictions
  total_probs_flat = tf.reshape(total_probs, [-1], name="total_probs_flat")
  next_beam_probs = tf.gather(total_probs_flat, word_indices)
  next_beam_probs.set_shape([config.beam_width])
  next_word_ids = tf.to_int64(tf.mod(word_indices, config.vocab_size))
  next_beam_ids = tf.div(word_indices, config.vocab_size)
  next_word_ids.set_shape([config.beam_width])
  next_beam_ids.set_shape([config.beam_width])

  # Append new ids to current predictions
  next_finished = tf.logical_or(
      tf.gather(beam_state.finished, next_beam_ids),
      tf.equal(next_word_ids, config.eos_token))
  next_finished.set_shape([config.beam_width])

  # Calculate the length of the next predictions.
  # 1. Finished beams remain unchanged
  # 2. Beams that are now finished (EOS predicted) remain unchanged
  # 3. Beams that are not yet finished have their length increased by 1
  lengths_to_add = tf.to_int32(tf.not_equal(next_word_ids, config.eos_token))
  lengths_to_add = (1 - tf.to_int32(next_finished)) * lengths_to_add
  next_prediction_len = tf.gather(beam_state.lengths, next_beam_ids)
  next_prediction_len += lengths_to_add
  next_prediction_len.set_shape([config.beam_width])

  next_state = BeamSearchState(
      log_probs=next_beam_scores,
      lengths=next_prediction_len,
      finished=next_finished,
      prev_word_ids=next_word_ids, 
      ref_ids=beam_state.ref_ids, 
      ref_id_visiteds=ref_id_visiteds, 
      source_visited=beam_state.source_visited, 
      image_visited=beam_state.image_visited)

  output = BeamSearchStepOutput(
      scores=next_beam_scores,
      predicted_ids=next_word_ids,
      beam_parent_ids=next_beam_ids)

  return output, next_state
