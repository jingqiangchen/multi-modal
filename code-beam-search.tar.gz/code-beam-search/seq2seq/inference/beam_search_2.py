
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from collections import namedtuple
import numpy as np

from tensorflow.python.framework import tensor_shape
from tensorflow.python.ops import tensor_array_ops

import tensorflow as tf
from tensorflow.python.util import nest  # pylint: disable=E0611


class BeamSearchState_Sent(
    namedtuple("BeamSearchState", ["log_probs", "finished", "lengths", "prev_word_ids", "ref_id_indices", "occurs"])):
  pass
  
class BeamSearchState_Doc(
    namedtuple("BeamSearchState_Doc", ["log_probs", "source_visited", "image_visited"])):
  pass


class BeamSearchStepOutput(
    namedtuple("BeamSearchStepOutput",
               ["scores", "predicted_ids", "beam_parent_ids"])):
  pass


class BeamSearchConfig(
    namedtuple("BeamSearchConfig", [
        "beam_width_doc", "beam_width_sent", "vocab_size", "eos_token", "eod_token", "neod_token", "unk_token", "sos_token",
        "length_penalty_weight", "choose_successors_fn", "source_ids", "caption_ids", "bigram_award", "search_sents_num", "max_sent_len"
    ])):
  pass


def gather_tree_py_doc(values, parents):
  """Gathers path through a tree backwards from the leave nodes. Used
  to reconstruct beams given their parents."""
  beam_length = values.shape[0]
  num_beams = values.shape[1]
  res = np.zeros_like(values)
  res[-1, :] = values[-1, :]
  for beam_id in range(num_beams):
    parent = parents[-1][beam_id]
    for level in reversed(range(beam_length - 1)):
      res[level, beam_id] = values[level][parent]
      parent = parents[level][parent]
  return np.array(res).astype(values.dtype)


def gather_tree_doc(values, parents):
  res = tf.py_func(
      func=gather_tree_py_doc, inp=[values, parents], Tout=values.dtype)
  res.set_shape(values.get_shape().as_list())
  return res


def gather_tree_py_sent(values, parents):
  """Gathers path through a tree backwards from the leave nodes. Used
  to reconstruct beams given their parents."""
  beam_length = values.shape[0]
  num_beams = values.shape[1]
  res = np.zeros_like(values)
  res[-1, :] = values[-1, :]
  for beam_id in range(num_beams):
    parent = parents[-1][beam_id]
    for level in reversed(range(beam_length - 1)):
      res[level, beam_id] = values[level][parent]
      parent = parents[level][parent]
  return np.array(res).astype(values.dtype)


def gather_tree_sent(values, parents):
  res = tf.py_func(
      func=gather_tree_py_sent, inp=[values, parents], Tout=values.dtype)
  res.set_shape(values.get_shape().as_list())
  return res


def create_initial_beam_state_doc(config):
  source_shape=tf.shape(config.source_ids)
  caption_shape=tf.shape(config.caption_ids)

  return BeamSearchState_Doc(
      log_probs=tf.zeros([config.beam_width_doc]),
      #finished=tf.zeros([config.beam_width_doc], dtype=tf.bool),
      #lengths=tf.zeros([config.beam_width_doc], dtype=tf.int32),
      source_visited=tf.zeros([config.beam_width_doc, source_shape[0]], dtype=tf.float32),
      image_visited=tf.zeros([config.beam_width_doc, caption_shape[0]], dtype=tf.float32))


def create_initial_beam_state_sent(config):
  source_shape=tf.shape(config.source_ids)
  caption_shape=tf.shape(config.caption_ids)

  return BeamSearchState_Sent(
      log_probs=tf.zeros([config.beam_width_sent]),
      finished=tf.zeros([config.beam_width_sent], dtype=tf.bool),
      lengths=tf.zeros([config.beam_width_sent], dtype=tf.int32),
      prev_word_ids=tf.fill([config.beam_width_sent], config.sos_token),
      ref_id_indices=tf.zeros([config.vocab_size], tf.int64),
      occurs=tf.zeros([source_shape[1],config.vocab_size],dtype=tf.int32))


def length_penalty(sequence_lengths, penalty_factor):
  """Calculates the length penalty according to
  https://arxiv.org/abs/1609.08144

   Args:
    sequence_lengths: The sequence length of all hypotheses, a tensor
      of shape [beam_size, vocab_size].
    penalty_factor: A scalar that weights the length penalty.

  Returns:
    The length penalty factor, a tensor fo shape [beam_size].
   """
  return tf.div((5. + tf.to_float(sequence_lengths))**penalty_factor, (5. + 1.)
                **penalty_factor)
  
  
def has_bigram_2(ref_id_indices, occurs, prev_word_ids,vocab_size,unk_token,eos_token):
    
    prev_word_ids_len=tf.shape(prev_word_ids)[0]
    ta = tensor_array_ops.TensorArray(
          dtype=tf.int32,
          size=0,
          dynamic_size=True,
          element_shape=tensor_shape.TensorShape(vocab_size))
    def body(time,ta):
        prev_word_id=prev_word_ids[time]
        index=ref_id_indices[prev_word_id]-1
        occur=tf.cond(index>-1,lambda:occurs[time][index],lambda:tf.zeros([vocab_size],dtype=tf.int32))
        ta=ta.write(time, occur)
        return time+1,ta
    time, ta=tf.while_loop(cond=lambda time,_: time<prev_word_ids_len, 
                              body=body, 
                              loop_vars=[0,ta])
    occ=ta.stack()
    occ=tf.to_int32(tf.greater(occ,0))
    
    return occ

def hyp_score_2(log_probs, sequence_lengths, ref_id_indices, occurs, prev_word_ids, config):
  
  def true_fn():
      return 0.
  
  def false_fn():
      output = has_bigram_2(ref_id_indices, occurs, prev_word_ids, config.vocab_size, config.unk_token,config.eos_token)
      output = tf.to_float(tf.greater(output,0))
      return output * config.bigram_award
  
  bigram_awards=tf.cond(tf.equal(prev_word_ids[0],config.sos_token), true_fn, false_fn)

  score = log_probs + bigram_awards
  #score.set_shape([config.beam_width, None])
  
  return score


def choose_top_k(scores_flat, config):
  """Chooses the top-k beams as successors.
  """
  next_beam_scores, word_indices = tf.nn.top_k(scores_flat, k=config.beam_width_sent)
  return next_beam_scores, word_indices


def nest_map(inputs, map_fn, name=None):
  """Applies a function to (possibly nested) tuple of tensors.
  """
  if nest.is_sequence(inputs):
    inputs_flat = nest.flatten(inputs)
    y_flat = [map_fn(_) for _ in inputs_flat]
    outputs = nest.pack_sequence_as(inputs, y_flat)
  else:
    outputs = map_fn(inputs)
  if name:
    outputs = tf.identity(outputs, name=name)
  return outputs


def mask_probs(probs, eos_token, finished):
  """Masks log probabilities such that finished beams
  allocate all probability mass to eos. Unfinished beams remain unchanged.

  Args:
    probs: Log probabiltiies of shape `[beam_width, vocab_size]`
    eos_token: An int32 id corresponding to the EOS token to allocate
      probability to
    finished: A boolean tensor of shape `[beam_width]` that specifies which
      elements in the beam are finished already.

  Returns:
    A tensor of shape `[beam_width, vocab_size]`, where unfinished beams
    stay unchanged and finished beams are replaced with a tensor that has all
    probability on the EOS token.
  """
  vocab_size = tf.shape(probs)[1]
  finished_mask = tf.expand_dims(tf.to_float(1. - tf.to_float(finished)), 1)
  # These examples are not finished and we leave them
  non_finished_examples = finished_mask * probs
  # All finished examples are replaced with a vector that has all
  # probability on EOS
  finished_row = tf.one_hot(
      eos_token, 
      vocab_size,
      dtype=tf.float32,
      on_value=0.,
      off_value=tf.float32.min)
  finished_examples = (1. - finished_mask) * finished_row
  return finished_examples + non_finished_examples
  
  
def beam_search_step_sent(is_new_start, inputs, logits, beam_state, config):

  # Calculate the current lengths of the predictions
  prediction_lengths = beam_state.lengths
  previously_finished = beam_state.finished
  
  probs = tf.nn.log_softmax(logits)
  
  probs = mask_probs(probs, config.eos_token, previously_finished)
  total_probs = tf.expand_dims(beam_state.log_probs, 1) + probs

  # Calculate the continuation lengths
  # We add 1 to all continuations that are not EOS and were not
  # finished previously
  lengths_to_add = tf.one_hot([config.eos_token] * config.beam_width_sent,
                              config.vocab_size, 0, 1)
  add_mask = (1 - tf.to_int32(previously_finished))
  lengths_to_add = tf.expand_dims(add_mask, 1) * lengths_to_add
  new_prediction_lengths = tf.expand_dims(prediction_lengths, 1) + lengths_to_add

  # Calculate the scores for each beam
  scores = hyp_score_2(
      log_probs=total_probs,
      sequence_lengths=new_prediction_lengths,
      ref_id_indices=beam_state.ref_id_indices,
      occurs=beam_state.occurs,
      prev_word_ids=beam_state.prev_word_ids, 
      config=config)
  #print(is_new_start)
  scores_flat = tf.reshape(scores, [-1])
  # During the first time step we only consider the initial beam
  scores_flat = tf.cond(
      is_new_start, lambda: scores[0], lambda: scores_flat)

  # Pick the next beams according to the specified successors function
  next_beam_scores, word_indices = config.choose_successors_fn(scores_flat,
                                                               config)
  next_beam_scores.set_shape([config.beam_width_sent])
  word_indices.set_shape([config.beam_width_sent])

  # Pick out the probs, beam_ids, and states according to the chosen predictions
  total_probs_flat = tf.reshape(total_probs, [-1], name="total_probs_flat")
  next_beam_probs = tf.gather(total_probs_flat, word_indices)
  next_beam_probs.set_shape([config.beam_width_sent])
  next_word_ids = tf.to_int64(tf.mod(word_indices, config.vocab_size))
  next_beam_ids = tf.div(word_indices, config.vocab_size)
  next_word_ids.set_shape([config.beam_width_sent])
  next_beam_ids.set_shape([config.beam_width_sent])

  # Append new ids to current predictions
  next_finished = tf.logical_or(
      tf.gather(beam_state.finished, next_beam_ids),
      tf.equal(next_word_ids, config.eos_token))
  next_finished.set_shape([config.beam_width_sent])

  # Calculate the length of the next predictions.
  # 1. Finished beams remain unchanged
  # 2. Beams that are now finished (EOS predicted) remain unchanged
  # 3. Beams that are not yet finished have their length increased by 1
  lengths_to_add = tf.to_int32(tf.not_equal(next_word_ids, config.eos_token))
  lengths_to_add = (1 - tf.to_int32(next_finished)) * lengths_to_add
  next_prediction_len = tf.gather(beam_state.lengths, next_beam_ids)
  next_prediction_len += lengths_to_add
  next_prediction_len.set_shape([config.beam_width_sent])

  indices=beam_state.ref_id_indices
  occurs=beam_state.occurs
  prev_word_ids=beam_state.prev_word_ids
  depth=config.vocab_size
  u_ref_ids_len=tf.shape(occurs)[1]
  def body(time,ta):
    prev_word_id=prev_word_ids[time]
    index=indices[prev_word_id]-1
    def true_fn():
        return occurs[time]-tf.concat([tf.zeros([index,depth],dtype=tf.int32),
                                                  tf.expand_dims(tf.one_hot(next_word_ids[time], depth=depth, on_value=1, off_value=0),0),
                                                  tf.zeros([u_ref_ids_len-index-1,depth],dtype=tf.int32)],0)
    def false_fn():
        return occurs[time]
    occur=tf.cond(index>-1,true_fn,false_fn)
    ta=ta.write(time, occur)
    return time+1,ta
  ta = tensor_array_ops.TensorArray(
          dtype=tf.int32,
          size=0,
          dynamic_size=True,
          element_shape=occurs.get_shape()[1:])
  time, ta=tf.while_loop(cond=lambda time,_: time<config.beam_width_sent, 
                              body=body, 
                              loop_vars=[0,ta])
  new_occurs=ta.stack()
  new_occurs.set_shape([config.beam_width_sent,None,config.vocab_size])
  
  next_state = BeamSearchState_Sent(
      log_probs=next_beam_scores,
      lengths=next_prediction_len,
      finished=next_finished,
      prev_word_ids=next_word_ids, 
      ref_id_indices=beam_state.ref_id_indices,
      occurs=new_occurs)

  output = BeamSearchStepOutput(
      scores=next_beam_scores,
      predicted_ids=next_word_ids,
      beam_parent_ids=next_beam_ids)

  return output, next_state
