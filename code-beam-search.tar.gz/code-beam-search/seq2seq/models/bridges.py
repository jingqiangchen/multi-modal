
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import abc
from pydoc import locate

import six
import numpy as np

import tensorflow as tf
from tensorflow.python.util import nest  # pylint: disable=E0611

from seq2seq.configurable import Configurable

import common


def _total_tensor_depth(tensor):
  """Returns the size of a tensor without the first (batch) dimension"""
  return np.prod(tensor.get_shape().as_list()[1:])


@six.add_metaclass(abc.ABCMeta)
class Bridge(Configurable):
  """An abstract bridge class. A bridge defines how state is passed
  between encoder and decoder.

  All logic is contained in the `_create` method, which returns an
  initial state for the decoder.

  Args:
    encoder_outputs: A namedtuple that corresponds to the the encoder outputs.
    decoder_state_size: An integer or tuple of integers defining the
      state size of the decoder.
  """

  def __init__(self, encoder_outputs, decoder_state_size, params, mode):
    Configurable.__init__(self, params, mode)
    self.encoder_outputs = encoder_outputs
    self.decoder_state_size = decoder_state_size
    self.batch_size = tf.shape(
        nest.flatten(self.encoder_outputs.final_state)[0])[0]

  def __call__(self):
    """Runs the bridge function.

    Returns:
      An initial decoder_state tensor or tuple of tensors.
    """
    return self._create()

  @abc.abstractmethod
  def _create(self):
    """ Implements the logic for this bridge.
    This function should be implemented by child classes.

    Returns:
      A tuple initial_decoder_state tensor or tuple of tensors.
    """
    raise NotImplementedError("Must be implemented by child class")


class AbsSumPicBridge_Hie(Bridge):

  def __init__(self, encoder_outputs, decoder_state_size, params, mode):
    super(AbsSumPicBridge_Hie, self).__init__(encoder_outputs,
                                             decoder_state_size, params, mode)
    self._bridge_input = getattr(encoder_outputs, 'final_state')
    self._activation_fn = locate(self.params["activation_fn"])

  @staticmethod
  def default_params():
    return {
        "bridge_input": "final_state",
        "activation_fn": "tensorflow.identity",
    }

  def _create(self):
    doc_final_state = self._bridge_input
    doc_final_state=tf.squeeze(doc_final_state, 0)

    state_size = self.decoder_state_size
    
    initial_state = tf.contrib.layers.fully_connected(
        inputs=doc_final_state,
        num_outputs=state_size,
        activation_fn=self._activation_fn,scope='AbsSumPicBridge_Hie')
    
    return initial_state

class AbsSumPicBridge_Image(Bridge):

  def __init__(self, encoder_outputs, decoder_state_size, params, mode):
    super(AbsSumPicBridge_Image, self).__init__(encoder_outputs,
                                             decoder_state_size, params, mode)
    self._bridge_input = getattr(encoder_outputs, 'final_state')
    self._activation_fn = locate(self.params["activation_fn"])

  @staticmethod
  def default_params():
    return {
        "bridge_input": "final_state",
        "activation_fn": "tensorflow.identity",
    }
    
  '''def _encode_pic_avg(self, image_tokens, image_len):
      shape=tf.shape(image_len)
      ilen=tf.where(tf.equal(image_len,tf.zeros(shape,tf.int32)),tf.ones(shape,tf.int32),image_len)
      return tf.divide(tf.reduce_sum(image_tokens,1),tf.expand_dims(tf.to_float(ilen),1))
  
  def _encode_pic_tanh(self, image_tokens, image_len):
      pass'''

  def _create(self):
    doc_final_state, image_final_state = self._bridge_input
    doc_final_state=tf.squeeze(doc_final_state, 0)
    image_final_state=tf.squeeze(image_final_state, 0)

    state_size = self.decoder_state_size
    
    text_image_concat=tf.concat([doc_final_state,image_final_state],1)
    
    initial_state = tf.contrib.layers.fully_connected(
        inputs=text_image_concat,
        num_outputs=state_size,
        activation_fn=self._activation_fn,scope='AbsSumPicBridge_Image')
    
    return initial_state

class AbsSumPicBridge_Caption(Bridge):

  def __init__(self, encoder_outputs, decoder_state_size, params, mode):
    super(AbsSumPicBridge_Caption, self).__init__(encoder_outputs,
                                             decoder_state_size, params, mode)
    self._bridge_input = getattr(encoder_outputs, 'final_state')
    self._activation_fn = locate(self.params["activation_fn"])

  @staticmethod
  def default_params():
    return {
        "bridge_input": "final_state",
        "activation_fn": "tensorflow.identity",
    }

  def _create(self):
    doc_final_state, caption_final_state = self._bridge_input
    doc_final_state=tf.squeeze(doc_final_state, 0)
    caption_final_state=tf.squeeze(caption_final_state, 0)

    state_size = self.decoder_state_size
    
    text_caption_concat=tf.concat([doc_final_state,caption_final_state],1)
    
    initial_state = tf.contrib.layers.fully_connected(
        inputs=text_caption_concat,
        num_outputs=state_size,
        activation_fn=self._activation_fn,scope='AbsSumPicBridge_Caption')
    
    return initial_state

class AbsSumPicBridge_Image_Caption(Bridge):

  def __init__(self, encoder_outputs, decoder_state_size, params, mode):
    super(AbsSumPicBridge_Image_Caption, self).__init__(encoder_outputs,
                                             decoder_state_size, params, mode)
    self._bridge_input = getattr(encoder_outputs, 'final_state')
    self._activation_fn = locate(self.params["activation_fn"])

  @staticmethod
  def default_params():
    return {
        "bridge_input": "final_state",
        "activation_fn": "tensorflow.identity",
    }

  def _create(self):
    doc_final_state, image_final_state, caption_final_state = self._bridge_input
    doc_final_state=tf.squeeze(doc_final_state, 0)
    image_final_state=tf.squeeze(image_final_state, 0)
    caption_final_state=tf.squeeze(caption_final_state, 0)
    
    text_image_caption_concat=tf.concat([doc_final_state, image_final_state, caption_final_state], 1)

    state_size = self.decoder_state_size
    
    initial_state = tf.contrib.layers.fully_connected(
        inputs=text_image_caption_concat,
        num_outputs=state_size,
        activation_fn=self._activation_fn,
        scope='AbsSumPicBridge_Image_Caption')
    
    return initial_state


class AbsSumPicBridge_Image_Caption_2(Bridge):

  def __init__(self, encoder_outputs, decoder_state_size, params, mode):
    super(AbsSumPicBridge_Image_Caption_2, self).__init__(encoder_outputs,
                                             decoder_state_size, params, mode)
    self._bridge_input = getattr(encoder_outputs, 'final_state')
    self._activation_fn = locate(self.params["activation_fn"])

  @staticmethod
  def default_params():
    return {
        "bridge_input": "final_state",
        "activation_fn": "tensorflow.identity",
    }

  def _create(self):
    doc_final_state, image_final_state = self._bridge_input
    doc_final_state=tf.squeeze(doc_final_state, 0)
    image_final_state=tf.squeeze(image_final_state, 0)
    
    text_image_caption_concat=tf.concat([doc_final_state, image_final_state], 1)

    state_size = self.decoder_state_size
    
    initial_state = tf.contrib.layers.fully_connected(
        inputs=text_image_caption_concat,
        num_outputs=state_size,
        activation_fn=self._activation_fn,
        scope='AbsSumPicBridge_Image_Caption')
    
    return initial_state





