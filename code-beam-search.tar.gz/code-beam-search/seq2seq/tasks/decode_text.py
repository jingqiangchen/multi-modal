
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import functools
from pydoc import locate

import numpy as np

import tensorflow as tf
from tensorflow import gfile

from seq2seq.tasks.inference_task import InferenceTask, unbatch_dict
import seq2seq.data.vocab as vocab
import common

from rouge import Rouge

rouge=Rouge()

def _get_prediction_length(predictions_dict):
  """Returns the length of the prediction based on the index
  of the first SEQUENCE_END token.
  """
  tokens_iter = enumerate(predictions_dict["predicted_tokens"])
  return next(((i + 1) for i, _ in tokens_iter if _ == "SEQUENCE_END"),
              len(predictions_dict["predicted_tokens"]))


def _get_unk_mapping(filename):
  """Reads a file that specifies a mapping from source to target tokens.
  The file must contain lines of the form <source>\t<target>"

  Args:
    filename: path to the mapping file

  Returns:
    A dictionary that maps from source -> target tokens.
  """
  with gfile.GFile(filename, "r") as mapping_file:
    lines = mapping_file.readlines()
    mapping = dict([_.split("\t")[0:2] for _ in lines])
    mapping = {k.strip(): v.strip() for k, v in mapping.items()}
  return mapping


def _unk_replace(source_tokens,
                 caption_tokens,
                 predicted_tokens,
                 attention_index,
                 text_scores,
                 image_scores,
                 caption_scores,
                 has_words,
                 mapping=None):

  result = []
  #print('predicted_tokens')
  for i in range(len(predicted_tokens)):
      token=predicted_tokens[i]
      
      if i == 0 or token == "DOC_NOT_END":
          sign=True
          text_score=text_scores[i]
          image_score=image_scores[i]
          caption_score=caption_scores[i]
          att_index=attention_index[i]
          
          text_score_shape=np.shape(text_score)
          image_score_shape=np.shape(image_score)

          if att_index<text_score_shape[0]:
              att_sent=source_tokens[att_index]
              text_score[att_index]=-1
          else:
              att_index=(att_index-text_score_shape[0]) % image_score_shape[0]
              att_sent=caption_tokens[att_index]
              image_score[att_index]=-1
              caption_score[att_index]=-1
          #print(att_sent)
          new_token_index=0
          result.append(token)
          #print("att_sent: ", ' '.join(att_sent))
      elif token == "UNK":
          while sign and (has_words.has_key(att_sent[new_token_index]) or \
                        att_sent[new_token_index] in ["SEQUENCE_START", "SEQUENCE_END", "DOC_NOT_END", "DOC_END", ""]):
              new_token_index+=1
              #print(new_token_index)
              if new_token_index>=np.shape(att_sent)[0]:
                  scores=np.concatenate([text_score,image_score,caption_score],0)
                  att_index = np.argmax(scores)
                  if att_index<text_score_shape[0]:
                      att_sent=source_tokens[att_index]
                      text_score[att_index]=-1
                  else:
                      att_index=(att_index-text_score_shape[0]) % image_score_shape[0]
                      att_sent=caption_tokens[att_index]
                      image_score[att_index]=-1
                      caption_score[att_index]=-1
                  new_token_index=0
                  if scores[att_index]==-1:
                      sign=False
                      break
                  '''print(att_sent)
                  print(scores[att_index])'''
                  '''print(np.shape(scores))
                  print(scores)
                  print(np.shape(source_tokens))
                  print('\n'.join([str(_) for _ in source_tokens]))
                  print(np.shape(caption_tokens))
                  print('\n'.join([str(_) for _ in caption_tokens]))'''
                  

          if sign:
              new_token=att_sent[new_token_index]
              att_sent[new_token_index]=""
          else:
              new_token="UNK"
          result.append(new_token)
      else:
          result.append(token)
          
  return np.array(result)
  
  
def get_vocab():
    has_words={}
    with gfile.GFile(common.path_vocab) as file:
        for line in file:
            line=line.strip("\n")
            items=line.split("\t")
            has_words[items[0]]=True
    return has_words


class DecodeText(InferenceTask):
    
  score_1=[0.,0.,0.]
  score_2=[0.,0.,0.]
  score_l=[0.,0.,0.]
  score_75_1=[0.,0.,0.]
  score_75_2=[0.,0.,0.]
  score_75_l=[0.,0.,0.]
  score_rep_1=[0.,0.,0.]
  score_rep_2=[0.,0.,0.]
  score_rep_l=[0.,0.,0.]
  score_rep_75_1=[0.,0.,0.]
  score_rep_75_2=[0.,0.,0.]
  score_rep_75_l=[0.,0.,0.]
  num=0
  def __init__(self, params):
    super(DecodeText, self).__init__(params)
    self._unk_mapping = None
    self._unk_replace_fn = _unk_replace
    
    self.has_words=get_vocab()

  @staticmethod
  def default_params():
    params = {}
    params.update({
        "delimiter": " ",
        "postproc_fn": "",
        "unk_replace": False,
        "unk_mapping": None,
    })
    return params

  def before_run(self, _run_context):
    fetches = {}
    fetches["predicted_tokens"] = self._predictions["predicted_tokens"]
    fetches["attention_index"] = self._predictions["beam_search_output.attention_index"]
    fetches["features.source_doc_length"] = self._predictions["features.source_doc_length"]
    fetches["features.source_sents_length"] = self._predictions["features.source_sents_length"]
    fetches["features.caption_tokens"] = self._predictions["features.caption_tokens"]
    fetches["features.caption_num"] = self._predictions["features.caption_num"]
    fetches["features.source_tokens"] = self._predictions["features.source_tokens"]
    fetches["labels.target_tokens"] = self._predictions["labels.target_tokens"]
    
    fetches["text_scores"] = self._predictions["beam_search_output.original_outputs.text_scores"]
    fetches["image_scores"] = self._predictions["beam_search_output.original_outputs.image_scores"]
    fetches["caption_scores"] = self._predictions["beam_search_output.original_outputs.caption_scores"]
    
    
    return tf.train.SessionRunArgs(fetches)

  def after_run(self, _run_context, run_values):
    
    DecodeText.num += 1
    print(DecodeText.num)
    fetches_batch = run_values.results

    for fetches in unbatch_dict(fetches_batch):

      fetches["predicted_tokens"] = np.char.decode(
          fetches["predicted_tokens"].astype("S"), "utf-8")
      predicted_tokens = fetches["predicted_tokens"]
      text_scores = fetches["text_scores"]
      image_scores = fetches["image_scores"]
      caption_scores = fetches["caption_scores"]
      attention_index = fetches["attention_index"]

      # If we're using beam search we take the first beam
      if np.ndim(predicted_tokens) > 1:
        predicted_tokens = predicted_tokens[:, 0]
        text_scores = text_scores[:, 0]
        image_scores = image_scores[:, 0]
        caption_scores = caption_scores[:, 0]
        attention_index = attention_index[:, 0]
      
      fetches["features.caption_tokens"] = np.char.decode(
          fetches["features.caption_tokens"].astype("S"), "utf-8")
      caption_tokens = fetches["features.caption_tokens"]
      caption_num = fetches["features.caption_num"]

      fetches["features.source_tokens"] = np.char.decode(
          fetches["features.source_tokens"].astype("S"), "utf-8")
      source_tokens = fetches["features.source_tokens"]
      source_doc_length = fetches["features.source_doc_length"]
      source_sents_length = fetches["features.source_sents_length"]
      target_tokens = fetches["labels.target_tokens"]

      if self._unk_replace_fn is not None:
        
        predicted_tokens_rep = self._unk_replace_fn(
            source_tokens=source_tokens,
            caption_tokens=caption_tokens,
            predicted_tokens=predicted_tokens,
            attention_index=attention_index,
            text_scores=text_scores,
            image_scores=image_scores,
            caption_scores=caption_scores,
            has_words=self.has_words)

      #sent = self.params["delimiter"].join(predicted_tokens).split("SEQUENCE_END")[0]
      '''summary=[]
      index=-1
      for word in predicted_tokens:
          if word=="DOC_NOT_END":
              summary.append([])
              index+=1
          elif word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END"]:
              summary[index].append(word)
              
      target=[]
      index=-1
      for sent in target_tokens:
          new_sent=[]
          for word in sent:
              if word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END", "DOC_NOT_END"]:
                  new_sent.append(word)
          target.append(new_sent)'''
      #sent = sent + u'\n------------------------------------------------------\n' + (' '.join(source_tokens)) + u'\n'

      # Apply postproc
      #if self._postproc_fn:
      #  sent = self._postproc_fn(sent)

      summary=[]
      index=-1
      for word in predicted_tokens:
          if word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END", "DOC_NOT_END"]:
              summary.append(word)
              
      summary_rep=[]
      index=-1
      for word in predicted_tokens_rep:
          if word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END", "DOC_NOT_END"]:
              summary_rep.append(word)
              
      target=[]
      index=-1
      for sent in target_tokens:
          new_sent=[]
          for word in sent:
              if word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END", "DOC_NOT_END"]:
                  new_sent.append(word)
          target.append(new_sent)
      summary=' '.join(summary)
      summary=summary.replace('SEQUENCE_START','').replace('SEQUENCE_END','').replace('DOC_END','').replace('DOC_NOT_END','')
      
      summary_rep=' '.join(summary_rep)
      summary_rep=summary_rep.replace('SEQUENCE_START','').replace('SEQUENCE_END','').replace('DOC_END','').replace('DOC_NOT_END','')
      target=' '.join([' '.join(sent) for sent in target_tokens])
      target=target.replace("DOC_NOT_END", '').replace("SEQUENCE_START", '').replace("SEQUENCE_END", '').replace("DOC_END", '')
      #print(summary)
      #print('----------------')
      #print(target)
      def pp(text):
        tmp=[]
        length=0
        for ch in text:
            if length>75: 
                break
            if ch!=' ':
                length+=1
            tmp.append(ch)
        return ''.join(tmp)
      print(DecodeText.num)
      print('------------------unk-------------------')
      print(summary)
      print('------------------rep-------------------')
      print(summary_rep)
      print('------------------target-------------------')
      print(target)
      
      print('-------------------full---unk---------------')
      scores = rouge.get_scores([summary], [target])
      print(scores[0]['rouge-1']['r'], scores[0]['rouge-1']['p'], scores[0]['rouge-1']['f'])
      DecodeText.score_1[0]+=float(scores[0]['rouge-1']['r'])
      DecodeText.score_1[1]+=float(scores[0]['rouge-1']['p'])
      DecodeText.score_1[2]+=float(scores[0]['rouge-1']['f'])
      print(DecodeText.score_1[0]/DecodeText.num, DecodeText.score_1[1]/DecodeText.num, DecodeText.score_1[2]/DecodeText.num)
      
      print(scores[0]['rouge-2']['r'], scores[0]['rouge-2']['p'], scores[0]['rouge-2']['f'])
      DecodeText.score_2[0]+=float(scores[0]['rouge-2']['r'])
      DecodeText.score_2[1]+=float(scores[0]['rouge-2']['p'])
      DecodeText.score_2[2]+=float(scores[0]['rouge-2']['f'])
      print(DecodeText.score_2[0]/DecodeText.num, DecodeText.score_2[1]/DecodeText.num, DecodeText.score_2[2]/DecodeText.num)
      
      print(scores[0]['rouge-l']['r'], scores[0]['rouge-l']['p'], scores[0]['rouge-l']['f'])
      DecodeText.score_l[0]+=float(scores[0]['rouge-l']['r'])
      DecodeText.score_l[1]+=float(scores[0]['rouge-l']['p'])
      DecodeText.score_l[2]+=float(scores[0]['rouge-l']['f'])
      print(DecodeText.score_l[0]/DecodeText.num, DecodeText.score_l[1]/DecodeText.num, DecodeText.score_l[2]/DecodeText.num)
      
      print('-------------------75---unk---------------')
      scores = rouge.get_scores([pp(summary)], [pp(target)])
      print(scores[0]['rouge-1']['r'], scores[0]['rouge-1']['p'], scores[0]['rouge-1']['f'])
      DecodeText.score_75_1[0]+=float(scores[0]['rouge-1']['r'])
      DecodeText.score_75_1[1]+=float(scores[0]['rouge-1']['p'])
      DecodeText.score_75_1[2]+=float(scores[0]['rouge-1']['f'])
      print(DecodeText.score_75_1[0]/DecodeText.num, DecodeText.score_75_1[1]/DecodeText.num, DecodeText.score_75_1[2]/DecodeText.num)
      
      print(scores[0]['rouge-2']['r'], scores[0]['rouge-2']['p'], scores[0]['rouge-2']['f'])
      DecodeText.score_75_2[0]+=float(scores[0]['rouge-2']['r'])
      DecodeText.score_75_2[1]+=float(scores[0]['rouge-2']['p'])
      DecodeText.score_75_2[2]+=float(scores[0]['rouge-2']['f'])
      print(DecodeText.score_75_2[0]/DecodeText.num, DecodeText.score_75_2[1]/DecodeText.num, DecodeText.score_75_2[2]/DecodeText.num)
      
      print(scores[0]['rouge-l']['r'], scores[0]['rouge-l']['p'], scores[0]['rouge-l']['f'])
      DecodeText.score_75_l[0]+=float(scores[0]['rouge-l']['r'])
      DecodeText.score_75_l[1]+=float(scores[0]['rouge-l']['p'])
      DecodeText.score_75_l[2]+=float(scores[0]['rouge-l']['f'])
      print(DecodeText.score_75_l[0]/DecodeText.num, DecodeText.score_75_l[1]/DecodeText.num, DecodeText.score_75_l[2]/DecodeText.num)
      
      print('-------------------full---rep---------------')
      scores_rep = rouge.get_scores([summary_rep], [target])
      print(scores_rep[0]['rouge-1']['r'], scores_rep[0]['rouge-1']['p'], scores_rep[0]['rouge-1']['f'])
      DecodeText.score_rep_1[0]+=float(scores_rep[0]['rouge-1']['r'])
      DecodeText.score_rep_1[1]+=float(scores_rep[0]['rouge-1']['p'])
      DecodeText.score_rep_1[2]+=float(scores_rep[0]['rouge-1']['f'])
      print(DecodeText.score_rep_1[0]/DecodeText.num, DecodeText.score_rep_1[1]/DecodeText.num, DecodeText.score_rep_1[2]/DecodeText.num)
      
      print(scores_rep[0]['rouge-2']['r'], scores_rep[0]['rouge-2']['p'], scores_rep[0]['rouge-2']['f'])
      DecodeText.score_rep_2[0]+=float(scores_rep[0]['rouge-2']['r'])
      DecodeText.score_rep_2[1]+=float(scores_rep[0]['rouge-2']['p'])
      DecodeText.score_rep_2[2]+=float(scores_rep[0]['rouge-2']['f'])
      print(DecodeText.score_rep_2[0]/DecodeText.num, DecodeText.score_rep_2[1]/DecodeText.num, DecodeText.score_rep_2[2]/DecodeText.num)
      
      print(scores_rep[0]['rouge-l']['r'], scores_rep[0]['rouge-l']['p'], scores_rep[0]['rouge-l']['f'])
      DecodeText.score_rep_l[0]+=float(scores_rep[0]['rouge-l']['r'])
      DecodeText.score_rep_l[1]+=float(scores_rep[0]['rouge-l']['p'])
      DecodeText.score_rep_l[2]+=float(scores_rep[0]['rouge-l']['f'])
      print(DecodeText.score_rep_l[0]/DecodeText.num, DecodeText.score_rep_l[1]/DecodeText.num, DecodeText.score_rep_l[2]/DecodeText.num)
      
      print('-------------------75---rep---------------')
      scores_rep = rouge.get_scores([pp(summary_rep)], [pp(target)])
      print(scores_rep[0]['rouge-1']['r'], scores_rep[0]['rouge-1']['p'], scores_rep[0]['rouge-1']['f'])
      DecodeText.score_rep_75_1[0]+=float(scores_rep[0]['rouge-1']['r'])
      DecodeText.score_rep_75_1[1]+=float(scores_rep[0]['rouge-1']['p'])
      DecodeText.score_rep_75_1[2]+=float(scores_rep[0]['rouge-1']['f'])
      print(DecodeText.score_rep_75_1[0]/DecodeText.num, DecodeText.score_rep_75_1[1]/DecodeText.num, DecodeText.score_rep_75_1[2]/DecodeText.num)
      
      print(scores_rep[0]['rouge-2']['r'], scores_rep[0]['rouge-2']['p'], scores_rep[0]['rouge-2']['f'])
      DecodeText.score_rep_75_2[0]+=float(scores_rep[0]['rouge-2']['r'])
      DecodeText.score_rep_75_2[1]+=float(scores_rep[0]['rouge-2']['p'])
      DecodeText.score_rep_75_2[2]+=float(scores_rep[0]['rouge-2']['f'])
      print(DecodeText.score_rep_75_2[0]/DecodeText.num, DecodeText.score_rep_75_2[1]/DecodeText.num, DecodeText.score_rep_75_2[2]/DecodeText.num)
      
      print(scores_rep[0]['rouge-l']['r'], scores_rep[0]['rouge-l']['p'], scores_rep[0]['rouge-l']['f'])
      DecodeText.score_rep_75_l[0]+=float(scores_rep[0]['rouge-l']['r'])
      DecodeText.score_rep_75_l[1]+=float(scores_rep[0]['rouge-l']['p'])
      DecodeText.score_rep_75_l[2]+=float(scores_rep[0]['rouge-l']['f'])
      print(DecodeText.score_rep_75_l[0]/DecodeText.num, DecodeText.score_rep_75_l[1]/DecodeText.num, DecodeText.score_rep_75_l[2]/DecodeText.num)
      
      print('-------------------------------------')
      
      
def _unk_replace_2(source_tokens,
                 caption_tokens,
                 predicted_tokens,
                 attention_index,
                 text_scores,
                 image_scores,
                 caption_scores,
                 has_words,
                 mapping=None):

  result = []
  #print('predicted_tokens')
  for i in range(len(predicted_tokens)):
      sent=predicted_tokens[i]
      
      text_score=text_scores[i]
      image_score=image_scores[i]
      caption_score=caption_scores[i]
      att_index=attention_index[i]
          
      text_score_shape=np.shape(text_score)
      image_score_shape=np.shape(image_score)

      if att_index<text_score_shape[0]:
          att_sent=source_tokens[att_index]
          text_score[att_index]=-1
      else:
          att_index=(att_index-text_score_shape[0]) % image_score_shape[0]
          att_sent=caption_tokens[att_index]
          image_score[att_index]=-1
          caption_score[att_index]=-1
      #print(att_sent)
      new_token_index=0
      sign=True
      new_sent=[]
      
      for j in range(len(sent)):
          token=sent[j]
          
          if token=="UNK":
              while sign and (has_words.has_key(att_sent[new_token_index]) or \
                        att_sent[new_token_index] in ["SEQUENCE_START", "SEQUENCE_END", "DOC_NOT_END", "DOC_END", ""]):
                  new_token_index+=1
                  if new_token_index>=np.shape(att_sent)[0]:
                      scores=np.concatenate([text_score,image_score,caption_score],0)
                      att_index = np.argmax(scores)
                      if att_index<text_score_shape[0]:
                          att_sent=source_tokens[att_index]
                          text_score[att_index]=-1
                      else:
                          att_index=(att_index-text_score_shape[0]) % image_score_shape[0]
                          att_sent=caption_tokens[att_index]
                          image_score[att_index]=-1
                          caption_score[att_index]=-1
                      new_token_index=0
                      if scores[att_index]==-1:
                          sign=False
                          break
                      '''print(att_sent)
                      print(scores[att_index])
                      print(np.shape(scores))
                      print(scores)
                      print(np.shape(source_tokens))
                      print('\n'.join([str(_) for _ in source_tokens]))
                      print(np.shape(caption_tokens))
                      print('\n'.join([str(_) for _ in caption_tokens]))'''
              if sign:
                  new_token=att_sent[new_token_index]
                  att_sent[new_token_index]=""
              else:
                  new_token="UNK"
              new_sent.append(new_token)
          else:
              new_sent.append(token)
          
      result.append(new_sent)
          
  return result
      
    
class DecodeText_2(InferenceTask):

  score_1=[0.,0.,0.]
  score_2=[0.,0.,0.]
  score_l=[0.,0.,0.]
  score_75_1=[0.,0.,0.]
  score_75_2=[0.,0.,0.]
  score_75_l=[0.,0.,0.]
  score_rep_1=[0.,0.,0.]
  score_rep_2=[0.,0.,0.]
  score_rep_l=[0.,0.,0.]
  score_rep_75_1=[0.,0.,0.]
  score_rep_75_2=[0.,0.,0.]
  score_rep_75_l=[0.,0.,0.]
  num=0
  def __init__(self, params):
    super(DecodeText_2, self).__init__(params)
    self._unk_mapping = None
    self._unk_replace_fn = _unk_replace_2
    self.has_words=get_vocab()

  @staticmethod
  def default_params():
    params = {}
    params.update({
        "delimiter": " ",
        "postproc_fn": "",
        "unk_replace": False,
        "unk_mapping": None,
    })
    return params

  def before_run(self, _run_context):
    
    fetches = {}
    fetches["predicted_tokens"] = self._predictions["predicted_tokens"]
    fetches["attention_index"] = self._predictions["attention_index"]
    fetches["features.source_doc_length"] = self._predictions["features.source_doc_length"]
    fetches["features.source_sents_length"] = self._predictions["features.source_sents_length"]
    fetches["features.caption_tokens"] = self._predictions["features.caption_tokens"]
    fetches["features.caption_num"] = self._predictions["features.caption_num"]
    fetches["features.source_tokens"] = self._predictions["features.source_tokens"]
    fetches["labels.target_tokens"] = self._predictions["labels.target_tokens"]
    
    fetches["text_scores"] = self._predictions["original_outputs.text_scores"]
    fetches["image_scores"] = self._predictions["original_outputs.image_scores"]
    fetches["caption_scores"] = self._predictions["original_outputs.caption_scores"]
    
    return tf.train.SessionRunArgs(fetches)

  def after_run(self, _run_context, run_values):
    fetches_batch = run_values.results
    DecodeText_2.num += 1

    for fetches in unbatch_dict(fetches_batch):

      fetches["predicted_tokens"] = np.char.decode(
          fetches["predicted_tokens"].astype("S"), "utf-8")
      predicted_tokens = fetches["predicted_tokens"]
      text_scores = fetches["text_scores"]
      image_scores = fetches["image_scores"]
      caption_scores = fetches["caption_scores"]
      attention_index = fetches["attention_index"]

      if np.ndim(predicted_tokens) > 1:
        predicted_tokens = predicted_tokens[:, 0]
        text_scores = text_scores[:, 0]
        image_scores = image_scores[:, 0]
        caption_scores = caption_scores[:, 0]
        attention_index = attention_index[:, 0]
      
      fetches["features.caption_tokens"] = np.char.decode(
          fetches["features.caption_tokens"].astype("S"), "utf-8")
      caption_tokens = fetches["features.caption_tokens"]
      caption_num = fetches["features.caption_num"]

      fetches["features.source_tokens"] = np.char.decode(
          fetches["features.source_tokens"].astype("S"), "utf-8")
      source_tokens = fetches["features.source_tokens"]
      source_doc_length = fetches["features.source_doc_length"]
      source_sents_length = fetches["features.source_sents_length"]
      target_tokens = fetches["labels.target_tokens"]
      
      print("[%d]" % DecodeText_2.num)
      print('-------------------image_scores---------------------')
      for image_score in image_scores:
          s=" ".join([str(score) for score in image_score])
          print(s)
      print('-------------------caption_scores---------------------')
      for caption_score in caption_scores:
          s=" ".join([str(score) for score in caption_score])
          print(s)
      print('-------------------text_scores---------------------')
      for text_score in text_scores:
          s=" ".join([str(score) for score in text_score])
          print(s)

      if self._unk_replace_fn is not None:
        
        predicted_tokens_rep = self._unk_replace_fn(
            source_tokens=source_tokens,
            caption_tokens=caption_tokens,
            predicted_tokens=predicted_tokens,
            attention_index=attention_index,
            text_scores=text_scores,
            image_scores=image_scores,
            caption_scores=caption_scores,
            has_words=self.has_words)

      summary=[]
      summary_lines=[]
      index=-1
      for sent in predicted_tokens:
          tmp=[]
          for word in sent:
              if word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END", "DOC_NOT_END", " "]: 
                  summary.append(word)
                  tmp.append(word)
          summary_lines.append(" ".join(tmp))
              
      summary_rep=[]
      summary_rep_lines=[]
      index=-1
      for sent in predicted_tokens_rep:
          tmp=[]
          for word in sent:
              if word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END", "DOC_NOT_END", " "]:
                  summary_rep.append(word)
                  tmp.append(word)
          summary_rep_lines.append(" ".join(tmp))
              
      target=[]
      target_lines=[]
      index=-1
      for sent in target_tokens:
          new_sent=[]
          tmp=[]
          for word in sent:
              if word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END", "DOC_NOT_END", " "]:
                  new_sent.append(word)
                  tmp.append(word)
          target.append(new_sent)
          target_lines.append(" ".join(tmp))

      summary=' '.join(summary)
      summary=summary.replace('SEQUENCE_START','').replace('SEQUENCE_END','').replace('DOC_END','').replace('DOC_NOT_END','')
      
      summary_rep=' '.join(summary_rep)
      summary_rep=summary_rep.replace('SEQUENCE_START','').replace('SEQUENCE_END','').replace('DOC_END','').replace('DOC_NOT_END','')
      
      target=' '.join([' '.join(sent) for sent in target])
      
      print('------------------unk---summary----------------')
      print("\n".join(summary_lines))
      print('------------------rep---summary----------------')
      print("\n".join(summary_rep_lines))
      print('------------------target---summary----------------')
      print("\n".join(target_lines))
      
      def pp(text):
        tmp=[]
        length=0
        for ch in text:
            if length>75: 
                break
            if ch!=' ':
                length+=1
            tmp.append(ch)
        return ''.join(tmp)
      
      print('-------------------full---unk---------------')
      scores = rouge.get_scores([summary], [target])
      print(scores[0]['rouge-1']['r'], scores[0]['rouge-1']['p'], scores[0]['rouge-1']['f'])
      DecodeText_2.score_1[0]+=float(scores[0]['rouge-1']['r'])
      DecodeText_2.score_1[1]+=float(scores[0]['rouge-1']['p'])
      DecodeText_2.score_1[2]+=float(scores[0]['rouge-1']['f'])
      print(DecodeText_2.score_1[0]/DecodeText_2.num, DecodeText_2.score_1[1]/DecodeText_2.num, DecodeText_2.score_1[2]/DecodeText_2.num)
      
      print(scores[0]['rouge-2']['r'], scores[0]['rouge-2']['p'], scores[0]['rouge-2']['f'])
      DecodeText_2.score_2[0]+=float(scores[0]['rouge-2']['r'])
      DecodeText_2.score_2[1]+=float(scores[0]['rouge-2']['p'])
      DecodeText_2.score_2[2]+=float(scores[0]['rouge-2']['f'])
      print(DecodeText_2.score_2[0]/DecodeText_2.num, DecodeText_2.score_2[1]/DecodeText_2.num, DecodeText_2.score_2[2]/DecodeText_2.num)
      
      print(scores[0]['rouge-l']['r'], scores[0]['rouge-l']['p'], scores[0]['rouge-l']['f'])
      DecodeText_2.score_l[0]+=float(scores[0]['rouge-l']['r'])
      DecodeText_2.score_l[1]+=float(scores[0]['rouge-l']['p'])
      DecodeText_2.score_l[2]+=float(scores[0]['rouge-l']['f'])
      print(DecodeText_2.score_l[0]/DecodeText_2.num, DecodeText_2.score_l[1]/DecodeText_2.num, DecodeText_2.score_l[2]/DecodeText_2.num)
      
      print('-------------------75---unk---------------')
      scores = rouge.get_scores([pp(summary)], [pp(target)])
      print(scores[0]['rouge-1']['r'], scores[0]['rouge-1']['p'], scores[0]['rouge-1']['f'])
      DecodeText_2.score_75_1[0]+=float(scores[0]['rouge-1']['r'])
      DecodeText_2.score_75_1[1]+=float(scores[0]['rouge-1']['p'])
      DecodeText_2.score_75_1[2]+=float(scores[0]['rouge-1']['f'])
      print(DecodeText_2.score_75_1[0]/DecodeText_2.num, DecodeText_2.score_75_1[1]/DecodeText_2.num, DecodeText_2.score_75_1[2]/DecodeText_2.num)
      
      print(scores[0]['rouge-2']['r'], scores[0]['rouge-2']['p'], scores[0]['rouge-2']['f'])
      DecodeText_2.score_75_2[0]+=float(scores[0]['rouge-2']['r'])
      DecodeText_2.score_75_2[1]+=float(scores[0]['rouge-2']['p'])
      DecodeText_2.score_75_2[2]+=float(scores[0]['rouge-2']['f'])
      print(DecodeText_2.score_75_2[0]/DecodeText_2.num, DecodeText_2.score_75_2[1]/DecodeText_2.num, DecodeText_2.score_75_2[2]/DecodeText_2.num)
      
      print(scores[0]['rouge-l']['r'], scores[0]['rouge-l']['p'], scores[0]['rouge-l']['f'])
      DecodeText_2.score_75_l[0]+=float(scores[0]['rouge-l']['r'])
      DecodeText_2.score_75_l[1]+=float(scores[0]['rouge-l']['p'])
      DecodeText_2.score_75_l[2]+=float(scores[0]['rouge-l']['f'])
      print(DecodeText_2.score_75_l[0]/DecodeText_2.num, DecodeText_2.score_75_l[1]/DecodeText_2.num, DecodeText_2.score_75_l[2]/DecodeText_2.num)
      
      print('-------------------full---rep---------------')
      scores_rep = rouge.get_scores([summary_rep], [target])
      print(scores_rep[0]['rouge-1']['r'], scores_rep[0]['rouge-1']['p'], scores_rep[0]['rouge-1']['f'])
      DecodeText_2.score_rep_1[0]+=float(scores_rep[0]['rouge-1']['r'])
      DecodeText_2.score_rep_1[1]+=float(scores_rep[0]['rouge-1']['p'])
      DecodeText_2.score_rep_1[2]+=float(scores_rep[0]['rouge-1']['f'])
      print(DecodeText_2.score_rep_1[0]/DecodeText_2.num, DecodeText_2.score_rep_1[1]/DecodeText_2.num, DecodeText_2.score_rep_1[2]/DecodeText_2.num)
      
      print(scores_rep[0]['rouge-2']['r'], scores_rep[0]['rouge-2']['p'], scores_rep[0]['rouge-2']['f'])
      DecodeText_2.score_rep_2[0]+=float(scores_rep[0]['rouge-2']['r'])
      DecodeText_2.score_rep_2[1]+=float(scores_rep[0]['rouge-2']['p'])
      DecodeText_2.score_rep_2[2]+=float(scores_rep[0]['rouge-2']['f'])
      print(DecodeText_2.score_rep_2[0]/DecodeText_2.num, DecodeText_2.score_rep_2[1]/DecodeText_2.num, DecodeText_2.score_rep_2[2]/DecodeText_2.num)
      
      print(scores_rep[0]['rouge-l']['r'], scores_rep[0]['rouge-l']['p'], scores_rep[0]['rouge-l']['f'])
      DecodeText_2.score_rep_l[0]+=float(scores_rep[0]['rouge-l']['r'])
      DecodeText_2.score_rep_l[1]+=float(scores_rep[0]['rouge-l']['p'])
      DecodeText_2.score_rep_l[2]+=float(scores_rep[0]['rouge-l']['f'])
      print(DecodeText_2.score_rep_l[0]/DecodeText_2.num, DecodeText_2.score_rep_l[1]/DecodeText_2.num, DecodeText_2.score_rep_l[2]/DecodeText_2.num)
      
      print('-------------------75---rep---------------')
      scores_rep = rouge.get_scores([pp(summary_rep)], [pp(target)])
      print(scores_rep[0]['rouge-1']['r'], scores_rep[0]['rouge-1']['p'], scores_rep[0]['rouge-1']['f'])
      DecodeText_2.score_rep_75_1[0]+=float(scores_rep[0]['rouge-1']['r'])
      DecodeText_2.score_rep_75_1[1]+=float(scores_rep[0]['rouge-1']['p'])
      DecodeText_2.score_rep_75_1[2]+=float(scores_rep[0]['rouge-1']['f'])
      print(DecodeText_2.score_rep_75_1[0]/DecodeText_2.num, DecodeText_2.score_rep_75_1[1]/DecodeText_2.num, DecodeText_2.score_rep_75_1[2]/DecodeText_2.num)
      
      print(scores_rep[0]['rouge-2']['r'], scores_rep[0]['rouge-2']['p'], scores_rep[0]['rouge-2']['f'])
      DecodeText_2.score_rep_75_2[0]+=float(scores_rep[0]['rouge-2']['r'])
      DecodeText_2.score_rep_75_2[1]+=float(scores_rep[0]['rouge-2']['p'])
      DecodeText_2.score_rep_75_2[2]+=float(scores_rep[0]['rouge-2']['f'])
      print(DecodeText_2.score_rep_75_2[0]/DecodeText_2.num, DecodeText_2.score_rep_75_2[1]/DecodeText_2.num, DecodeText_2.score_rep_75_2[2]/DecodeText_2.num)
      
      print(scores_rep[0]['rouge-l']['r'], scores_rep[0]['rouge-l']['p'], scores_rep[0]['rouge-l']['f'])
      DecodeText_2.score_rep_75_l[0]+=float(scores_rep[0]['rouge-l']['r'])
      DecodeText_2.score_rep_75_l[1]+=float(scores_rep[0]['rouge-l']['p'])
      DecodeText_2.score_rep_75_l[2]+=float(scores_rep[0]['rouge-l']['f'])
      print(DecodeText_2.score_rep_75_l[0]/DecodeText_2.num, DecodeText_2.score_rep_75_l[1]/DecodeText_2.num, DecodeText_2.score_rep_75_l[2]/DecodeText_2.num)
      
      print('-------------------------------------')
      
      
      
      
      
def _unk_replace_3(source_tokens,
                 predicted_tokens,
                 attention_index,
                 text_scores,
                 has_words,
                 mapping=None):

  result = []
  #print('predicted_tokens')
  for i in range(len(predicted_tokens)):
      sent=predicted_tokens[i]
      
      text_score=text_scores[i]
      att_index=attention_index[i]

      att_sent=source_tokens[att_index]
      text_score[att_index]=-1
      #print(att_sent)
      new_token_index=0
      sign=True
      new_sent=[]
      
      for j in range(len(sent)):
          token=sent[j]
          
          if token=="UNK":
              while sign and (has_words.has_key(att_sent[new_token_index]) or \
                        att_sent[new_token_index] in ["SEQUENCE_START", "SEQUENCE_END", "DOC_NOT_END", "DOC_END", ""]):
                  new_token_index+=1
                  if new_token_index>=np.shape(att_sent)[0]:
                      scores=text_score
                      att_index = np.argmax(scores)
                      att_sent=source_tokens[att_index]
                      text_score[att_index]=-1
                          
                      new_token_index=0
                      if scores[att_index]==-1:
                          sign=False
                          break
              if sign:
                  new_token=att_sent[new_token_index]
                  att_sent[new_token_index]=""
              else:
                  new_token="UNK"
              new_sent.append(new_token)
          else:
              new_sent.append(token)
          
      result.append(new_sent)
          
  return result
      
    
class DecodeText_2_Text(InferenceTask):

  score_1=[0.,0.,0.]
  score_2=[0.,0.,0.]
  score_l=[0.,0.,0.]
  score_75_1=[0.,0.,0.]
  score_75_2=[0.,0.,0.]
  score_75_l=[0.,0.,0.]
  score_rep_1=[0.,0.,0.]
  score_rep_2=[0.,0.,0.]
  score_rep_l=[0.,0.,0.]
  score_rep_75_1=[0.,0.,0.]
  score_rep_75_2=[0.,0.,0.]
  score_rep_75_l=[0.,0.,0.]
  num=0
  def __init__(self, params):
    super(DecodeText_2_Text, self).__init__(params)
    self._unk_mapping = None
    self._unk_replace_fn = _unk_replace_3
    self.has_words=get_vocab()

  @staticmethod
  def default_params():
    params = {}
    params.update({
        "delimiter": " ",
        "postproc_fn": "",
        "unk_replace": False,
        "unk_mapping": None,
    })
    return params

  def before_run(self, _run_context):
    
    fetches = {}
    fetches["predicted_tokens"] = self._predictions["predicted_tokens"]
    fetches["attention_index"] = self._predictions["attention_index"]
    fetches["features.source_doc_length"] = self._predictions["features.source_doc_length"]
    fetches["features.source_sents_length"] = self._predictions["features.source_sents_length"]
    fetches["features.source_tokens"] = self._predictions["features.source_tokens"]
    fetches["labels.target_tokens"] = self._predictions["labels.target_tokens"]
    
    fetches["text_scores"] = self._predictions["original_outputs.text_scores"]
    
    return tf.train.SessionRunArgs(fetches)

  def after_run(self, _run_context, run_values):
    fetches_batch = run_values.results
    DecodeText_2_Text.num += 1

    for fetches in unbatch_dict(fetches_batch):

      fetches["predicted_tokens"] = np.char.decode(
          fetches["predicted_tokens"].astype("S"), "utf-8")
      predicted_tokens = fetches["predicted_tokens"]
      text_scores = fetches["text_scores"]
      attention_index = fetches["attention_index"]

      if np.ndim(predicted_tokens) > 1:
        predicted_tokens = predicted_tokens[:, 0]
        text_scores = text_scores[:, 0]
        attention_index = attention_index[:, 0]

      fetches["features.source_tokens"] = np.char.decode(
          fetches["features.source_tokens"].astype("S"), "utf-8")
      source_tokens = fetches["features.source_tokens"]
      source_doc_length = fetches["features.source_doc_length"]
      source_sents_length = fetches["features.source_sents_length"]
      target_tokens = fetches["labels.target_tokens"]
      
      print("[%d]" % DecodeText_2_Text.num)
      print('-------------------text_scores---------------------')
      for text_score in text_scores:
          s=" ".join([str(score) for score in text_score])
          print(s)

      if self._unk_replace_fn is not None:
        
        predicted_tokens_rep = self._unk_replace_fn(
            source_tokens=source_tokens,
            predicted_tokens=predicted_tokens,
            attention_index=attention_index,
            text_scores=text_scores,
            has_words=self.has_words)

      #sent = self.params["delimiter"].join(predicted_tokens).split("SEQUENCE_END")[0]
      summary=[]
      summary_lines=[]
      index=-1
      for sent in predicted_tokens:
          tmp=[]
          for word in sent:
              if word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END", "DOC_NOT_END", " "]: 
                  summary.append(word)
                  tmp.append(word)
          summary_lines.append(" ".join(tmp))
              
      summary_rep=[]
      summary_rep_lines=[]
      index=-1
      for sent in predicted_tokens_rep:
          tmp=[]
          for word in sent:
              if word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END", "DOC_NOT_END", " "]:
                  summary_rep.append(word)
                  tmp.append(word)
          summary_rep_lines.append(" ".join(tmp))
              
      target=[]
      target_lines=[]
      index=-1
      for sent in target_tokens:
          new_sent=[]
          tmp=[]
          for word in sent:
              if word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END", "DOC_NOT_END", " "]:
                  new_sent.append(word)
                  tmp.append(word)
          target.append(new_sent)
          target_lines.append(" ".join(tmp))

      summary=' '.join(summary)
      summary=summary.replace('SEQUENCE_START','').replace('SEQUENCE_END','').replace('DOC_END','').replace('DOC_NOT_END','')
      
      summary_rep=' '.join(summary_rep)
      summary_rep=summary_rep.replace('SEQUENCE_START','').replace('SEQUENCE_END','').replace('DOC_END','').replace('DOC_NOT_END','')
      
      target=' '.join([' '.join(sent) for sent in target])
      
      print('------------------unk---summary----------------')
      print("\n".join(summary_lines))
      print('------------------rep---summary----------------')
      print("\n".join(summary_rep_lines))
      print('------------------target---summary----------------')
      print("\n".join(target_lines))
      
      def pp(text):
        tmp=[]
        length=0
        for ch in text:
            if length>75: 
                break
            if ch!=' ':
                length+=1
            tmp.append(ch)
        return ''.join(tmp)
      
      print('-------------------full---unk---------------')
      scores = rouge.get_scores([summary], [target])
      print(scores[0]['rouge-1']['r'], scores[0]['rouge-1']['p'], scores[0]['rouge-1']['f'])
      DecodeText_2_Text.score_1[0]+=float(scores[0]['rouge-1']['r'])
      DecodeText_2_Text.score_1[1]+=float(scores[0]['rouge-1']['p'])
      DecodeText_2_Text.score_1[2]+=float(scores[0]['rouge-1']['f'])
      print(DecodeText_2_Text.score_1[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_1[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_1[2]/DecodeText_2_Text.num)
      
      print(scores[0]['rouge-2']['r'], scores[0]['rouge-2']['p'], scores[0]['rouge-2']['f'])
      DecodeText_2_Text.score_2[0]+=float(scores[0]['rouge-2']['r'])
      DecodeText_2_Text.score_2[1]+=float(scores[0]['rouge-2']['p'])
      DecodeText_2_Text.score_2[2]+=float(scores[0]['rouge-2']['f'])
      print(DecodeText_2_Text.score_2[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_2[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_2[2]/DecodeText_2_Text.num)
      
      print(scores[0]['rouge-l']['r'], scores[0]['rouge-l']['p'], scores[0]['rouge-l']['f'])
      DecodeText_2_Text.score_l[0]+=float(scores[0]['rouge-l']['r'])
      DecodeText_2_Text.score_l[1]+=float(scores[0]['rouge-l']['p'])
      DecodeText_2_Text.score_l[2]+=float(scores[0]['rouge-l']['f'])
      print(DecodeText_2_Text.score_l[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_l[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_l[2]/DecodeText_2_Text.num)
      
      print('-------------------75---unk---------------')
      scores = rouge.get_scores([pp(summary)], [pp(target)])
      print(scores[0]['rouge-1']['r'], scores[0]['rouge-1']['p'], scores[0]['rouge-1']['f'])
      DecodeText_2_Text.score_75_1[0]+=float(scores[0]['rouge-1']['r'])
      DecodeText_2_Text.score_75_1[1]+=float(scores[0]['rouge-1']['p'])
      DecodeText_2_Text.score_75_1[2]+=float(scores[0]['rouge-1']['f'])
      print(DecodeText_2_Text.score_75_1[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_75_1[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_75_1[2]/DecodeText_2_Text.num)
      
      print(scores[0]['rouge-2']['r'], scores[0]['rouge-2']['p'], scores[0]['rouge-2']['f'])
      DecodeText_2_Text.score_75_2[0]+=float(scores[0]['rouge-2']['r'])
      DecodeText_2_Text.score_75_2[1]+=float(scores[0]['rouge-2']['p'])
      DecodeText_2_Text.score_75_2[2]+=float(scores[0]['rouge-2']['f'])
      print(DecodeText_2_Text.score_75_2[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_75_2[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_75_2[2]/DecodeText_2_Text.num)
      
      print(scores[0]['rouge-l']['r'], scores[0]['rouge-l']['p'], scores[0]['rouge-l']['f'])
      DecodeText_2_Text.score_75_l[0]+=float(scores[0]['rouge-l']['r'])
      DecodeText_2_Text.score_75_l[1]+=float(scores[0]['rouge-l']['p'])
      DecodeText_2_Text.score_75_l[2]+=float(scores[0]['rouge-l']['f'])
      print(DecodeText_2_Text.score_75_l[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_75_l[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_75_l[2]/DecodeText_2_Text.num)
      
      print('-------------------full---rep---------------')
      scores_rep = rouge.get_scores([summary_rep], [target])
      print(scores_rep[0]['rouge-1']['r'], scores_rep[0]['rouge-1']['p'], scores_rep[0]['rouge-1']['f'])
      DecodeText_2_Text.score_rep_1[0]+=float(scores_rep[0]['rouge-1']['r'])
      DecodeText_2_Text.score_rep_1[1]+=float(scores_rep[0]['rouge-1']['p'])
      DecodeText_2_Text.score_rep_1[2]+=float(scores_rep[0]['rouge-1']['f'])
      print(DecodeText_2_Text.score_rep_1[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_1[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_1[2]/DecodeText_2_Text.num)
      
      print(scores_rep[0]['rouge-2']['r'], scores_rep[0]['rouge-2']['p'], scores_rep[0]['rouge-2']['f'])
      DecodeText_2_Text.score_rep_2[0]+=float(scores_rep[0]['rouge-2']['r'])
      DecodeText_2_Text.score_rep_2[1]+=float(scores_rep[0]['rouge-2']['p'])
      DecodeText_2_Text.score_rep_2[2]+=float(scores_rep[0]['rouge-2']['f'])
      print(DecodeText_2_Text.score_rep_2[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_2[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_2[2]/DecodeText_2_Text.num)
      
      print(scores_rep[0]['rouge-l']['r'], scores_rep[0]['rouge-l']['p'], scores_rep[0]['rouge-l']['f'])
      DecodeText_2_Text.score_rep_l[0]+=float(scores_rep[0]['rouge-l']['r'])
      DecodeText_2_Text.score_rep_l[1]+=float(scores_rep[0]['rouge-l']['p'])
      DecodeText_2_Text.score_rep_l[2]+=float(scores_rep[0]['rouge-l']['f'])
      print(DecodeText_2_Text.score_rep_l[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_l[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_l[2]/DecodeText_2_Text.num)
      
      print('-------------------75---rep---------------')
      scores_rep = rouge.get_scores([pp(summary_rep)], [pp(target)])
      print(scores_rep[0]['rouge-1']['r'], scores_rep[0]['rouge-1']['p'], scores_rep[0]['rouge-1']['f'])
      DecodeText_2_Text.score_rep_75_1[0]+=float(scores_rep[0]['rouge-1']['r'])
      DecodeText_2_Text.score_rep_75_1[1]+=float(scores_rep[0]['rouge-1']['p'])
      DecodeText_2_Text.score_rep_75_1[2]+=float(scores_rep[0]['rouge-1']['f'])
      print(DecodeText_2_Text.score_rep_75_1[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_75_1[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_75_1[2]/DecodeText_2_Text.num)
      
      print(scores_rep[0]['rouge-2']['r'], scores_rep[0]['rouge-2']['p'], scores_rep[0]['rouge-2']['f'])
      DecodeText_2_Text.score_rep_75_2[0]+=float(scores_rep[0]['rouge-2']['r'])
      DecodeText_2_Text.score_rep_75_2[1]+=float(scores_rep[0]['rouge-2']['p'])
      DecodeText_2_Text.score_rep_75_2[2]+=float(scores_rep[0]['rouge-2']['f'])
      print(DecodeText_2_Text.score_rep_75_2[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_75_2[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_75_2[2]/DecodeText_2_Text.num)
      
      print(scores_rep[0]['rouge-l']['r'], scores_rep[0]['rouge-l']['p'], scores_rep[0]['rouge-l']['f'])
      DecodeText_2_Text.score_rep_75_l[0]+=float(scores_rep[0]['rouge-l']['r'])
      DecodeText_2_Text.score_rep_75_l[1]+=float(scores_rep[0]['rouge-l']['p'])
      DecodeText_2_Text.score_rep_75_l[2]+=float(scores_rep[0]['rouge-l']['f'])
      print(DecodeText_2_Text.score_rep_75_l[0]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_75_l[1]/DecodeText_2_Text.num, DecodeText_2_Text.score_rep_75_l[2]/DecodeText_2_Text.num)
      
      print('-------------------------------------')




