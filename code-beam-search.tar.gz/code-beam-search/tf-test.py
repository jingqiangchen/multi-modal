import numpy as np
import tensorflow as tf
from tensorflow.python.util import nest
from tensorflow.python.ops import array_ops
from tensorflow.python.ops import math_ops
from tensorflow.python.ops import tensor_array_ops
from tensorflow.python.ops import rnn, rnn_cell_impl
from tensorflow.python.framework import tensor_shape
import os, sys, threading, time
import common
from tensorflow import gfile
#from seq2seq.contrib.seq2seq.helper import TrainingHelper_Ext

#word2vec=tf.load_op_library(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'word2vec_ops.so'))

def test1():
    x = np.array([[1,2,3],[4,5,6]])
    sess = tf.Session()
    
    sum0 = np.sum(x, axis=0)
    sum1 = np.sum(x, axis=1)
    
    sum2 = sess.run(tf.reduce_sum(x))
    sum3 = sess.run(tf.reduce_sum(x, 0))
    sum4 = sess.run(tf.reduce_sum(x, 1))
    sum5 = sess.run(tf.reduce_sum(x, 1, keep_dims=True))
    sum6 = sess.run(tf.reduce_sum(x, [0, 1]))
    
    
    print (sum0)
    print (sum1)
    print (sum2)
    print (sum3)
    print (sum4)
    print (sum5)
    print (sum6)
    sess.close()
    
def test2():
    data = [[1,2,3,4,5,6,7,8],[11,12,13,14,15,16,17,18]]
    x = tf.strided_slice(data,[0,0],[1,4])
    y = tf.strided_slice(data,[1,1],[2,3])
    with tf.Session() as sess:
        print(sess.run(x))
        print(sess.run(y))
        
        
BATCH_SIZE = 6  
NUM_EXPOCHES = 2  
  
  
def input_producer():
    i = tf.train.range_input_producer(NUM_EXPOCHES, shuffle=False).dequeue()
    inputs=i
    return inputs


class Inputs(object):
    def __init__(self):
        self.inputs = input_producer()


def test3():
    inputs = Inputs()
    init = tf.initialize_all_variables()
    sv = tf.train.Supervisor(logdir="/home/cjq/tmp/",init_op=init)
    with sv.managed_session() as sess:
        sess.run(init)
        a='ddd'
        for i in range(100):
            ii=sess.run(inputs.inputs)
            print(ii)
        sess.close()
    print(a)
    
    
def test4():
    w1 = tf.Variable(tf.random_normal(shape=[2]), name='w1')
    w2 = tf.Variable(tf.random_normal(shape=[5]), name='w2')
    saver = tf.train.Saver()
    sess = tf.Session()
    sess.run(tf.global_variables_initializer())
    saver.save(sess, 'my_test_model')
    
    
def test5():
    w1 = tf.Variable(tf.truncated_normal(shape=[10]), name='w1')
    w2 = tf.Variable(tf.truncated_normal(shape=[20]), name='w2')
    tf.add_to_collection('vars', w1)
    tf.add_to_collection('vars', w2)
    saver = tf.train.Saver()
    sess = tf.Session()
    sess.run(tf.global_variables_initializer())
    saver.save(sess, 'my-model')
    
    
def test6():
    sess = tf.Session()
    new_saver = tf.train.import_meta_graph('my-model.meta')
    new_saver.restore(sess, tf.train.latest_checkpoint('./'))
    with tf.Graph().as_default():
        all_vars = tf.get_collection('vars')
        for v in all_vars:
            v_ = sess.run(v)
            print(v_)
        
        
def test7():
    sess = tf.Session()
    new_saver = tf.train.import_meta_graph('my-model.meta')
    new_saver.restore(sess, tf.train.latest_checkpoint('./'))
    for op in tf.get_default_graph().get_operations():
       print(op.name, " " ,op.type)
    #print(tf.Graph().get_all_collection_keys().get_tensor_by_name("w1"))
    
    
def test8():
    w1 = tf.Variable(tf.truncated_normal(shape=[10]), name='w1')
    w2 = tf.Variable(tf.truncated_normal(shape=[10]), name='w2')
    w3 = tf.add(w1, w2)
    tf.add_to_collection('vars', w1)
    tf.add_to_collection('vars', w2)
    tf.add_to_collection('vars', w3)
    #saver = tf.train.Saver()
    #sess0 = tf.Session()
    #sess0.run(tf.global_variables_initializer())
    #sess0.close()
    #saver.save(sess, 'my-model2')
    metagraph=tf.train.export_meta_graph()
    
    
    with tf.Graph().as_default():
        new_saver = tf.train.import_meta_graph(metagraph)
        init=tf.ConfigProto(allow_soft_placement=True)
        sv = tf.train.Supervisor(logdir="./test3")
        with sv.managed_session(config=init) as sess:
            #new_saver.restore(sess, tf.train.latest_checkpoint('./'))
            all_vars = tf.get_collection('vars')
            #sess.run(tf.global_variables_initializer())
            w1=all_vars[0]
            w2=all_vars[1]
            w3=all_vars[2]
            v_ = sess.run(w3)
            print(v_)
            sv.saver.save(sess, "./test3", global_step=True)
            
            
def test9():
    
    a1=tf.Variable([[[1,1],[2,2],[3,3]],[[11,11],[22,22],[33,33]]])
    a2=tf.Variable([[[4,4,4],[5,5,5],[6,6,6]],[[44,44,44],[55,55,55],[66,66,66]]])
    a=(a1, a2)
    
    ta=tensor_array_ops.TensorArray(dtype=a1.dtype, size=2)
    c=ta.unstack(a1)
    d=c.read(0)
    
    ta2=tensor_array_ops.TensorArray(dtype=a2.dtype, size=2)
    c2=ta2.unstack(a2)
    d2=c2.read(0)
    
    e=nest.pack_sequence_as(a, (d,d2))
    sess=tf.Session()
    sess.run(tf.global_variables_initializer())
    aa=sess.run(e)
    print(aa[0])
    

def test10():
    
    a1=tf.Variable([[[1,1],[2,2],[3,3]],[[11,11],[22,22],[33,33]]])
    a2=tf.Variable([[[4,4,4],[5,5,5],[6,6,6]],[[44,44,44],[55,55,55],[66,66,66]]])
    a=(a1, a2)
    ta=tensor_array_ops.TensorArray(dtype=a1.dtype, size=2)
    
    c=ta.unstack(a1)
    d=c.read(0)
    shape=a1.get_shape().with_rank_at_least(3)
    sess=tf.Session()
    sess.run(tf.global_variables_initializer())
    #aa=sess.run(shape)
    print(shape[1:])
    
    
def test11():
    
    a1=tf.Variable([[[1,1],[2,2],[3,3]],[[11,11],[22,22],[33,33]]])
    a2=tf.Variable([[[4,4,4],[5,5,5],[6,6,6]],[[44,44,44],[55,55,55],[66,66,66]]])
    a=(a1, a2)
    b=array_ops.transpose(a1,[1,0,2])
    sess=tf.Session()
    sess.run(tf.global_variables_initializer())
    aa=sess.run(b)
    print(aa)
    

def test12():
    a1=(1,2)
    a2=3
    a=[a1,a2]
    print(a[1])
    
    
def test13():
    a1=tf.Variable([[[1,1,1],[2,2,2],[3,3,3]],[[11,11,11],[22,22,22],[33,33,33]]])
    a2=tf.Variable([[[4,4,4],[5,5,5],[6,6,6]],[[44,44,44],[55,55,55],[66,66,66]]])
    
    a=(a1, a2)
    b=[[[1,1,1],[2,2,2],[3,3,3]],[[11,11,11],[22,22,22],[33,33,33]]]
    cell=rnn_cell_impl.BasicRNNCell(5)
    init_state=cell.zero_state(2,tf.float32)
    tf.nn.dynamic_rnn(cell, np.array([[[4,4,4],[5,5,5],[6,6,6]],[[44,44,44],[55,55,55],[66,66,66]]]), initial_state=init_state, dtype=tf.int32)
    #tf.contrib.rnn
    
    
def test14():
    a1=tf.Variable([[1.0,1.0],[2.0,2.0]])
    a2=tf.Variable([[3.0,3.0],[4.0,4.0]])
    
    a=[(a1,a1), (a2,a2)]
    cell=rnn_cell_impl.BasicRNNCell(5)
    init_state=cell.zero_state(2,tf.float32)
    tf.nn.static_rnn(cell, a, initial_state=init_state, dtype=tf.float32)
    #tf.contrib.rnn
    tf.ontrib.seq2seq.Decoder
    
    
def test15():
    (words, counts, words_per_epoch, epoch, words_, examples,
     labels) = word2vec.skipgram_word2vec(filename='train-data-test',
                                          batch_size=5,
                                          window_size=5,
                                          min_count=1,
                                          subsample=1e-3)
    with tf.Session() as session:
        (vocab_words, vocab_counts,
         words_per_epoch, vocab_words_) = session.run([words, counts, words_per_epoch, words_])
        #vocab_size = len(vocab_words)
        print(vocab_words, vocab_counts, words_per_epoch)
        print(vocab_words_)
        print(np.sum(vocab_counts))
        print(len(vocab_words))
        
        
def test16():
    dir='//home//cjq//sum-pic//dailymail//images'
    to_dir='//home//cjq//sum-pic//dailymail//image-features'
    dir_list=os.listdir(dir)
    i=0
    for dir_name in dir_list:
        if i>10:
            break
        files=os.listdir('%s//%s'%(dir,dir_name))
        for file in files:
            os.system('cp %s//%s//%s %s//%s' % (dir,dir_name,file,to_dir,file))
        i=i+1
        
        
def test17():
    test_image_dir='//home//cjq//sum-pic//corpus//image-features'
    image_list='//home//cjq//sum-pic//corpus//test//image-list'
    extract_feature_bin='//home//cjq//sum-pic/caffe/build/tools/extract_features'
    vggnet_model='//home//cjq//sum-pic/caffe/models/16-layer/VGG_ILSVRC_16_layers.caffemodel'
    vggnet_prototo='//home//cjq//sum-pic/caffe/models/16-layer/VGG_ILSVRC_16_layers_deploy.prototxt'
    feature='//home//cjq//sum-pic//corpus//test//feature'
    #os.system('find %s -type f -exec echo {} \; > %s-tmp' % (test_image_dir,image_list))
    #os.system('sed "s/$/ 0/" %s-tmp > %s' % (image_list, image_list))
    os.system('%s %s %s fc7 %s 10 levelfdb' 
              % (extract_feature_bin, vggnet_model, vggnet_prototo, feature));
    
    
def test19():
    l1=np.array([1,2,3,4,5,6,7,8,9])
    l1.tofile('array')
    
    l2=np.fromfile('array', dtype=np.int32)
    print(l2[0])
    
    image = caffe.io.load_image('/home/cjq/sum-pic/corpus/test/image-features/0001d4ce3598e37f20a47fe609736f72e5d73467-8')
    image2 = caffe.io.load_image('/home/cjq/sum-pic/corpus/test/image-features/0001d4ce3598e37f20a47fe609736f72e5d73467-7')
    l3=np.array(image, dtype=np.float32)
    #np.reshape(image, [], order)l3.append(image2)
    print(image[0][0][0])
    
    
def test20():
    test_dir='/home/cjq/sum-pic/corpus/test'
    feature_file_dir=test_dir + '/features'
    feature_file_names=os.listdir(feature_file_dir)
    for feature_file_name in feature_file_names:
        lst=np.fromfile(feature_file_dir+'/'+feature_file_name)
        print(lst,np.float32)
        
        
def test21():
    stories=corpus+'/stories'
    test_stories=corpus+'/test/stories'
    files=os.listdir(stories)
    i=0
    for file in files:
        if i>1000:
            break
        os.system('cp %s/%s %s/%s' % (stories, file, test_stories, file))
        i=i+1
        
        
def test22():
    X = np.random.randn(2, 3, 3)
    Y = np.random.randn(1, 10, 8)
    X=np.asfarray([[[1,1,1],[2,2,2],[3,3,3]],[[11,11,11],[22,22,22],[33,33,33]]]);
    #X[1,6:] = 0
    X_lengths = [10, 6]
    cell = tf.contrib.rnn.BasicLSTMCell(num_units=3, state_is_tuple=True)
    '''outputs, last_states = tf.nn.dynamic_rnn(
        cell=cell,
        dtype=tf.float64,
        inputs=(X))
    cell()'''
    cell(tf.Variable(np.asfarray([[1.,1.,1.],[11.,11.,11.]], np.float32),tf.float32),
         tf.Variable(np.asfarray([[1.,1.,1.]], np.float32),tf.float32))
        
    #result = tf.contrib.learn.run_n(
    #    {"outputs": outputs, "last_states": last_states},
    #    n=1,
    #    feed_dict=None)
    
    #print X
    #assert result[0]["outputs"].shape == (2, 10, 64)
    #assert (result[0]["outputs"][1,7,:] == np.zeros(cell.output_size)).all()
#test22()    
    
def test23():
    input = tf.Variable(tf.ones([1,3,3,5]))  
    filter = tf.Variable(tf.ones([3,3,5,1]))  
      
    op = tf.nn.conv2d(input, filter, strides=[1, 1, 1, 1], padding='SAME')  
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        aop=sess.run(op)
        print(aop)
        
        
def test24():
    image = caffe.io.load_image(common.path_test+'/cat.jpg')
    transformed_image = transformer.preprocess('data', image)
    img=Image.new('RGBA',(224,224))
    img.frombytes(transformed_image[0])
    img.save(common.path_test+'/cat-224-0.png')
    
    
def test25():
    a=tf.Variable([[1,2,3]])
    b=tf.Variable([[1,2,3]])
    c=tf.matmul(a, b,False,True)
    c=tf.Variable([1,2,3])
    d=tf.Variable([4,5,6])

    l1=np.array([1,2,3],np.float32)
    l2=np.array([l1,l1,l1,l1,l1,l1,l1])
    l3=np.array([[1],[1],[1]],np.float32)
    #l1.tofile("t.txt")
    t1=tf.constant(l1)
    t2=tf.constant(l2)
    t3=tf.constant(l3)
    
    t5=tf.matmul(tf.expand_dims(t1,0),tf.expand_dims(t1,0),transpose_b=True)
    t4=tf.matmul(t2,t3)

    #l4=np.vstack((l1,l1))
    #l4=np.vstack((l4,l1))
    #l4=np.vstack((l4,l1))
    #l4=np.vstack((l4,l1))
    #print(l4)
    #c2=tf.assign(c,[d[0],d[1],d[2]])
    #c3=tf.assign(c2,[c[0],c[1],c[2]])
    #f=tf.Variable([a,b])
    #f1=tf.assign(f[0,0,0:1],[0,0])
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        #d=sess.run(c)
        #sess.run(c0)
        #sess.run(c1)
        e=sess.run(t4)
        print(e)
        
        
def test26():
    #l1.tofile("t.txt")
    t1=tf.Variable([[1,2,3],[1,2,3],[1,2,3]],tf.float32)
    #t2=tf.constant(l2)
    att_query = tf.contrib.layers.fully_connected(
        inputs=t1,
        num_outputs=2,
        activation_fn=tf.tanh,
        scope="att_query")
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        dd=sess.run(att_query)
        print(dd)
        
        
def inference_graph():
    data=tf.Variable([[1.0,2.0,3.0],[4.0,5.0,6.0],[7.0,8.0,9.0]],tf.float32)
    layer_size=5
    
    nn_activations = tf.contrib.layers.fully_connected(data, layer_size,scope='nn')
    nn_activations2 = tf.contrib.layers.fully_connected(data, layer_size,reuse=True,scope='nn')
    #nn_activations3 = tf.contrib.layers.fully_connected(data, layer_size,scope='nn')
    #nn_activations = tf.contrib.layers.fully_connected(nn_activations,layer_size)

    
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        dd=sess.run(nn_activations)
        print(dd)
        dd=sess.run(nn_activations2)
        print(dd)
        #dd=sess.run(nn_activations3)
        #print(dd)
        
        
def mask():
    scores_mask = tf.sequence_mask(
        lengths=tf.to_int32(4),
        maxlen=tf.to_int32(7),
        dtype=tf.float32)
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(scores_mask))
        
        
class TT:
    @property
    def length(self):
        return self.length
        
        
def test27():
    tt=TT()
    tt.length=1
    
def test100():
    from tensorflow.python.platform import gfile
    sources='/home/cjq/sum-pic/dailymail/test/story-texts/*'
    if '*' in sources:
        data_files = gfile.Glob('/home/cjq/sum-pic/dailymail/test/story-texts/*')
        print(data_files)
        
def test28():
    a=tf.ones([32,40],tf.int32)
    b=tf.reduce_sum(a)
    with tf.Session() as sess:
        print(sess.run(b))
        
def test29():
    #os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    #os.environ["PATH"] ="$PATH:/usr/local/cuda-8.0/bin" 
    #os.environ["LD_LIBRARY_PATH"] ="/usr/local/cuda-8.0/lib64"
    #a=tf.Variable(tf.random_uniform([100,10], dtype=tf.float32))
    #b=tf.Variable(tf.random_uniform([10,100], dtype=tf.float32))
    #c=tf.matmul(a,b)
    a=tf.Variable(1,tf.float32)
    b=tf.Variable(2,tf.float32)
    c=tf.Variable(3,tf.float32)
    op1=tf.assign(a,tf.add(a,b))
    op2=tf.assign(a,tf.add(a,b))
    op3=tf.assign(a,tf.add(a,c))

    with tf.Session(config=tf.ConfigProto(log_device_placement=True)) as sess:
        sess.run(tf.initialize_all_variables())
        sess.run(op1)
        sess.run(op2)
        sess.run(op3)
        d=sess.run(a)
        print(a)
class Test30:      
    @property  
    def test30(self):
        w=np.fromfile(common.path_vocab_embedding,np.float32)
        w=np.reshape(w,[-1,128])
        w=np.vstack([w,np.zeros([3,128],np.float32)])
        w=tf.get_variable(initializer=w,
                          dtype=tf.float32,name='embedding')
        #tf.get_variable('name', shape, dtype, initializer, regularizer, trainable, collections, caching_device, partitioner, validate_shape, use_resource, custom_getter, constraint)
        print(1)
        return w
    def main(self):
        with tf.Session() as sess:
            sess.run(tf.initialize_all_variables())
            print(sess.run(tf.shape(self.test30)))
            #print(sess.run(tf.shape(self.test30)))

def test31():
    def true_fn():
        print(1)
        return 1
    def false_fn():
        print(2)
        return 2
    a1=tf.Variable(1,tf.int32)
    a2=tf.Variable(2,tf.int32)
    a=tf.cond(tf.less(a1, a2),true_fn,false_fn)
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(a))
        
def test32():
    scores_mask = tf.sequence_mask(
        lengths=tf.constant([5,5,5,5,5],tf.int32),
        maxlen=10,
        dtype=tf.float32)
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(scores_mask))
    
def test33():
    from seq2seq.contrib.seq2seq import helper
    
    input1=tf.ones([4,5],tf.float32)
    input2=tf.ones([4,5,3],tf.float32)
    length=tf.constant([3,2,4,1],tf.float32)
    outputs=tf.ones([4],tf.float32)
    state=tf.ones([4],tf.float32)
    
    hp=helper.TrainingHelper_Ext((input1,input2),length)
    finished, next_targets, next_sents, state=hp.next_inputs(2, outputs, state)
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([next_targets, next_sents]))
        
def test34():
    import seq2seq
    labels=tf.constant([[1.,2.,2.],[4.,5.,6.]],tf.float32)
    logits=tf.constant([[1,0,0],[0,1,0]],tf.float32)
    lengths=tf.constant([1,1,0],tf.float32)
    sigmoid=tf.sigmoid(logits)
    ops=seq2seq.losses.sigmoid_cross_entropy_sequence_loss(targets=labels,logits=logits,sequence_length=lengths)
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(sigmoid))
        
def test35():
    from tensorflow.python.ops.rnn_cell_impl import GRUCell
    from tensorflow.contrib.rnn.python.ops.rnn import stack_bidirectional_dynamic_rnn
    cell=GRUCell(10)
    a1=tf.ones([5,7,3],tf.float32)
    length=tf.constant([3,3,2,2,1],tf.int32)
    b1,b2,b3=stack_bidirectional_dynamic_rnn(
        [cell],[cell],
        a1,
        sequence_length=length,
        dtype=tf.float32,
        scope='doc_caption_encoder')
    with tf.Sessitest32on() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([tf.shape(b1),tf.shape(b2),tf.shape(b3)]))
        
def test36():
    from seq2seq.contrib.seq2seq import decoder
    index=tf.constant(1)
    a1=tf.Variable([[1,2,3,4],[11,12,13,14],[21,22,23,24]])
    a2=decoder._transpose_batch_time(a1)
    ta=tensor_array_ops.TensorArray(dtype=a2.dtype, size=4)
    ua=ta.unstack(a2)
    aa=ua.read(index)
    
    b1=tf.Variable([[[111,112],[121,122],[131,132],[141,142]],[[111,112],[121,122],[131,132],[141,142]],[[111,112],[121,122],[131,132],[141,142]]])
    b2=decoder._transpose_batch_time(b1)
    tb=tensor_array_ops.TensorArray(dtype=b2.dtype, size=4)
    ub=tb.unstack(b2)
    bb=ub.read(index)
    
    sess=tf.Session()
    sess.run(tf.global_variables_initializer())
    print(sess.run([aa, bb]))
    
def test37():
    from seq2seq.contrib.seq2seq import decoder
    a=tf.constant(7,tf.int32)
    a=tf.cond(a>6, lambda: a+1, lambda: a+2)
    mod=tf.mod(a,3)
    div=tf.div(a,3)
    
    a1=tf.Variable([[1,2,3,4],[11,12,13,14],[21,22,23,24]])
    a2=decoder._transpose_batch_time(a1)
    ta=tensor_array_ops.TensorArray(dtype=a2.dtype, size=4, clear_after_read = False)
    ua=ta.unstack(a2)
    #aa=ua.read(mod)
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([ua.read(0)]))
        
def test38():
    sequence_length=tf.constant([[4,5,6],[4,5,6]])
    loss_mask = tf.sequence_mask(tf.to_int32(sequence_length), 7)
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([loss_mask]))
        
def test39():
    str=tf.constant(['abc','123'],tf.string)
    str2=str+'a' + ' ' + 'c'
    str3=tf.concat([str2, ['dfd']],0)
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([str3]))
        
def test40():
    num=tf.constant([[1,2],[3,4]])
    num2=num+1
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([num2]))
        
def test41():
    def true_fn():
        return tf.constant(1)
    a=tf.cond(tf.constant(True),true_fn,false_fn=None)
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([a]))
        
def test42():
    from tensorflow.python.ops import tensor_array_ops
    
    ta = tensor_array_ops.TensorArray(
          dtype=tf.float32,
          size=0,
          dynamic_size=True,
          element_shape=tensor_shape.TensorShape([3, 2]))
    time=0
    def condition(time,ta):
        return time<20
    def loop(time,ta):
        ta=ta.write(time, tf.ones([3,2]))
        return time+1,ta
    _,ta=tf.while_loop(condition,loop,loop_vars=[time,ta])
    size=ta.size()
    bb=ta.read(size-1)
    #ta=ta.write(4,bb)
    #ta=ta.write(3, tf.zeros([3,2])).write(2, tf.zeros([3,2])).write(1, tf.zeros([3,2])).write(0, tf.zeros([3,2]))
    aa=ta.stack()
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([aa,bb]))
        
def test43():
    def tt(a):
        def true_fn():
            return a+1
        def false_fn():
            return a+2
        b=tf.cond(tf.constant(True), true_fn, false_fn)
        return b
    cc=tt(tf.constant(1.0))
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([nn]))
        
def test44():
    from rouge import Rouge
    rouge=Rouge()
    def py_func(sources_value,targets_value):
        scores=rouge.get_scores(sources_value,targets_value)
        return np.float32(scores[0]["rouge-1"]["f"])
    sources_value=tf.constant("geoff whitington , NUM , had diabetes and was on the verge of losing a leg .",tf.string)
    targets_value=tf.constant("his sons anthony and ian helped the father-of-four shed six stone . ",tf.string)
    rouge2 = tf.py_func(
          func=py_func,
          inp=[sources_value, targets_value],
          Tout=tf.float32,
          name="value")
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([rouge2]))
        
class TestClass45():
    def __init__(self):
        self.doc_state=tf.constant(1)
        
    def test45(self):
        from tensorflow.python.ops import tensor_array_ops
        from tensorflow.python.framework import tensor_shape

        time=0
        sent_state = tf.constant(0)
        def condition(time,ta):
            return time<13
        def loop(time, sent_state):
            def true_fn():
                self.doc_state=self.doc_state+sent_state
                return sent_state+self.doc_state
            def false_fn():
                return sent_state + 1
            sent_state=tf.cond(tf.equal(time % 4, 0), true_fn, false_fn)
            return time+1,sent_state
        time, sent_state=tf.while_loop(condition,loop,loop_vars=[time,0])

        with tf.Session() as sess:
            sess.run(tf.initialize_all_variables())
            print(sess.run([time, sent_state]))
            
def test46():
    data=tf.constant([[1,1,1],[2,2,2],[3,3,3],[4,4,4]])
    scores=tf.constant([3,5,1,6])
    next_beam_scores, word_indices = tf.nn.top_k(scores, k=1)
    
    new_data=tf.tile(tf.expand_dims(data[word_indices[0]],0),[tf.shape(data)[0],1])
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        #print(sess.run([next_beam_scores, word_indices]))
        #print(sess.run([data[word_indices[0]]]))
        print(sess.run(new_data))
    
def test47():
    x=tf.constant([3,5,6,8,0])
    op=tf.gather(x, [3])
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(op))
        
def test48():
    x=tf.expand_dims(tf.constant([1,2,3]),1)
    y=tf.one_hot(indices=[1,2], depth=3, on_value=1, off_value=0)
    #z=x*y
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(y))
        
def test49():
    x=tf.constant([[False, False, True, False], [True, False, True, False]])
    x=tf.to_int32(x)
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(x*9-1))
        
def test50():
    x=tf.zeros([5])
    y=tf.ones([3])
    x_len=tf.shape(x)[0]
    y_len=tf.shape(y)[0]
    def true_fn():
        z=tf.concat([y, tf.fill([x_len-y_len],-1.)],0)
        return x, z
    def false_fn():
        z=tf.concat([x, tf.fill([y_len-x_len],-1.)],0)
        return z, y
    x, y = tf.cond(x_len>y_len, true_fn, false_fn)
    z=x+y
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(z))
        
def test51():
    x=tf.constant([0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9])
    y=tf.constant([4,6])
    time=tf.while_loop(cond=lambda time: tf.logical_and(time<tf.shape(x)[0]-2, tf.logical_not(tf.reduce_all(tf.equal(x[time:time+2], y)))), 
                       body=lambda time:time+1, 
                       loop_vars=[0])
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(time<18))
        
def test52():
    def has_bigram(ref_ids, prev_id, cur_id):
        length=tf.shape(ref_ids)[0]-2
        y=tf.concat([tf.expand_dims(prev_id,0),tf.expand_dims(cur_id,0)],0)
        time=tf.while_loop(cond=lambda time: tf.logical_and(time<length, tf.logical_not(tf.reduce_all(tf.equal(ref_ids[time:time+2], y)))), 
                           body=lambda time:time+1, 
                           loop_vars=[0])
        return time<length
    x=tf.constant([0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9])
    z=has_bigram(x, tf.constant(1), tf.constant(4))
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(z))
        
def test53():
    ref_ids=tf.constant([0,1,2,1,3,4,5,6,4,8])
    ref_id_visited=tf.fill(tf.shape(ref_ids),False)
    y=tf.constant([1,1])
    unk=tf.constant(-1)
    depth=10
    def out_body(out_time,ta,ref_id_visited):
        
        def body(time, sign,found,ref_id_visited):
            def true_fn():
                return tf.one_hot(indices=ref_ids[time+1], depth=depth, on_value=1., off_value=0.), tf.constant(True), \
                            tf.logical_or(ref_id_visited,tf.one_hot(indices=time+1, depth=depth, on_value=True, off_value=False))
            def false_fn():
                return tf.zeros([depth]), tf.constant(False), ref_id_visited
            
            new_sign, found, ref_id_visited=tf.cond(tf.logical_and(
                                    #tf.logical_and(tf.not_equal(y[out_time],unk),tf.not_equal(ref_ids[time+1],unk)), 
                                    tf.logical_not(ref_id_visited[time+1]),
                                    tf.equal(ref_ids[time], y[out_time])),
                             true_fn,false_fn)
            return time+1,sign+new_sign,found,ref_id_visited
            
        time,sign,_,ref_id_visited=tf.while_loop(cond=lambda time,sign,found,_: tf.logical_and(time<tf.shape(ref_ids)[0]-1,tf.logical_not(found)), 
                                body=body, 
                                loop_vars=[0,tf.zeros([depth]),tf.constant(False),ref_id_visited])
        
        ta=ta.write(out_time, sign)
        return out_time+1,ta,ref_id_visited
    
    ta = tensor_array_ops.TensorArray(
          dtype=tf.float32,
          size=0,
          dynamic_size=True,
          element_shape=tensor_shape.TensorShape(depth))
    time, ta, _=tf.while_loop(cond=lambda time,ta,ref_id_visited: time<tf.shape(y)[0], 
                              body=out_body, 
                              loop_vars=[0,ta,ref_id_visited])
    output=ta.stack()
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([output]))

def test54():
    word_exists={}
    with gfile.GFile(common.path_vocab) as file:
        for line in file:
            line=line.strip("\n")
            items=line.split("\t")
            word_exists[items[0]]=True
            print(items[0], items[1])
        #vocab_size = sum(1 for _ in file)
        #print(vocab_size)
        
def test55():
    data=tf.constant([1])
    a=tf.tile(data[0:],[5])
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([a]))
        
def test56():
    from collections import namedtuple
    class BeamDecoderOutput_Doc(
        namedtuple("BeamDecoderOutput_Doc", [
            "predicted_ids", "log_probs", "scores", "beam_parent_ids",
            "attention_index"
        ])):
        pass
    
    s=BeamDecoderOutput_Doc(
        predicted_ids=tf.TensorShape([]),
        log_probs=tf.TensorShape([]),
        scores=tf.TensorShape([]),
        beam_parent_ids=tf.TensorShape([]),
        attention_index=tf.TensorShape([]))
    
    t=BeamDecoderOutput_Doc(
        predicted_ids=tf.int32,
        log_probs=tf.float32,
        scores=tf.float32,
        beam_parent_ids=tf.int32,
        attention_index=tf.int32)
    
    outputs_ta = nest.map_structure(lambda t,s:tensor_array_ops.TensorArray(
          dtype=t,
          size=0,
          dynamic_size=True,
          element_shape=s), t, s)
    
    rec=BeamDecoderOutput_Doc(
        predicted_ids=tf.constant(1),
        log_probs=tf.constant(.1),
        scores=tf.constant(.1),
        beam_parent_ids=tf.constant(1),
        attention_index=tf.constant(1))
    
    outputs_ta=nest.map_structure(lambda r,output_ta:output_ta.write(0, r), rec,outputs_ta)
    
    o=nest.map_structure(lambda ta:ta.stack(),outputs_ta)
    
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(o))
    
def test57():
    state=tf.zeros([1,3])
    inputs=tf.ones([2,3])
    def body(time, state):
        return time+1, state+inputs
        
    time, o=tf.while_loop(lambda time,_:time<3, body=body, loop_vars=[0, state])
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(o))
        
def test58():
    import rouge
    r=rouge.Rouge()
    scores=r.get_scores(["UNK and founded in , used to use off UNK million . the own . he says now a prominent for the who have he he prophet government has \' UNK \' . has the that ' that he people are would ' lives lives ' and them lives life ' the ' but of were wanted ' to get up ' . he tuesday he he said in the the blog blog . his the profit speech than and on he church has who , the a own faith as become the own . the from the . become city of . help . he governor says UNK has been the ' ' who his . UNK violence ' ."], 
                        ["cattle rancher cliven bundy allegedly refuses to pay $ NUMm taxes on his herd . bundy has become a hero among locals who claim that the federal government is \' overreaching \' . bundy told supporters on saturday that black people ' abort their young children , put their young men in jail , because they never learned how to pick cotton ' . on thursday , bundy doubled down on his racist comments by making a few more racist comments . the NUM-year-old , father-of-NUM is using his new-found fame to share his views on everything from abortion to the welfare state to slavery . nevada senator harry reid has branded bundy and those protecting him ' domestic terrorists ' ."])
    print(scores[0]['rouge-1']['f'], scores[0]['rouge-2']['f'])
    
def test59():
    a=tf.ones([5])
    b=tf.ones([10])
    c=tf.concat([a,tf.zeros([5])],0)
    
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run(c+b))
        
def test60():
    from collections import namedtuple
    class BeamDecoderOutput_Doc(
        namedtuple("BeamDecoderOutput_Doc", [
            "a", "b"
        ])):
        pass
    n=BeamDecoderOutput_Doc(a=np.array([1,2,3]), b=np.array([4,5,6]))
    m=nest.map_structure(lambda d:d[0], n)
    print(m)
    
def test61():
    ref_ids=tf.constant([7,1,2,1,3,1,0,0,4,0])
    ref_id_visiteds=tf.fill([2,10],False)
    y=tf.constant([4,4])
    unk=tf.constant(-1)
    depth=10
    
    def out_body(out_time,ta,visited_ta):
        
        ref_id_visited=ref_id_visiteds[out_time]
        def body(time, sign,found,ref_id_visited):
            
            def true_fn():
                return tf.one_hot(indices=ref_ids[time+1], depth=depth, on_value=1., off_value=0.), tf.constant(True), \
                            tf.logical_or(ref_id_visited,tf.one_hot(indices=time+1, depth=depth, on_value=True, off_value=False))
                
            def false_fn():
                return tf.zeros([depth]), tf.constant(False), ref_id_visited
            
            new_sign, found, ref_id_visited=tf.cond(tf.logical_and(
                                    #tf.logical_and(tf.not_equal(y[out_time],unk),tf.not_equal(ref_ids[time+1],unk)), 
                                    tf.logical_not(ref_id_visited[time+1]),
                                    tf.equal(ref_ids[time], y[out_time])),
                             true_fn,false_fn)
            
            return time+1,sign+new_sign,found,ref_id_visited
            
        time,sign,found,ref_id_visited=tf.while_loop(cond=lambda time,sign,found,ref_id_visited: tf.logical_and(
                                                        tf.logical_and(time<tf.shape(ref_ids)[0]-1,tf.logical_not(found)), tf.not_equal(ref_ids[time],0)), 
                                body=body, 
                                loop_vars=[0,tf.zeros([depth]),tf.constant(False),ref_id_visited])
        
        ta=ta.write(out_time, sign)
        visited_ta=visited_ta.write(out_time,ref_id_visited)
        
        return out_time+1,ta,visited_ta
    
    ta = tensor_array_ops.TensorArray(
          dtype=tf.float32,
          size=0,
          dynamic_size=True,
          element_shape=tensor_shape.TensorShape(depth))
    
    visited_ta = tensor_array_ops.TensorArray(
          dtype=tf.bool,
          size=0,
          dynamic_size=True,
          element_shape=tensor_shape.TensorShape(10))
    
    time, ta, visited_ta=tf.while_loop(cond=lambda time,ta,visited_ta: time<tf.shape(y)[0], 
                              body=out_body, 
                              loop_vars=[0,ta,visited_ta])
    output=ta.stack()
    visited=visited_ta.stack()
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([output, visited]))
        
def test62():
    a=tf.constant([True, True, True])
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([tf.reduce_all(a)]))
        
def test63():
    import re
    def read_reverse(filename):
        f = open(filename)
        f.seek(0, 2)
        last_position = f.tell()
        #print(last_position)
        while True:
            line = f.readline()
            current_position = f.tell()
            #print(current_position)
            i = 1
            while current_position == last_position:
                if len(line) == current_position:
                    #print line
                    return
                i += 0.5
                f.seek(max(int(-72 * i), -current_position), 1)
                line = f.readline()
                current_position = f.tell()
    
            while current_position != last_position:
                line = f.readline()
                current_position = f.tell()
                #print(line)
            mo=re.match("(\d)*\n", line)
            if mo:
                print(mo.group(0))
                break
                
            #print line
            last_position = last_position - len(line)
            f.seek(max(-72, -last_position) - len(line), 1)
    read_reverse("/home/test/sum-pic/dailymail/abs-sum-pic/caption-attention-hie512-256-DOCNOTEND-4/pred/test-full-300.2")
    
def test64():
    depth=20
    beam_width_sent=3
    unk=tf.constant(99)
    ref_ids=tf.constant([7,1,2,1,3,7,7,0,4,0])
    u_ref_ids,_=tf.unique(ref_ids)
    #u_ref_ids=u_ref_ids-unk*(u_ref_ids==unk)
    ref_ids_len=tf.shape(ref_ids)[0]
    u_ref_ids_len=tf.shape(u_ref_ids)[0]
    
    
    def body(time,indices):
        return time+1, indices+tf.one_hot(indices=u_ref_ids[time], depth=depth, on_value=time+1, off_value=0)
    _,indices=tf.while_loop(cond=lambda time,_: time<tf.shape(u_ref_ids)[0], 
                                body=body, 
                                loop_vars=[0,tf.zeros([depth],dtype=tf.int32)])
    
    def out_body(out_time,ta):
        u_ref_id=u_ref_ids[out_time]
        def body(time, occur):
            
            def true_fn():
                return occur+tf.one_hot(indices=ref_ids[time+1], depth=depth, on_value=1, off_value=0)
                
            def false_fn():
                return occur+tf.zeros([depth],dtype=tf.int32)
            
            occur=tf.cond(tf.logical_or(tf.not_equal(ref_ids[time], u_ref_id), tf.logical_and(tf.equal(ref_ids[time+1], unk), tf.equal(u_ref_id, unk))),false_fn,true_fn)
                                    #tf.logical_and(tf.not_equal(y[out_time],unk),tf.not_equal(ref_ids[time+1],unk)), 
            
            return time+1,occur
        
        time,occur=tf.while_loop(cond=lambda time,_: time<ref_ids_len-1, 
                                body=body, 
                                loop_vars=[0,tf.zeros([depth],dtype=tf.int32)])
        
        ta=ta.write(out_time, occur)
        
        return out_time+1,ta
    
    ta = tensor_array_ops.TensorArray(
          dtype=tf.int32,
          size=0,
          dynamic_size=True,
          element_shape=tensor_shape.TensorShape(depth))
    
    time, ta=tf.while_loop(cond=lambda time,ta: time<u_ref_ids_len, 
                              body=out_body, 
                              loop_vars=[0,ta])
    occurs=ta.stack()
    occurs.set_shape([None, depth])
    occurs=tf.tile(tf.expand_dims(occurs,0),[beam_width_sent,1,1])
    
    
    
    prev_word_ids=tf.constant([7,1,2])
    prev_word_ids_len=tf.shape(prev_word_ids)[0]
    ta = tensor_array_ops.TensorArray(
          dtype=tf.int32,
          size=0,
          dynamic_size=True,
          element_shape=tensor_shape.TensorShape(depth))
    def body(time,ta):
        prev_word_id=prev_word_ids[time]
        index=indices[prev_word_id]-1
        occur=tf.cond(index>-1,lambda:occurs[time][index],lambda:tf.zeros([depth],dtype=tf.int32))
        ta=ta.write(time, occur)
        return time+1,ta
    time, ta=tf.while_loop(cond=lambda time,_: time<prev_word_ids_len, 
                              body=body, 
                              loop_vars=[0,ta])
    occ=ta.stack()
    occ2=tf.to_int32(tf.greater(occ,0))
    
    
    
    next_word_ids=tf.constant([2,2,1])
    def body(time,ta):
        prev_word_id=prev_word_ids[time]
        index=indices[prev_word_id]-1
        def true_fn():
            return occurs[time]-tf.concat([tf.zeros([index,depth],dtype=tf.int32),
                                                  tf.expand_dims(tf.one_hot(next_word_ids[time], depth=depth, on_value=1, off_value=0),0),
                                                  tf.zeros([tf.shape(occurs)[1]-index-1,depth],dtype=tf.int32)],0)
            pass
        def false_fn():
            return occurs[time]
        occur=tf.cond(index>-1,true_fn,false_fn)
        ta=ta.write(time, occur)
        return time+1,ta
    ta = tensor_array_ops.TensorArray(
          dtype=tf.int32,
          size=0,
          dynamic_size=True,
          element_shape=occurs.get_shape()[1:])
    time, ta=tf.while_loop(cond=lambda time,_: time<prev_word_ids_len, 
                              body=body, 
                              loop_vars=[0,ta])
    new_occurs=ta.stack()
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        print(sess.run([new_occurs]))
        
def test65():
    vocab_tensor = tf.constant([6,9,0,99,56,4,2],dtype=tf.int64)
    #count_tensor = tf.constant(counts, dtype=tf.float32)
    vocab_idx_tensor = tf.range(7, dtype=tf.int64)
    
    # Create word -> id mapping
    vocab_to_id_init = tf.contrib.lookup.KeyValueTensorInitializer(
        vocab_tensor, vocab_idx_tensor, tf.int64, tf.int64)
    vocab_to_id_table = tf.contrib.lookup.HashTable(vocab_to_id_init,
                                                  0)
    
    def body(time,table):
        return time+1,table
    time,table=tf.while_loop(cond=lambda time,_:time<5, 
                  body=body, 
                  loop_vars=[0,vocab_to_id_table])
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        sess.run(tf.initialize_all_tables())
        #print(sess.run([vocab_to_id_table.lookup(tf.constant(99,dtype=tf.int64))]))
        print(sess.run([time]))
        
def test66():
    import hashlib
    def Hashhex(s):
        h = hashlib.sha1()
        h.update(s)
        return h.hexdigest()
    
    path_test=common.path_corpus+"/wayback_test_urls.txt"
    path_train=common.path_corpus+"/wayback_training_urls.txt"

    with open(path_test) as file:
        urls=file.readlines()
        lines=[Hashhex(url.strip("\n")) for url in urls]
    
    w_file=open(common.path_corpus+"/test_urls_4.txt", "w")
    for i in range(len(lines)):
        with open(common.path_captions+"/"+lines[i]) as file:
            captions=file.readlines()
            if len(captions)==4:
                w_file.write(urls[i])
                
    
    with open(path_train) as file:
        urls=file.readlines()
        lines=[Hashhex(url.strip("\n")) for url in urls]
    
    w_file=open(common.path_corpus+"/train_urls_4.txt", "w")
    for i in range(len(lines)):
        with open(common.path_captions+"/"+lines[i]) as file:
            captions=file.readlines()
            if len(captions)==4:
                w_file.write(urls[i])
                
def test67():
    import hashlib
    def Hashhex(s):
        h = hashlib.sha1()
        h.update(s)
        return h.hexdigest()
    print(Hashhex("http://web.archive.org/web/20150804054426id_/http://www.dailymail.co.uk/femail/article-3058104/Dad-challenges-public-school-saying-FIVE-YEAR-OLD-daughter-s-rainbow-sundress-revealing.html"))
    print(Hashhex("http://web.archive.org/web/20150804043009id_/http://www.dailymail.co.uk/news/article-3056897/George-Bush-hits-Obama-s-nuclear-deal-Iran-says-successor-losing-war-against-Islamic-State.html"))
    print(Hashhex("http://web.archive.org/web/20150719161503id_/http://www.dailymail.co.uk/femail/food/article-2968211/The-world-s-FLAMING-burger-six-types-chilli-smothered-hot-sauce-set-FIRE-table-sign-waiver-eat-it.html"))
    print(Hashhex("http://web.archive.org/web/20150719144816id_/http://www.dailymail.co.uk/news/article-2968331/ISIS-planning-murder-150-Christian-hostages-does-not-stop-air-strikes.html"))
    print(Hashhex("http://web.archive.org/web/20150719135857id_/http://www.dailymail.co.uk/news/article-2965719/Putin-says-war-Russia-Ukraine-unlikely-TV.html"))



test67()












