# -*- coding: utf-8 -*-

import os
import common
import argparse

def train_text(batch_size=4, gpu=None):
    if gpu is None:
        gpu = 0
        
    VOCAB_SOURCE=common.path_vocab 
    VOCAB_TARGET=common.path_vocab
    TRAIN_SOURCES=common.path_train_file
    TRAIN_TARGETS=common.path_train_file
    DEV_SOURCES=common.path_dev_file
    DEV_TARGETS=common.path_dev_file
    MOFRL_DIR=common.path_model_dir_text 
    
    MODEL_CONFIG=common.path_code_dir+'/configs/abs_sum_pic_hie.yml,'\
                + common.path_code_dir+'/configs/train_seq2seq.yml,'\
                + common.path_code_dir+'/configs/text_metrics_bpe.yml'
    #--train_steps $TRAIN_STEPS \ 
    os.system('''
        export CUDA_VISIBLE_DEVICES=%d
        
        export VOCAB_SOURCE=%s
        export VOCAB_TARGET=%s
        export TRAIN_SOURCES=%s
        export TRAIN_TARGETS=%s
        export DEV_SOURCES=%s
        export DEV_TARGETS=%s
        export TRAIN_STEPS=1000
        export MODEL_DIR=%s
        export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
        
        mkdir -p $MODEL_DIR
            
        python -m bin.train \
              --config_paths="%s" \
              --model_params "
                  vocab_source: $VOCAB_SOURCE 
                  vocab_target: $VOCAB_TARGET" \
              --input_pipeline_train " 
                class: ParallelTextInputPipeline_Text 
                params: 
                  source_files: 
                    - $TRAIN_SOURCES 
                  target_files: 
                    - $TRAIN_TARGETS" \
              --input_pipeline_dev "
                class: ParallelTextInputPipeline_Text 
                params:
                   source_files: 
                    - $DEV_SOURCES 
                   target_files: 
                    - $DEV_TARGETS" \
              --batch_size %d \
              --eval_every_n_steps 5000 \
              --output_dir $MODEL_DIR
    ''' % (gpu, VOCAB_SOURCE, VOCAB_TARGET, TRAIN_SOURCES,TRAIN_TARGETS,DEV_SOURCES,DEV_TARGETS,MOFRL_DIR,MODEL_CONFIG,batch_size))
    
def train_image(batch_size=4, gpu = 1):
    if gpu is None:
        gpu = 1
        
    VOCAB_SOURCE=common.path_vocab
    VOCAB_TARGET=common.path_vocab
    TRAIN_SOURCES=common.path_train_file#common.path_story_texts+'/*'
    TRAIN_TARGETS=common.path_train_file#common.path_story_summaries+'/*'
    TRAIN_IMAGES=common.path_train_file#common.path_image_features+'/*'
    DEV_SOURCES=common.path_dev_file#common.path_story_texts+'/*'
    DEV_TARGETS=common.path_dev_file#common.path_story_summaries+'/*'
    DEV_IMAGES=common.path_dev_file#common.path_image_features+'/*'
    MOFRL_DIR=common.path_model_dir_image 
    
    MODEL_CONFIG=common.path_code_dir+'/configs/abs_sum_pic_image_hie.yml,'\
                + common.path_code_dir+'/configs/train_seq2seq.yml,'\
                + common.path_code_dir+'/configs/text_metrics_bpe.yml'
    #--train_steps $TRAIN_STEPS \ 
    os.system('''
        export CUDA_VISIBLE_DEVICES=%d
        
        export VOCAB_SOURCE=%s
        export VOCAB_TARGET=%s
        export TRAIN_SOURCES=%s
        export TRAIN_TARGETS=%s
        export TRAIN_IMAGES=%s
        export DEV_SOURCES=%s
        export DEV_TARGETS=%s
        export DEV_IMAGES=%s
        export TRAIN_STEPS=1000
        export MODEL_DIR=%s
        export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
        
        mkdir -p $MODEL_DIR
            
        python -m bin.train \
              --config_paths="%s" \
              --model_params "
                  vocab_source: $VOCAB_SOURCE 
                  vocab_target: $VOCAB_TARGET" \
              --input_pipeline_train " 
                class: ParallelTextInputPipeline_Image 
                params: 
                  source_files: 
                    - $TRAIN_SOURCES 
                  target_files: 
                    - $TRAIN_TARGETS
                  image_files:
                    - $TRAIN_IMAGES" \
              --input_pipeline_dev "
                class: ParallelTextInputPipeline_Image 
                params:
                   source_files: 
                    - $DEV_SOURCES 
                   target_files: 
                    - $DEV_TARGETS
                   image_files:
                    - $DEV_IMAGES" \
              --batch_size %d \
              --eval_every_n_steps 10000 \
              --output_dir $MODEL_DIR
    ''' % (gpu, VOCAB_SOURCE, VOCAB_TARGET, TRAIN_SOURCES,TRAIN_TARGETS,TRAIN_IMAGES,DEV_SOURCES,
           DEV_TARGETS,DEV_IMAGES,MOFRL_DIR,MODEL_CONFIG,batch_size))

def train_caption(batch_size=4, gpu = 0):
    if gpu is None:
        gpu = 0
        
    VOCAB_SOURCE=common.path_vocab
    VOCAB_TARGET=common.path_vocab
    TRAIN_SOURCES=common.path_train_file
    TRAIN_TARGETS=common.path_train_file
    TRAIN_CAPTIONS=common.path_train_file
    DEV_SOURCES=common.path_dev_file
    DEV_TARGETS=common.path_dev_file
    DEV_CAPTIONS=common.path_dev_file
    MOFRL_DIR=common.path_model_dir_caption 
    
    MODEL_CONFIG=common.path_code_dir+'/configs/abs_sum_pic_caption_hie.yml,'\
                + common.path_code_dir+'/configs/train_seq2seq.yml,'\
                + common.path_code_dir+'/configs/text_metrics_bpe.yml'
    #--train_steps $TRAIN_STEPS \ 
    os.system('''
        export CUDA_VISIBLE_DEVICES=%d
        
        export VOCAB_SOURCE=%s
        export VOCAB_TARGET=%s
        export TRAIN_SOURCES=%s
        export TRAIN_TARGETS=%s
        export TRAIN_CAPTIONS=%s
        export DEV_SOURCES=%s
        export DEV_TARGETS=%s
        export DEV_CAPTIONS=%s
        export TRAIN_STEPS=1000
        export MODEL_DIR=%s
        export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
        
        mkdir -p $MODEL_DIR
            
        python -m bin.train \
              --config_paths="%s" \
              --model_params "
                  vocab_source: $VOCAB_SOURCE 
                  vocab_target: $VOCAB_TARGET" \
              --input_pipeline_train " 
                class: ParallelTextInputPipeline_Caption 
                params: 
                  source_files: 
                    - $TRAIN_SOURCES 
                  target_files: 
                    - $TRAIN_TARGETS
                  caption_files:
                    - $TRAIN_CAPTIONS" \
              --input_pipeline_dev "
                class: ParallelTextInputPipeline_Caption 
                params:
                   source_files: 
                    - $DEV_SOURCES 
                   target_files: 
                    - $DEV_TARGETS
                   caption_files:
                    - $DEV_CAPTIONS" \
              --batch_size %d \
              --eval_every_n_steps 5000 \
              --output_dir $MODEL_DIR
    ''' % (gpu, VOCAB_SOURCE, VOCAB_TARGET, TRAIN_SOURCES,TRAIN_TARGETS,TRAIN_CAPTIONS,DEV_SOURCES,DEV_TARGETS,
           DEV_CAPTIONS,MOFRL_DIR,MODEL_CONFIG,batch_size))
  
def train_image_caption(batch_size=4, gpu=0):
    if gpu is None:
        gpu = 0
        
    VOCAB_SOURCE=common.path_vocab
    VOCAB_TARGET=common.path_vocab
    TRAIN_SOURCES=common.path_train_file
    TRAIN_TARGETS=common.path_train_file
    TRAIN_CAPTIONS=common.path_train_file
    TRAIN_IMAGES=common.path_train_file
    DEV_SOURCES=common.path_dev_file
    DEV_TARGETS=common.path_dev_file
    DEV_CAPTIONS=common.path_dev_file
    DEV_IMAGES=common.path_dev_file
    MOFRL_DIR=common.path_model_dir_image_caption 
    
    MODEL_CONFIG=common.path_code_dir+'/configs/abs_sum_pic_image_caption_hie.yml,'\
                + common.path_code_dir+'/configs/train_seq2seq.yml,'\
                + common.path_code_dir+'/configs/text_metrics_bpe.yml'
    #--train_steps $TRAIN_STEPS \ 
    os.system('''
        export CUDA_VISIBLE_DEVICES=%d
        
        export VOCAB_SOURCE=%s
        export VOCAB_TARGET=%s
        export TRAIN_SOURCES=%s
        export TRAIN_TARGETS=%s
        export TRAIN_CAPTIONS=%s
        export TRAIN_IMAGES=%s
        export DEV_SOURCES=%s
        export DEV_TARGETS=%s
        export DEV_CAPTIONS=%s
        export DEV_IMAGES=%s
        export TRAIN_STEPS=1000
        export MODEL_DIR=%s
        export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
        
        mkdir -p $MODEL_DIR
            
        python -m bin.train \
              --config_paths="%s" \
              --model_params "
                  vocab_source: $VOCAB_SOURCE 
                  vocab_target: $VOCAB_TARGET" \
              --input_pipeline_train " 
                class: ParallelTextInputPipeline_Image_Caption 
                params: 
                  source_files: 
                    - $TRAIN_SOURCES 
                  target_files: 
                    - $TRAIN_TARGETS
                  caption_files:
                    - $TRAIN_CAPTIONS
                  image_files:
                    - $TRAIN_IMAGES " \
              --input_pipeline_dev "
                class: ParallelTextInputPipeline_Image_Caption 
                params:
                   source_files: 
                    - $DEV_SOURCES 
                   target_files: 
                    - $DEV_TARGETS
                   caption_files:
                    - $DEV_CAPTIONS
                   image_files:
                    - $DEV_IMAGES" \
              --batch_size %d \
              --eval_every_n_steps 10000 \
              --output_dir $MODEL_DIR
    ''' % (gpu, VOCAB_SOURCE, VOCAB_TARGET, TRAIN_SOURCES,TRAIN_TARGETS,TRAIN_CAPTIONS,TRAIN_IMAGES,
           DEV_SOURCES,DEV_TARGETS,DEV_CAPTIONS,DEV_IMAGES,MOFRL_DIR,MODEL_CONFIG,batch_size))


def train_image_caption_2(batch_size=4, gpu=0):
    if gpu is None:
        gpu = 0
        
    VOCAB_SOURCE=common.path_vocab
    VOCAB_TARGET=common.path_vocab
    TRAIN_SOURCES=common.path_train_file
    TRAIN_TARGETS=common.path_train_file
    TRAIN_CAPTIONS=common.path_train_file
    TRAIN_IMAGES=common.path_train_file
    DEV_SOURCES=common.path_dev_file
    DEV_TARGETS=common.path_dev_file
    DEV_CAPTIONS=common.path_dev_file
    DEV_IMAGES=common.path_dev_file
    MOFRL_DIR=common.path_model_dir_image_caption_2 
    
    MODEL_CONFIG=common.path_code_dir+'/configs/abs_sum_pic_image_caption_2_hie.yml,'\
                + common.path_code_dir+'/configs/train_seq2seq.yml,'\
                + common.path_code_dir+'/configs/text_metrics_bpe.yml'
    #--train_steps $TRAIN_STEPS \ 
    os.system('''
        export CUDA_VISIBLE_DEVICES=%d
        
        export VOCAB_SOURCE=%s
        export VOCAB_TARGET=%s
        export TRAIN_SOURCES=%s
        export TRAIN_TARGETS=%s
        export TRAIN_CAPTIONS=%s
        export TRAIN_IMAGES=%s
        export DEV_SOURCES=%s
        export DEV_TARGETS=%s
        export DEV_CAPTIONS=%s
        export DEV_IMAGES=%s
        export TRAIN_STEPS=1000
        export MODEL_DIR=%s
        export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
        
        mkdir -p $MODEL_DIR
            
        python -m bin.train \
              --config_paths="%s" \
              --model_params "
                  vocab_source: $VOCAB_SOURCE 
                  vocab_target: $VOCAB_TARGET" \
              --input_pipeline_train " 
                class: ParallelTextInputPipeline_Image_Caption 
                params: 
                  source_files: 
                    - $TRAIN_SOURCES 
                  target_files: 
                    - $TRAIN_TARGETS
                  caption_files:
                    - $TRAIN_CAPTIONS
                  image_files:
                    - $TRAIN_IMAGES " \
              --input_pipeline_dev "
                class: ParallelTextInputPipeline_Image_Caption 
                params:
                   source_files: 
                    - $DEV_SOURCES 
                   target_files: 
                    - $DEV_TARGETS
                   caption_files:
                    - $DEV_CAPTIONS
                   image_files:
                    - $DEV_IMAGES" \
              --batch_size %d \
              --eval_every_n_steps 10000 \
              --output_dir $MODEL_DIR
    ''' % (gpu, VOCAB_SOURCE, VOCAB_TARGET, TRAIN_SOURCES,TRAIN_TARGETS,TRAIN_CAPTIONS,TRAIN_IMAGES,
           DEV_SOURCES,DEV_TARGETS,DEV_CAPTIONS,DEV_IMAGES,MOFRL_DIR,MODEL_CONFIG,batch_size))

  
def infer_caption():
    MOFRL_DIR=common.path_model_dir_caption 
    TEST_SOURCES=common.path_dev_file
    os.system('''
        export MODEL_DIR=%s
        export TEST_SOURCES=%s
        export PRED_DIR=$MODEL_DIR/pred-fenhao-8
        mkdir -p ${PRED_DIR}
        
        python -m bin.infer \
          --tasks "
            - class: DecodeText" \
          --model_dir $MODEL_DIR \
          --input_pipeline "
            class: ParallelTextInputPipeline_Caption
            params:
              source_files:
                - $TEST_SOURCES
              target_files: 
                - $TEST_SOURCES
              caption_files:
                - $TEST_SOURCES" \
          >  ${PRED_DIR}/predictions-infer.txt
        ''' % (MOFRL_DIR, TEST_SOURCES))
    
def beam_search_caption():
    MOFRL_DIR=common.path_model_dir_caption 
    TEST_SOURCES=common.path_dev_file
    
    os.system('''
        export MODEL_DIR=%s
        export TEST_SOURCES=%s
        export PRED_DIR=$MODEL_DIR/pred-fenhao-8
        mkdir -p ${PRED_DIR}
        
        python -m bin.infer \
          --tasks "
            - class: DecodeText
            - class: DumpBeams
              params:
                file: ${PRED_DIR}/beams.npz" \
          --model_dir $MODEL_DIR \
          --model_params "
            inference.beam_search.beam_width: 5" \
          --input_pipeline "
            class: ParallelTextInputPipeline_Caption
            params:
              source_files:
                - $TEST_SOURCES
              target_files: 
                - $TEST_SOURCES
              caption_files:
                - $TEST_SOURCES" \
          > ${PRED_DIR}/predictions-beam-search.txt
        ''' % (MOFRL_DIR, TEST_SOURCES))
    
def main():
    parser = argparse.ArgumentParser(description='sum-pic args')
    parser.add_argument(
      '--action', choices=['train', 'infer', 'beam-search'], default='train')
    parser.add_argument(
      '--mode', choices=['caption', 'image', 'image-caption', 'image-caption-2', 'text'], default='text')
    parser.add_argument('--batch_size', type=int, default=4)
    parser.add_argument('--gpu', type=int, default=None)
    args = parser.parse_args()
    if args.action == 'train':
        if args.mode == 'image':
          while True:
            train_image(args.batch_size, args.gpu)
        elif args.mode == 'caption':
          while True:
            train_caption(args.batch_size, args.gpu)
        elif args.mode == 'image-caption':
          while True:
            train_image_caption(args.batch_size, args.gpu)
        elif args.mode == 'image-caption-2':
          while True:
            train_image_caption_2(args.batch_size, args.gpu)
        elif args.mode == 'text':
          while True:
            train_text(args.batch_size, args.gpu)
    elif args.action == 'beam-search':
        if args.mode == 'image':
            pass
        elif args.mode == 'caption':
            pass
        elif args.mode == 'image-caption':
            pass
    elif args.action == 'infer':
        if args.mode == 'image':
            pass
        elif args.mode == 'caption':
            pass
        elif args.mode == 'image-caption':
            pass

if __name__=='__main__':
    main()
    










