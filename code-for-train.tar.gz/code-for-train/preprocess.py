# -*- coding: utf-8 -*-
import numpy as np
import os, sys, threading, time
import matplotlib.pyplot as plt
import pylab
# display plots in this notebook
#%matplotlib inline
#import caffe
from multiprocessing.pool import Pool
from multiprocessing.pool import ThreadPool
from itertools import izip
from itertools import repeat

import collections
import re

import common

from nltk.tokenize.stanford import StanfordTokenizer
import nltk

import word2vec

def load_caffe(batch_size=1):
    caffe.set_mode_cpu()
    model_def = common.path_proto
    model_weights = common.path_model
    net = caffe.Net(model_def,      # defines the structure of the model
                    model_weights,  # contains the trained weights
                    caffe.TEST)     # use test mode (e.g., don't perform dropout)
    
    # load the mean ImageNet image (as distributed with Caffe) for subtraction
    mu = np.load(common.path_mean)
    mu = mu.mean(1).mean(1)  # average over pixels to obtain the mean (BGR) pixel values
    print 'mean-subtracted values:', zip('BGR', mu)
    # create transformer for the input called 'data'
    transformer = caffe.io.Transformer({'data': net.blobs['data'].data.shape})
    transformer.set_transpose('data', (2,0,1))  # move image channels to outermost dimension
    transformer.set_mean('data', mu)            # subtract the dataset-mean value in each channel
    transformer.set_raw_scale('data', 255)      # rescale from [0, 1] to [0, 255]
    transformer.set_channel_swap('data', (2,1,0))  # swap channels from RGB to BGR
    
    # set the size of the input (we can skip this if we're happy
    #  with the default; we can also change it later, e.g., for different batch sizes)
    net.blobs['data'].reshape(batch_size,        # batch size
                              3,         # 3-channel (BGR) images
                              224, 224)  # image size is 227x227
    
    return net, transformer

def generate_image_list():
    image_file_subdirs=os.listdir(common.path_images)
    print(len(image_file_subdirs))
    image_list_file=open(common.path_image_list+'-0', 'w')
    file_count=0
    print(1)
    for image_file_subdir in image_file_subdirs:
        if not os.path.exists(common.path_image_features+'/'+image_file_subdir):
            print(common.path_image_features+'/'+image_file_subdir)
            if file_count==60000:
                image_list_file.close()
                image_list_file=open(common.path_image_list+'-1', 'w')
            image_file_names=os.listdir(common.path_images+'/'+image_file_subdir)
            for image_file_name in image_file_names:
                image_list_file.write(image_file_name+'\n')
            file_count=file_count+1
            pass
    
    image_list_file.close()

def extract_image_features_test():
    feature_file_test_dir=common.path_corpus + '/test/image-features'
    image_file_test_dir=common.path_corpus + '/test/images'
    story_test_dir=common.path_corpus + '/test/story-summaries'
    
    caffe.set_mode_cpu()
    model_def = common.path_proto
    model_weights = common.path_model
    net = caffe.Net(model_def,      # defines the structure of the model
                    model_weights,  # contains the trained weights
                    caffe.TEST)     # use test mode (e.g., don't perform dropout)
    
    # load the mean ImageNet image (as distributed with Caffe) for subtraction
    mu = np.load(common.path_mean)
    mu = mu.mean(1).mean(1)  # average over pixels to obtain the mean (BGR) pixel values
    print 'mean-subtracted values:', zip('BGR', mu)
    # create transformer for the input called 'data'
    transformer = caffe.io.Transformer({'data': net.blobs['data'].data.shape})
    transformer.set_transpose('data', (2,0,1))  # move image channels to outermost dimension
    transformer.set_mean('data', mu)            # subtract the dataset-mean value in each channel
    transformer.set_raw_scale('data', 255)      # rescale from [0, 1] to [0, 255]
    transformer.set_channel_swap('data', (2,1,0))  # swap channels from RGB to BGR
    
    # set the size of the input (we can skip this if we're happy
    #  with the default; we can also change it later, e.g., for different batch sizes)
    net.blobs['data'].reshape(1,        # batch size
                              3,         # 3-channel (BGR) images
                              224, 224)  # image size is 227x227
    
    count=0
    count2=0
    story_test_files=os.listdir(story_test_dir)
    for story_test in story_test_files:
        os.system('cp '+common.path_corpus+'/captions/'+story_test+' '+common.path_corpus+'/test/captions/'+story_test)
        
        image_file_test=image_file_test_dir+'/'+story_test
        if not os.path.exists(image_file_test):
            os.mkdir(image_file_test)
        if not os.path.exists(common.path_corpus+'/test/image-features/'+story_test):
            os.mkdir(common.path_corpus+'/test/image-features/'+story_test)
            
        image_file=common.path_images+'/'+story_test
        images=os.listdir(image_file)
        for pimage in images:
            os.system('cp '+image_file+'/'+pimage+' '+image_file_test+'/'+pimage)
            if not os.path.exists(common.path_corpus+'/image-features/'+story_test):
                os.mkdir(common.path_corpus+'/image-features/'+story_test)
            if not os.path.exists(common.path_corpus+'/image-features/'+story_test+'/'+pimage):
                try:
                    image = caffe.io.load_image(common.path_corpus+'/images/'+story_test+'/'+pimage)
                    transformed_image = transformer.preprocess('data', image)
                    net.blobs['data'].data[...] = transformed_image
                    ### perform classification
                    output = net.forward()
                    #output_prob = output['prob'][0]  # the output probability vector for the first image in the batch
                    fc=output['fc7']
                    #print 'predicted class is:', output_prob.argmax()
                    #print(output)
                    print(count2, count, pimage, len(fc), len(fc[0]))
                    fc.tofile(common.path_corpus+'/image-features/'+story_test+'/'+pimage)
                except ValueError:
                    print(common.path_images+'/'+image_file+'/'+pimage)
            os.system('cp '+common.path_corpus+'/image-features/'+story_test+'/'+pimage+' '+common.path_corpus+'/test/image-features/'+story_test+'/'+pimage)

def extract_image_features_all():
    net, transformer=load_caffe(1)
    image_file_subdirs=os.listdir(common.path_images)
    print(len(image_file_subdirs))
    extract_image_features(image_file_subdirs,net, transformer)
    
def extract_image_features_list():
    common.path_image_list=common.path_corpus+'/image-dirs'
    with open(common.path_image_list+'-1') as file:
        file_paths=file.readlines()
    file_names=[os.path.basename(file_name.replace('\n','')) for file_name in file_paths]
    extract_image_features(file_names)
    
    
def extract_image_features(image_name_list, net, transformer):
    count=0
    count2=0
    for image_file_subdir in image_name_list:
        count2=count2+1
        if not os.path.exists(common.path_image_features+'/'+image_file_subdir):
            os.mkdir(common.path_image_features+'/'+image_file_subdir)
            
        image_file_names=os.listdir(common.path_images+'/'+image_file_subdir)
        for image_file_name in image_file_names:
            count=count+1
            if os.path.exists(common.path_image_features+'/'+image_file_subdir+'/'+image_file_name):
                #print(count2, count, image_file_name)
                continue
            
            try:
                image = caffe.io.load_image(common.path_images+'/'+image_file_subdir+'/'+image_file_name)
                transformed_image = transformer.preprocess('data', image)
                net.blobs['data'].data[...] = transformed_image
                output = net.forward()
                fc=output['conv5_4']
                print(count2, count, image_file_name, len(fc), len(fc[0]))
                fc.tofile(common.path_image_features+'/'+image_file_subdir+'/'+image_file_name)
            except ValueError:
                print('ValueError: '+common.path_images+'/'+image_file_subdir+'/'+image_file_name)
            except IOError:
                print('IOError: '+common.path_images+'/'+image_file_subdir+'/'+image_file_name)
    print(count2,count)         
                
def extract_image_features_list_batch(batch_size=10):
    with open(common.path_image_list+'-1') as file:
        file_names=file.readlines()
    with open(common.path_image_list+'-1-u') as file:
        file_names_u=file.readlines()
    
    net, transformer=load_caffe(batch_size)
    
    file_names=[file_name.replace('\n','') for file_name in file_names]
    file_names_u=[file_name.replace('\n','') for file_name in file_names_u]
    file_names=[file_name for file_name in file_names if file_name not in file_names_u]
    
    image_num=len(file_names)
    batch_num=image_num/batch_size
    u_file=open(common.path_image_list+'-1-u','a')
    for batch_index in range(batch_num):
        extract_image_features_batch(file_names[batch_size*batch_index:batch_size*(batch_index+1)], net, transformer)
        for i in range(batch_size):
            file_name=file_names[batch_size*batch_index+i]
            print(batch_index, file_name)
            u_file.write(file_name+'\n')
        u_file.flush()
    u_file.close()
    
def extract_image_features_batch(image_names, net, transformer):
    batch_size=len(image_names)
    for i in range(batch_size):
        try:
            image_name=image_names[i]
            image_dir_name=image_name.split('-')[0]
            image = caffe.io.load_image(common.path_images+'/'+image_dir_name+'/'+image_name)
            transformed_image = transformer.preprocess('data', image)
            net.blobs['data'].data[i,...] = transformed_image
        except ValueError:
            print('error0: '+common.path_images+'/'+image_dir_name+'/'+image_name)
        
    output = net.forward()
    fc=output['conv5_4']
        
    for i in range(batch_size):
        try:
            image_name=image_names[i]
            image_dir_name=image_name.split('-')[0]
            if not os.path.exists(common.path_image_features+'/'+image_dir_name):
                os.mkdir(common.path_image_features+'/'+image_dir_name)
            fc[i].tofile(common.path_image_features+'/'+image_dir_name+'/'+image_name)
        except ValueError:
            print('error1: '+common.path_images+'/'+image_dir_name+'/'+image_name)
            
'''def merge_image_features():
    old_dirs=os.listdir(common.path_image_features+'-bak')
    for old_dir in old_dirs:
        old_feature_names=os.listdir(common.path_image_features+'-bak/'+old_dir)
        old_feature_names=sorted(old_feature_names, key=lambda d : int(d.split('-')[-1].split('.')[0]))
        old_features=[np.fromfile(common.path_image_features+'-bak/'+old_dir+'/'+old_feature_name) 
                      for old_feature_name in old_feature_names]
        new_features=np.array([],dtype=np.float32)
        #for old_feature in old_features:
        #    new_features.concatenate(0,old_feature)
        if len(old_features)!=0:
            new_features=np.concatenate(old_features,0)
            new_features.tofile(common.path_image_features+'/'+old_dir)
            print(np.shape(new_features))
        else:
            wfile=open(common.path_image_features+'/'+old_dir,'wb')
            wfile.close()'''
                
def merge_image_features():
    import struct
    path_image_features=common.path_image_features_split
    
    def Mapper(t):
        dir_name, n=t
        
        file=open(path_image_features+'/'+dir_name,'wb')
        file_names=os.listdir(path_image_features+'-bak/'+dir_name)
        file_names=sorted(file_names, key=lambda d : int(d.split('-')[-1].split('.')[0]))
        for file_name in file_names:
            feas=np.fromfile(path_image_features+'-bak/'+dir_name+'/'+file_name,np.float32)
            for fea in feas:
                file.write(struct.pack('f',fea))
        file.close()
        
        print(n, dir_name)
        
        return True
    
    def Mode(request_parallelism):
        dir_names=os.listdir(path_image_features+'-bak')
    
        p = ThreadPool(request_parallelism)
    
        results = p.imap_unordered(Mapper, izip(dir_names, range(len(dir_names))))
        i=0
        try:
            for ok in results:
                i=i+1
        except KeyboardInterrupt:
            print 'Interrupted by user'
            
    Mode(5)


def extract_story_and_summary():
    tokenizer = StanfordTokenizer(path_to_jar=r"/home/cjq/eclipse/libs/stanford-parser/stanford-parser.jar")
    def preprocess_line(line=''):
        line=line.lower()
        #line=re.sub(r'[\.,\'\"\?\:\;\!]',lambda m:' '+m.group(0), line, 0)
        #line=re.sub(r'[\\\/\(\)\|\[\]\+\=\-\{\}]',lambda m:' '+m.group(0)+' ', line, 0)
        line=' '.join(tokenizer.tokenize(line)).replace('`','\'')
        #line=re.sub(r'[^a-zA-Z0-9\s\.,\'\"\?\:\;\!\\\/\(\)\|\[\]\+\=\-\{\}]','', line, 0)
        line=re.sub(r'[^\x00-\x7F]','', line, 0)
        line=re.sub(r'([0-9]+(,[0-9]{3})*)(.[0-9]{1,2})?','NUM', line, 0)
        return line
    
    story_file_names=os.listdir(common.path_stories)
    count=0
    print(common.path_stories)
    for story_file_name in story_file_names:
        count=count+1
        print(count,story_file_name)
        story_file=open(common.path_stories+'/'+story_file_name)
        story_file_name=os.path.splitext(story_file_name)[0]
        stroy_text_file=open(common.path_story_texts+'/'+story_file_name, 'w')
        stroy_summary_file=open(common.path_story_summaries+'/'+story_file_name, 'w')
        
        is_highlight=False
        need_return=True
        for line in story_file.readlines():
            line=line.strip().replace('\n', '').replace('\r', '')
            if line=='@highlight':
                is_highlight=True
                continue
            if not is_highlight:
                if line=='':
                    if need_return:
                        stroy_text_file.write('\n')
                        need_return=False
                else:
                    stroy_text_file.write(preprocess_line(line)+' ')
                    need_return=True
            else:
                if line=='':
                    if need_return:
                        stroy_summary_file.write('\n')
                        need_return=False
                else:
                    stroy_summary_file.write(preprocess_line(line)+' ')
                    need_return=True
             
        story_file.close()
        stroy_text_file.close()
        stroy_summary_file.close()
        
def process_summaries():
    files=os.listdir(common.path_story_summaries+'-bak')
    for file in files:
        with open(common.path_story_summaries+'-bak/'+file) as rfile:
            text=rfile.read()
            text=re.sub(r'\n','. \n', text, 0)
            text=text+'. '
            #print(text)
            with open(common.path_story_summaries+'/'+file,'w') as wfile:
                wfile.write(text)
        
def merge_text():
    tokenizer = StanfordTokenizer(path_to_jar=common.path_parser)
    def merge_corpus():
        with open(common.path_word_embedding_corpus,'w') as source_file:
            file_names=os.listdir(common.path_story_texts)
            for file_name in file_names:
                with open(common.path_story_texts+'/'+file_name) as file:
                    source_file.write(file.read())
                
            file_names=os.listdir(common.path_story_summaries)
            for file_name in file_names:
                with open(common.path_story_texts+'/'+file_name) as file:
                    source_file.write(file.read())
    
    def merge_billion():
        with open(common.path_word_embedding_billion,'w') as source_file:
            file_names=os.listdir(common.path_word_embedding_billion_orign)
            print(file_names)
            for file_name in file_names:
                with open(common.path_word_embedding_billion_orign+'/'+file_name) as file:
                    source_file.write(common.preprocess_line(tokenizer,file.read()))
                    
    def merge_all():
        sources=[common.path_word_embedding_corpus,common.path_word_embedding_billion]
        with open(common.path_word_embedding_source_all,'w') as source_file:
            for file_name in sources:
                with open(file_name) as file:
                    source_file.write(file.read())
        
    #merge_corpus()
    merge_billion()
    merge_all()
    
def build_vocab():
    data=[]
    file_names=os.listdir(common.path_story_texts)
    for file_name in file_names:
        with open(common.path_story_texts+'/'+file_name, 'r') as file:
            words=file.read().replace('\n','').split()
            data.extend(words)
            
    file_names=os.listdir(common.path_story_summaries)
    for file_name in file_names:
        with open(common.path_story_summaries+'/'+file_name, 'r') as file:
            words=file.read().replace('\n','').split()
            data.extend(words)
            
    file_names=os.listdir(common.path_captions)
    for file_name in file_names:
        with open(common.path_captions+'/'+file_name, 'r') as file:
            words=file.read().replace('\n','').split()
            data.extend(words)

    counter = collections.Counter(data)
    count_pairs = sorted(counter.items(), key=lambda x: (-x[1], x[0]))
    word_list=[word for word, count in count_pairs]
    
    count=0 
    with open(common.path_vocab_tsc, 'w') as vocab:
        for item1, item2 in count_pairs:
            if count>40000:
                break
            print(item1, item2)
            vocab.write('%s\t%s\n' % (item1, item2))
            count=count+1
    '''count_pairs = sorted(counter.items(), key=lambda x: (-x[1], x[0]))
    words, _ = list(zip(*count_pairs))
    word_to_id = dict(zip(words, range(len(words))))
    return word_to_id'''
            
def build_word2vec():
    def create_word2vec():
        word2vec.word2vec(common.path_word_embedding_source_all, common.path_word_embedding_target, size=128, verbose=True)
    def vocab_embedding(path_vocab, path_embedding):
        model = word2vec.load(common.path_word_embedding_target)
        with open(path_vocab) as file:
            vocab=[line.split('\t')[0] for line in file.readlines()]
            embeddings=[]
            for word in vocab:
                embeddings.append(model[word])
            embeddings=np.array(embeddings,np.float32)
            embeddings.tofile(path_embedding)
    def vocab():
        model = word2vec.load(common.path_word_embedding_target)
        embeddings=np.fromfile(common.path_vocab_embedding_tsc, np.float32)
        embeddings=np.reshape(embeddings, [-1, 128])
        print(np.shape(embeddings))
        count = 0
        with open("/home/test/vocab-new", "w") as file:
            for i in range(40000):
                #print(embeddings[i])
                word=model.get_word(embeddings[i])
                print(word)
                file.write("%s\t0\n" % word)

    vocab_embedding(common.path_vocab_tsc, common.path_vocab_embedding_tsc)
    #test()
            
    #print(model.vocab)
    #print(model.vectors.shape)
    #print(model['extremely'])
    #indexes, metrics = model.cosine('NUM')
    #print(model.vocab[indexes])
    #word2vec.word2phrase(common.path_story_texts+'/00a1c2c7394101bbcefe155bb793af06224f6559', common.path_word_embedding+'/00a1c2c7394101bbcefe155bb793af06224f6559-phrase', verbose=True)
    #print(common.path_story_texts+'/00a1c2c7394101bbcefe155bb793af06224f6559', common.path_word_embedding+'/00a1c2c7394101bbcefe155bb793af06224f6559')
    #word2vec.word2clusters(common.path_story_texts+'/00a1c2c7394101bbcefe155bb793af06224f6559', common.path_word_embedding+'/00a1c2c7394101bbcefe155bb793af06224f6559.cluster', 100, verbose=True)

def process_story_and_summaries():
    def StroyMapper(t):
        story_file_name, tokenizer,n=t
        story_file=open(common.path_stories+'/'+story_file_name)
        story_file_name=os.path.splitext(story_file_name)[0]
        stroy_text_file=open(common.path_story_texts+'/'+story_file_name, 'w')
        stroy_summary_file=open(common.path_story_summaries+'/'+story_file_name, 'w')
            
        is_highlight=False
        need_return=True
        for line in story_file.readlines():
            line=line.strip().replace('\n', '').replace('\r', '')
            if line=='@highlight':
                is_highlight=True
                continue
            if not is_highlight:
                if line=='':
                    if need_return:
                        stroy_text_file.write('\n')
                        need_return=False
                else:
                    stroy_text_file.write(common.preprocess_line(tokenizer,line)+' ')
                    need_return=True
            else:
                if line=='':
                    if need_return:
                        stroy_summary_file.write('\n')
                        need_return=False
                else:
                    stroy_summary_file.write(common.preprocess_line(tokenizer,line)+' ')
                    need_return=True
                 
        story_file.close()
        stroy_text_file.close()
        stroy_summary_file.close()
        print(n, story_file_name)
        return True
    
    def StroyMode(request_parallelism):
        tokenizer = StanfordTokenizer(path_to_jar=r"/home/test/eclipse/libs/stanford-parser/stanford-parser.jar")
        stroy_file_names=os.listdir(common.path_stories)
    
        p = ThreadPool(request_parallelism)
    
        results = p.imap_unordered(StroyMapper, izip(stroy_file_names, repeat(tokenizer), range(len(stroy_file_names))))
        i=0
        try:
            for ok in results:
                i=i+1
        except KeyboardInterrupt:
            print 'Interrupted by user'
            
    StroyMode(10)
    
    
def build_train_dev_test_files():
    import hashlib
    def Hashhex(s):
        h = hashlib.sha1()
        h.update(s)
        return h.hexdigest()
    
    stories=os.listdir(common.path_stories)
    stories=[os.path.splitext(line)[0] for line in stories]

    with open(common.path_corpus+'/wayback_training_urls.txt') as train_file:
        files=[Hashhex(line.strip('\n')) for line in train_file.readlines()]
    files=[file for file in files if file in stories]
    with open(common.path_corpus+'/trains','w') as wfile:
        wfile.write('\n'.join(files))
    
    with open(common.path_corpus+'/wayback_validation_urls.txt') as train_file:
        files=[Hashhex(line.strip('\n')) for line in train_file.readlines()]
    files=[file for file in files if file in stories]
    with open(common.path_corpus+'/devs','w') as wfile:
        wfile.write('\n'.join(files))
    
    with open(common.path_corpus+'/wayback_test_urls.txt') as train_file:
        files=[Hashhex(line.strip('\n')) for line in train_file.readlines()]
    files=[file for file in files if file in stories]
    with open(common.path_corpus+'/tests','w') as wfile:
        wfile.write('\n'.join(files))
        
def build_captions(request_parallelism=10):
    path_captions_bak=common.path_captions+'-bak'
    def Mapper(t):
        file_name, tokenizer,n=t
        with open(path_captions_bak+'/'+file_name) as cap_file:
            with open(common.path_captions+'/'+file_name,'w') as new_cap_file:
                line1=''
                line2=''
                indice_bak=[]
                for line in cap_file.readlines():
                    if re.match(r'^(\d+ )+$', line):        
                        if line1 != '' and line2 != '':
                            line1=line1.strip('\n').strip(' ')
                            line2=line2.strip('\n')
                            line2=common.preprocess_line(tokenizer, line2)
                            indice=line1.split(' ')
                            indice_bak.append(indice)
                            #print(file_name, indice)
                            for _ in indice:
                                new_cap_file.write(line2+'\n')
                        line1=line
                        line2=''
                    else:
                        line2=line2+line
                
                if line1 != '' and line2 != '':
                    line1=line1.strip('\n').strip(' ')
                    line2=line2.strip('\n')
                    line2=common.preprocess_line(tokenizer, line2)
                    indice=line1.split(' ')
                    indice_bak.append(indice)
                    #print(n,file_name, indice)
                    for _ in indice:
                        new_cap_file.write(line2+'\n')
                                
        print(n, file_name, indice_bak)
        return True

    def build():
        tokenizer = StanfordTokenizer(path_to_jar=common.path_parser)
        file_names=os.listdir(path_captions_bak)
        p = ThreadPool(request_parallelism)
        results = p.imap_unordered(Mapper, izip(file_names, repeat(tokenizer), range(len(file_names))))
        i=0
        try:
            for ok in results:
                i=i+1
        except KeyboardInterrupt:
            print 'Interrupted by user'
            
    def post_process():
        story_file_names=os.listdir(common.path_story_texts)
        caption_file_names=os.listdir(common.path_captions)
        stroy_not_have_captions=[file_name for file_name in story_file_names if file_name not in caption_file_names]
        for file_name in stroy_not_have_captions:
            with open(common.path_captions+'/'+file_name,'w'):
                print(file_name)
                
    #build()
    post_process() 
    
def create_test_data():
    path_dailymail_test=common.path_sum_pic+"/dailymail-test"
    path_train_file=common.path_corpus+"/test-trains"
    path_dev_file=common.path_corpus+"/test-devs"
    path_test_file=common.path_corpus+"/test-tests"
    path_files=(path_train_file,path_dev_file,path_test_file)
    
    path_image_features=path_dailymail_test+"/image-features"
    path_captions=path_dailymail_test+"/captions"
    path_story_summaries=path_dailymail_test+"/story-summaries"
    path_story_texts=path_dailymail_test+"/story-texts"
    path_tos=[path_image_features,path_captions,path_story_summaries,path_story_texts]
    
    path_froms=[common.path_image_features,common.path_captions,common.path_story_summaries,common.path_story_texts]
    
    for path_file in path_files:
        with open(path_file) as file:
            for line in file.readlines():
                line=line.strip("\n")
                
                for path_from,path_to in zip(path_froms,path_tos):
                    if not os.path.exists(path_to):
                        os.mkdir(path_to)
                    os.system('''
                        cp %s %s
                    ''' % (path_from+"/"+line,path_to+"/"+line))
                

def test():
    with open(common.path_dev_file) as dev:
        for file_name in dev.readlines():
            file_name=file_name.strip('\n')
            with open(common.path_captions+'/'+file_name) as file:
                print(file_name, file.read())
    
if __name__=='__main__':
    #os.system('export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin')  
    #extract_image_features_all()
    #extract_image_features()
    #extract_image_features_list()
    #extract_image_features_list_batch(batch_size=50)
    #generate_image_list()
    #ImageFeatureMode(3)
    #extract_image_features_test()
    #build_vocab()
    build_word2vec()
    #extract_story_and_summary()
    #process_summaries()
    #merge_image_features()
    #extract_image_features_test2()
    #generate_image_list()
    #imageTest2()
    
    #rouge_test()
    #build_train_dev_test_files()
    #merge_text()
    #build_captions()
    #os.system('mkdir dd')
    #test()
    #create_test_data()








