
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import tensorflow as tf
from tensorflow.contrib.slim.python.slim.data import data_decoder

import common

class SplitTokensDecoder(data_decoder.DataDecoder):

  def __init__(self,
               delimiter=" ",
               tokens_feature_name="tokens",
               length_feature_name="length",
               prepend_token=None,
               append_token=None):
    self.delimiter = delimiter
    self.tokens_feature_name = tokens_feature_name
    self.length_feature_name = length_feature_name
    self.prepend_token = prepend_token
    self.append_token = append_token

  def decode(self, data, items):
    decoded_items = {}

    tokens = tf.string_split([data], delimiter=self.delimiter).values

    if self.prepend_token is not None:
      tokens = tf.concat([[self.prepend_token], tokens], 0)

    if self.append_token is not None:
      tokens = tf.concat([tokens, [self.append_token]], 0)

    decoded_items[self.length_feature_name] = tf.size(tokens)
    decoded_items[self.tokens_feature_name] = tokens
    return [decoded_items[_] for _ in items]

  def list_items(self):
    return [self.tokens_feature_name, self.length_feature_name]

class SplitSentsAndTokensDecoder(data_decoder.DataDecoder):
  def __init__(self,
               sent_delimiter="\n",
               word_delimiter=" ",
               tokens_feature_name="tokens",
               length_doc_name="doc_length",
               length_sents_name="sents_length",
               sent_prepend_token=None,
               sent_prepend_token_2=None,
               sent_append_token=None,
               doc_append_token=None):
    self.sent_delimiter = sent_delimiter
    self.word_delimiter = word_delimiter
    self.tokens_feature_name = tokens_feature_name
    self.length_doc_name = length_doc_name
    self.length_sents_name = length_sents_name
    self.sent_prepend_token = sent_prepend_token
    self.sent_prepend_token_2 = sent_prepend_token_2
    self.sent_append_token = sent_append_token
    self.doc_append_token = doc_append_token

  def decode(self, data, items):
    
    def true_fn():
        true_items={}
        if self.doc_append_token is not None:
            #sentences = tf.concat([sentences, [self.append_token]], 0)
            true_items[self.length_doc_name] = tf.constant(1,tf.int32)
            true_items[self.length_sents_name] = tf.constant([1],tf.int32)
            true_items[self.tokens_feature_name] = tf.constant([[self.doc_append_token]],tf.string)
        else:
            true_items[self.length_doc_name] = tf.constant(0,tf.int32)
            true_items[self.length_sents_name] = tf.constant([0],tf.int32)
            true_items[self.tokens_feature_name] = tf.constant([['']],tf.string)
        
        return true_items
    
    def false_fn():
        false_items={}
        
        sentences = tf.string_split([data], delimiter=self.sent_delimiter).values
        
        doc_end=self.doc_append_token
        
        if self.sent_prepend_token_2 is not None:
            sentences = self.sent_prepend_token_2 + " " +sentences
            
        if self.sent_prepend_token is not None:
            sentences = self.sent_prepend_token + " " +sentences
            doc_end = self.sent_prepend_token + " " +doc_end
            
        if self.sent_append_token is not None:
            sentences = sentences + " " + self.sent_append_token
            
        if self.doc_append_token is not None:
            sentences = tf.concat([sentences, [doc_end]], 0)
        
        sentences = tf.string_split(sentences, delimiter=self.word_delimiter)
        sentences=tf.sparse_to_dense(sentences.indices, sentences.dense_shape, sentences.values, '')
    
        sent_lens=tf.reduce_sum(tf.where(tf.equal(sentences, ''),tf.zeros(tf.shape(sentences), dtype=tf.int32),
                                         tf.ones(tf.shape(sentences), dtype=tf.int32)),[1])

        false_items[self.length_doc_name] = tf.size(sent_lens)
        false_items[self.length_sents_name] = sent_lens
        false_items[self.tokens_feature_name] = sentences

        return false_items

    decoded_items=tf.cond(tf.equal(data, ''), true_fn, false_fn)
    
    return [decoded_items[_] for _ in items]

  def list_items(self):
    return [self.tokens_feature_name, self.length_doc_name, self.length_sents_name]

class ImageMatrixDecoder(data_decoder.DataDecoder):

  def __init__(self,
               tokens_feature_name="tokens",
               length_feature_name="length"):
    self.tokens_feature_name = tokens_feature_name
    self.length_feature_name = length_feature_name

  def decode(self, data, items):
    
    def true_fn():
        true_items={}
        true_items[self.tokens_feature_name] = tf.zeros([1,4096],tf.float32)
        true_items[self.length_feature_name] = tf.constant(0, tf.int32)
        print(1)
        return true_items
    
    def false_fn():
        false_items={}
        value = tf.decode_raw(bytes=data, out_type=tf.float32)
        #value = tf.slice(input_=value, begin=[0], size=[-1])
        
        value = tf.reshape(value,(-1, 4096))
        
        false_items[self.tokens_feature_name] = value
        false_items[self.length_feature_name] = tf.shape(value)[0]

        return false_items

    decoded_items=tf.cond(tf.equal(data, ''), true_fn, false_fn)
    
    return [decoded_items[_] for _ in items]

  def list_items(self):
    return [self.tokens_feature_name, self.length_feature_name]

class ImageMatrixDecoder_Pixel(ImageMatrixDecoder):

  def decode(self, data, items):
    
    def true_fn():
        true_items={}
        true_items[self.tokens_feature_name] = tf.zeros([1,common.num_pix,common.dim_pix],tf.float32)
        true_items[self.length_feature_name] = tf.constant(0, tf.int32)

        return true_items
    
    def false_fn():
        false_items={}
        value = tf.decode_raw(bytes=data, out_type=tf.float32)
        
        value = tf.reshape(value,(-1,common.num_pix,common.dim_pix))
        
        false_items[self.tokens_feature_name] = value
        false_items[self.length_feature_name] = tf.shape(value)[0]

        return false_items

    decoded_items=tf.cond(tf.equal(data, ''), true_fn, false_fn)
    
    return [decoded_items[_] for _ in items]












