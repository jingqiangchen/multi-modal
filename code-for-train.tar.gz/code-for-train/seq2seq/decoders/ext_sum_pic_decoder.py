
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from collections import namedtuple
import tensorflow as tf
from seq2seq.decoders.rnn_decoder import RNNDecoder

from seq2seq.contrib.seq2seq.helper import CustomHelper
from seq2seq.training import utils as training_utils


class ExtSumPicDecoderOutput(
    namedtuple("DecoderOutput", [
        "logits", "predicted_ids", "cell_output", "text_scores",
        "text_context", "pic_scores", "pic_context"
    ])):
  pass


class ExtSumPicDecoder(RNNDecoder):
    
  def __init__(self,
               params,
               mode,
               sents,
               docs,
               images,
               doc_len,
               image_len,
               attention_fn, 
               reverse_scores_lengths=None,
               name="ExtSumPicDecoder"):
    super(ExtSumPicDecoder, self).__init__(params, mode, name)
    self.sents = sents
    self.docs = docs
    self.images = images
    self.doc_len = doc_len
    self.image_len = image_len
    self.attention_fn=attention_fn, 
    self.reverse_scores_lengths = reverse_scores_lengths

  @property
  def output_size(self):
    return ExtSumPicDecoderOutput(
        logits=self.vocab_size,
        predicted_ids=tf.TensorShape([]),
        cell_output=self.cell.output_size,
        text_scores=tf.shape(self.attention_values[0])[1:-1],
        text_context=self.attention_values[0].get_shape()[-1],
        pic_scores=tf.shape(self.attention_values[1])[1:-1],
        pic_context=self.attention_values[1].get_shape()[-1])

  @property
  def output_dtype(self):
    return ExtSumPicDecoderOutput(
        logits=tf.float32,
        predicted_ids=tf.int32,
        cell_output=tf.float32,
        text_scores=tf.float32,
        text_context=tf.float32,
        pic_scores=tf.float32,
        pic_context=tf.float32)

  def initialize(self, name=None):
    finished, first_inputs = self.helper.initialize()
    input1, input2 = first_inputs
    first_inputs = (input1, input2, None)

    return finished, first_inputs, self.initial_state

  def _setup(self, initial_state, helper):
    self.initial_state = initial_state

    def att_next_inputs(time, outputs, state, sample_ids, name=None):

      finished, next_inputs, next_state = helper.next_inputs(
          time=time,
          outputs=outputs,
          state=state,
          sample_ids=sample_ids,
          name=name)
      
      input1, input2 = next_inputs
      next_inputs = (input1, input2, outputs.summary)
      
      return (finished, next_inputs, next_state)

    self.helper = CustomHelper(
        initialize_fn=helper.initialize,
        sample_fn=helper.sample,
        next_inputs_fn=att_next_inputs)

  def compute_output(self, inputs, state):

    targets, sents, summary = inputs
    
    sent_salience = tf.contrib.layers.fully_connected(
        inputs=sents,
        num_outputs=1,
        activation_fn=None,
        scope="sent_salience")
    logits = sent_salience
    
    doc_content = tf.contrib.layers.fully_connected(
        inputs=sents,
        num_outputs=tf.shape(self.docs)[-1],
        activation_fn=None,
        scope="doc_content")
    doc_content = doc_content * self.docs
    doc_content = tf.reduce_sum(doc_content, 1)
    logits += doc_content
    
    if summary is not None:
        redundency = tf.contrib.layers.fully_connected(
            inputs=sents,
            num_outputs=tf.shape(summary)[-1],
            activation_fn=None,
            scope="doc_content")
        redundency = redundency * summary
        redundency = tf.reduce_sum(redundency, 1)
        logits += redundency
         
    pic_scores, pic_context = self.attention_fn(query=sents, values=self.images, values_length=self.image_len)
    sum_pic_scores = tf.reduce_sum(pic_scores, 1)
    logits += sum_pic_scores
    
    

    return logits

  def step(self, time_, inputs, state, name=None):

    logits = \
      self.compute_output(inputs, state)

    sample_ids = self.helper.sample(
        time=time_, outputs=logits, state=state)
    
    targets, sents, summary = inputs
    if summary is None:
        summary = tf.sigmoid(logits) * sents
    else:
        summary = summary + tf.sigmoid(logits) * sents
          
    outputs = ExtSumPicDecoderOutput(
        logits=logits,
        predicted_ids=sample_ids,
        summary=summary,
        pic_scores=None,
        pic_context=None)    

    finished, next_inputs, next_state = self.helper.next_inputs(
        time=time_, outputs=outputs, state=state, sample_ids=sample_ids)

    return (outputs, next_state, next_inputs, finished)




