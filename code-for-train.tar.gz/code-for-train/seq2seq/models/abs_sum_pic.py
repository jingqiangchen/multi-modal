
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from pydoc import locate

import tensorflow as tf

from seq2seq import decoders
from seq2seq.models.basic_seq2seq import BasicSeq2Seq
from seq2seq import graph_utils
from seq2seq.data import vocab
from seq2seq.models import bridges

from seq2seq.contrib.seq2seq import helper as tf_decode_helper


class AbsSumPic(BasicSeq2Seq):

  def __init__(self, params, mode, name="abs_sum_pic"):
    #params=AbsSumPic.default_params()
    super(AbsSumPic, self).__init__(params, mode, name)

  @staticmethod
  def default_params():
    params = BasicSeq2Seq.default_params().copy()
    params.update({
        "attention.class": "AttentionLayerAbsSumPicBahdanau",
        "attention.params": {}, # Arbitrary attention layer parameters
        "bridge.class": "seq2seq.models.bridges.AbsSumPicBridge",
        "encoder.class": "seq2seq.encoders.AbsSumPicRNNEncoder",
        "encoder.params": {},  # Arbitrary parameters for the encoder
        "decoder.class": "seq2seq.decoders.AbsSumPicDecoder",
        "decoder.params": {}  # Arbitrary parameters for the decoder
    })
    return params

  def _create_decoder(self, encoder_output, features, _labels):
    attention_class = locate(self.params["attention.class"]) or \
      getattr(decoders.attention, self.params["attention.class"])
    attention_layer = attention_class(
        params=self.params["attention.params"], mode=self.mode)

    reverse_scores_lengths = None
    if self.params["source.reverse"]:
      reverse_scores_lengths = features["source_len"]
      if self.use_beam_search:
        reverse_scores_lengths = tf.tile(
            input=reverse_scores_lengths,
            multiples=[self.params["inference.beam_search.beam_width"]])

    return self.decoder_class(
        params=self.params["decoder.params"],
        mode=self.mode,
        vocab_size=self.target_vocab_info.total_size,
        attention_values=(encoder_output.attention_values, encoder_output.image_tokens),
        attention_values_length=(encoder_output.attention_values_length, encoder_output.image_num),
        attention_keys=(encoder_output.attention_values, encoder_output.image_tokens),
        attention_fn=attention_layer,
        reverse_scores_lengths=reverse_scores_lengths)
    
  def _preprocess(self, features, labels):
    source_vocab_to_id, source_id_to_vocab, source_word_to_count, _ = \
      vocab.create_vocabulary_lookup_table(self.source_vocab_info.path)

    target_vocab_to_id, target_id_to_vocab, target_word_to_count, _ = \
      vocab.create_vocabulary_lookup_table(self.target_vocab_info.path)

    graph_utils.add_dict_to_collection({
        "source_vocab_to_id": source_vocab_to_id,
        "source_id_to_vocab": source_id_to_vocab,
        "source_word_to_count": source_word_to_count,
        "target_vocab_to_id": target_vocab_to_id,
        "target_id_to_vocab": target_id_to_vocab,
        "target_word_to_count": target_word_to_count
    }, "vocab_tables")

    '''if self.params["source.max_seq_len"] is not None:
      features["source_tokens"] = features["source_tokens"][:, :self.params[
          "source.max_seq_len"]]
      features["source_len"] = tf.minimum(features["source_len"],
                                          self.params["source.max_seq_len"])'''

    features["source_ids"] = source_vocab_to_id.lookup(features["source_tokens"])

    '''if self.params["source.reverse"] is True:
      features["source_ids"] = tf.reverse_sequence(
          input=features["source_ids"],
          seq_lengths=features["source_len"],
          seq_dim=1,
          batch_dim=0,
          name=None)'''

    features["source_doc_length"] = tf.to_int32(features["source_doc_length"])
    tf.summary.histogram("source_doc_length", tf.to_float(features["source_doc_length"]))
    
    features["source_sents_length"] = tf.to_int32(features["source_sents_length"])
    tf.summary.histogram("source_sents_length", tf.to_float(features["source_sents_length"]))

    if labels is None:
      return features, None

    labels = labels.copy()

    '''if self.params["target.max_seq_len"] is not None:
      labels["target_tokens"] = labels["target_tokens"][:, :self.params["target.max_seq_len"]]
      labels["target_len"] = tf.minimum(labels["target_len"],self.params["target.max_seq_len"])'''

    labels["target_ids"] = target_vocab_to_id.lookup(labels["target_tokens"])

    labels["target_len"] = tf.to_int32(labels["target_len"])
    tf.summary.histogram("target_len", tf.to_float(labels["target_len"]))

    num_tokens = tf.reduce_sum(labels["target_len"])
    num_tokens += tf.reduce_sum(features["source_sents_length"])
    token_counter_var = tf.Variable(0, "tokens_counter")
    total_tokens = tf.assign_add(token_counter_var, num_tokens)
    tf.summary.scalar("num_tokens", total_tokens)

    with tf.control_dependencies([total_tokens]):
      features["source_tokens"] = tf.identity(features["source_tokens"])

    graph_utils.add_dict_to_collection(features, "features")
    if labels:
      graph_utils.add_dict_to_collection(labels, "labels")
    print(labels['target_len'].get_shape())
    return features, labels

  def encode(self, features, labels):
    source_embedded = tf.nn.embedding_lookup(self.source_embedding,
                                             features["source_ids"])

    encoder_fn = self.encoder_class(self.params["encoder.params"], self.mode)
    return encoder_fn(source_embedded, features)

  def _create_bridge(self, encoder_outputs, decoder_state_size):
    bridge_class = locate(self.params["bridge.class"]) or \
      getattr(bridges, self.params["bridge.class"])
    return bridge_class(
        encoder_outputs=encoder_outputs,
        decoder_state_size=decoder_state_size,
        params=self.params["bridge.params"],
        mode=self.mode)

  def decode(self, encoder_output, features, labels):
    decoder = self._create_decoder(encoder_output, features, labels)
    
    if self.use_beam_search:
      decoder = self._get_beam_search_decoder(decoder)

    bridge = self._create_bridge(
        encoder_outputs=encoder_output,
        decoder_state_size=decoder.cell.state_size)
    
    if self.mode == tf.contrib.learn.ModeKeys.INFER:
      return self._decode_infer(decoder, bridge, encoder_output, features,
                                labels)
    else:
      return self._decode_train(decoder, bridge, encoder_output, features,
                                labels)

class AbsSumPic_Hie(AbsSumPic):
    
  def __init__(self, params, mode, name="abs_sum_pic_caption"):
    #params=AbsSumPic.default_params()
    super(AbsSumPic_Hie, self).__init__(params, mode, name)
    
  @staticmethod
  def default_params():
    params = BasicSeq2Seq.default_params().copy()
    params.update({
        "attention.class": "AbsSumPicBahdanau_Hie",
        "attention.params": {}, # Arbitrary attention layer parameters
        "bridge.class": "seq2seq.models.bridges.AbsSumPicBridge_Hie",
        "encoder.class": "seq2seq.encoders.AbsSumPicRNNEncoder_Hie",
        "encoder.params": {},  # Arbitrary parameters for the encoder
        "decoder.class": "seq2seq.decoders.AbsSumPicDecoder_Hie",
        "decoder.params": {}  # Arbitrary parameters for the decoder
    })
    return params

  def encode(self, features, labels):
    source_embedded = tf.nn.embedding_lookup(self.source_embedding,
                                             features["source_ids"])

    encoder_fn = self.encoder_class(self.params["encoder.params"], self.mode)
    return encoder_fn(source_embedded,features,self.params["embedding.dim"])

  def _create_decoder(self, encoder_output, features, _labels):
    attention_class = locate(self.params["attention.class"]) or \
      getattr(decoders.attention, self.params["attention.class"])
    attention_layer = attention_class(
        params=self.params["attention.params"], mode=self.mode)

    reverse_scores_lengths = None
    if self.params["source.reverse"]:
      reverse_scores_lengths = features["source_len"]
      if self.use_beam_search:
        reverse_scores_lengths = tf.tile(
            input=reverse_scores_lengths,
            multiples=[self.params["inference.beam_search.beam_width"]])

    return self.decoder_class(
        params=self.params["decoder.params"],
        mode=self.mode,
        vocab_size=self.target_vocab_info.total_size,
        attention_values=encoder_output.attention_values,
        attention_values_length=encoder_output.attention_values_length,
        attention_keys=encoder_output.attention_values,
        attention_fn=attention_layer,
        reverse_scores_lengths=reverse_scores_lengths)

  def _decode_train(self, decoder, bridge, _encoder_output, _features, labels):
    target_embedded = tf.nn.embedding_lookup(self.target_embedding,
                                             labels["target_ids"])

    target_embedded=target_embedded[:,:,:-1,:]
    '''shape=tf.shape(target_embedded)
    target_embedded=tf.reshape(target_embedded,[shape[0],-1,shape[-1]])'''
    helper_train = tf_decode_helper.TrainingHelper_Hie(
        inputs=target_embedded,
        sequence_length=(labels["target_num"], labels["target_len"]-1), embedding_dim=self.params['embedding.dim'])
    decoder_initial_state = bridge()
    
    return decoder(decoder_initial_state, helper_train)

  def _decode_infer(self, decoder, bridge, _encoder_output, features, labels):
    """Runs decoding in inference mode"""
    batch_size = self.batch_size(features, labels)
    if self.use_beam_search:
      batch_size = self.params["inference.beam_search.beam_width"]

    target_start_id = self.target_vocab_info.special_vocab.SEQUENCE_START
    helper_infer = tf_decode_helper.GreedyEmbeddingHelper_Hie(
        embedding=self.target_embedding,
        start_tokens=tf.fill([batch_size], target_start_id),
        sent_end_token=self.target_vocab_info.special_vocab.SEQUENCE_END,
        doc_end_token=self.target_vocab_info.special_vocab.DOC_END,
        doc_not_end_token=self.target_vocab_info.special_vocab.DOC_NOT_END)
    decoder_initial_state = bridge()
    return decoder(decoder_initial_state, helper_infer)

class AbsSumPic_Caption_Hie(AbsSumPic):
    
  def __init__(self, params, mode, name="abs_sum_pic_caption"):
    #params=AbsSumPic.default_params()
    super(AbsSumPic_Caption_Hie, self).__init__(params, mode, name)
    
  @staticmethod
  def default_params():
    params = BasicSeq2Seq.default_params().copy()
    params.update({
        "attention.class": "AbsSumPicBahdanau_Caption",
        "attention.params": {}, # Arbitrary attention layer parameters
        "bridge.class": "seq2seq.models.bridges.AbsSumPicBridge_Caption",
        "encoder.class": "seq2seq.encoders.AbsSumPicRNNEncoder_Caption",
        "encoder.params": {},  # Arbitrary parameters for the encoder
        "decoder.class": "seq2seq.decoders.AbsSumPicDecoder",
        "decoder.params": {}  # Arbitrary parameters for the decoder
    })
    return params

  def encode(self, features, labels):
    source_embedded = tf.nn.embedding_lookup(self.source_embedding,
                                             features["source_ids"])
    
    caption_embedded = tf.nn.embedding_lookup(self.source_embedding,
                                             features["caption_ids"])

    encoder_fn = self.encoder_class(self.params["encoder.params"], self.mode)
    return encoder_fn(source_embedded,caption_embedded,features,self.params["embedding.dim"])

  def _preprocess(self, features, labels):
    
    features, labels=super(AbsSumPic_Caption_Hie, self)._preprocess(features, labels)
    
    source_vocab_to_id, source_id_to_vocab, source_word_to_count, _ = \
      vocab.create_vocabulary_lookup_table(self.source_vocab_info.path)
    
    features["caption_ids"] = source_vocab_to_id.lookup(features["caption_tokens"])
    
    features["caption_num"] = tf.to_int32(features["caption_num"])
    tf.summary.histogram("caption_num", tf.to_float(features["caption_num"]))

    features["caption_len"] = tf.to_int32(features["caption_len"])
    tf.summary.histogram("caption_len", tf.to_float(features["caption_len"]))

    return features, labels

  def _decode_train(self, decoder, bridge, _encoder_output, _features, labels):
    target_embedded = tf.nn.embedding_lookup(self.target_embedding,
                                             labels["target_ids"])

    target_embedded=target_embedded[:,:,:-1,:]
    '''shape=tf.shape(target_embedded)
    target_embedded=tf.reshape(target_embedded,[shape[0],-1,shape[-1]])'''
    helper_train = tf_decode_helper.TrainingHelper_Hie(
        inputs=target_embedded,
        sequence_length=(labels["target_num"], labels["target_len"]-1), embedding_dim=self.params['embedding.dim'])
    decoder_initial_state = bridge()
    
    return decoder(decoder_initial_state, helper_train)

  def _decode_infer(self, decoder, bridge, _encoder_output, features, labels):
    """Runs decoding in inference mode"""
    batch_size = self.batch_size(features, labels)
    if self.use_beam_search:
      batch_size = self.params["inference.beam_search.beam_width"]

    target_start_id = self.target_vocab_info.special_vocab.SEQUENCE_START
    helper_infer = tf_decode_helper.GreedyEmbeddingHelper_Hie(
        embedding=self.target_embedding,
        start_tokens=tf.fill([batch_size], target_start_id),
        sent_end_token=self.target_vocab_info.special_vocab.SEQUENCE_END,
        doc_end_token=self.target_vocab_info.special_vocab.DOC_END,
        doc_not_end_token=self.target_vocab_info.special_vocab.DOC_NOT_END)
    decoder_initial_state = bridge()
    return decoder(decoder_initial_state, helper_infer)


class AbsSumPic_Image_Hie(AbsSumPic):
    
  def __init__(self, params, mode, name="abs_sum_pic_image"):
    #params=AbsSumPic.default_params()
    super(AbsSumPic_Image_Hie, self).__init__(params, mode, name)
    
  @staticmethod
  def default_params():
    params = BasicSeq2Seq.default_params().copy()
    params.update({
        "attention.class": "AbsSumPicBahdanau_Image",
        "attention.params": {}, # Arbitrary attention layer parameters
        "bridge.class": "seq2seq.models.bridges.AbsSumPicBridge_Image",
        "encoder.class": "seq2seq.encoders.AbsSumPicRNNEncoder_Image",
        "encoder.params": {},  # Arbitrary parameters for the encoder
        "decoder.class": "seq2seq.decoders.AbsSumPicDecoder_Image",
        "decoder.params": {}  # Arbitrary parameters for the decoder
    })
    return params

  def encode(self, features, labels):
    source_embedded = tf.nn.embedding_lookup(self.source_embedding,
                                             features["source_ids"])

    encoder_fn = self.encoder_class(self.params["encoder.params"], self.mode)
    
    return encoder_fn(source_embedded, features, self.params["embedding.dim"])

  def _decode_train(self, decoder, bridge, _encoder_output, _features, labels):
    target_embedded = tf.nn.embedding_lookup(self.target_embedding,
                                             labels["target_ids"])

    target_embedded=target_embedded[:,:,:-1,:]

    helper_train = tf_decode_helper.TrainingHelper_Hie(
        inputs=target_embedded,
        sequence_length=(labels["target_num"], labels["target_len"]-1), embedding_dim=self.params['embedding.dim'])
    decoder_initial_state = bridge()
    
    return decoder(decoder_initial_state, helper_train)

  def _decode_infer(self, decoder, bridge, _encoder_output, features, labels):
    """Runs decoding in inference mode"""
    batch_size = self.batch_size(features, labels)
    if self.use_beam_search:
      batch_size = self.params["inference.beam_search.beam_width"]

    target_start_id = self.target_vocab_info.special_vocab.SEQUENCE_START
    helper_infer = tf_decode_helper.GreedyEmbeddingHelper_Hie(
        embedding=self.target_embedding,
        start_tokens=tf.fill([batch_size], target_start_id),
        sent_end_token=self.target_vocab_info.special_vocab.SEQUENCE_END,
        doc_end_token=self.target_vocab_info.special_vocab.DOC_END,
        doc_not_end_token=self.target_vocab_info.special_vocab.DOC_NOT_END)
    decoder_initial_state = bridge()
    return decoder(decoder_initial_state, helper_infer)


class AbsSumPic_Image_Caption_Hie(AbsSumPic_Caption_Hie):
  def __init__(self, params, mode, name="abs_sum_pic_image_caption"):
    #params=AbsSumPic.default_params()
    super(AbsSumPic_Image_Caption_Hie, self).__init__(params, mode, name)
    
  @staticmethod
  def default_params():
    params = BasicSeq2Seq.default_params().copy()
    params.update({
        "attention.class": "AbsSumPicBahdanau_Image_Caption",
        "attention.params": {}, # Arbitrary attention layer parameters
        "bridge.class": "seq2seq.models.bridges.AbsSumPicBridge_Image_Caption",
        "encoder.class": "seq2seq.encoders.AbsSumPicRNNEncoder_Image_Caption",
        "encoder.params": {},  # Arbitrary parameters for the encoder
        "decoder.class": "seq2seq.decoders.AbsSumPicDecoder",
        "decoder.params": {}  # Arbitrary parameters for the decoder
    })
    return params

  def _create_decoder(self, encoder_output, features, _labels):
    attention_class = locate(self.params["attention.class"]) or \
      getattr(decoders.attention, self.params["attention.class"])
    attention_layer = attention_class(
        params=self.params["attention.params"], mode=self.mode)

    reverse_scores_lengths = None
    if self.params["source.reverse"]:
      reverse_scores_lengths = features["source_len"]
      if self.use_beam_search:
        reverse_scores_lengths = tf.tile(
            input=reverse_scores_lengths,
            multiples=[self.params["inference.beam_search.beam_width"]])

    image_tokens, caption_tokens = encoder_output.image_tokens
    image_num, caption_num = encoder_output.image_num
    return self.decoder_class(
        params=self.params["decoder.params"],
        mode=self.mode,
        vocab_size=self.target_vocab_info.total_size,
        attention_values=(encoder_output.attention_values, image_tokens, caption_tokens),
        attention_values_length=(encoder_output.attention_values_length, image_num, caption_num),
        attention_keys=(encoder_output.attention_values, image_tokens, caption_tokens),
        attention_fn=attention_layer,
        reverse_scores_lengths=reverse_scores_lengths)

  def encode(self, features, labels):
    source_embedded = tf.nn.embedding_lookup(self.source_embedding,
                                             features["source_ids"])
    
    caption_embedded = tf.nn.embedding_lookup(self.source_embedding,
                                             features["caption_ids"])

    encoder_fn = self.encoder_class(self.params["encoder.params"], self.mode)
    return encoder_fn(source_embedded, caption_embedded, features, embedding_dim=self.params['embedding.dim'])

  def _preprocess(self, features, labels):
    
    features, labels=super(AbsSumPic_Image_Caption_Hie, self)._preprocess(features, labels)
    
    source_vocab_to_id, source_id_to_vocab, source_word_to_count, _ = \
      vocab.create_vocabulary_lookup_table(self.source_vocab_info.path)
    
    features["caption_ids"] = source_vocab_to_id.lookup(features["caption_tokens"])
    
    features["caption_num"] = tf.to_int32(features["caption_num"])
    tf.summary.histogram("caption_num", tf.to_float(features["caption_num"]))

    features["caption_len"] = tf.to_int32(features["caption_len"])
    tf.summary.histogram("caption_len", tf.to_float(features["caption_len"]))

    return features, labels


class AbsSumPic_Image_Caption_2_Hie(AbsSumPic_Caption_Hie):
  def __init__(self, params, mode, name="abs_sum_pic_image_caption"):
    #params=AbsSumPic.default_params()
    super(AbsSumPic_Image_Caption_2_Hie, self).__init__(params, mode, name)
    
  @staticmethod
  def default_params():
    params = BasicSeq2Seq.default_params().copy()
    params.update({
        "attention.class": "AbsSumPicBahdanau_Image_Caption",
        "attention.params": {}, # Arbitrary attention layer parameters
        "bridge.class": "seq2seq.models.bridges.AbsSumPicBridge_Image_Caption",
        "encoder.class": "seq2seq.encoders.AbsSumPicRNNEncoder_Image_Caption",
        "encoder.params": {},  # Arbitrary parameters for the encoder
        "decoder.class": "seq2seq.decoders.AbsSumPicDecoder",
        "decoder.params": {}  # Arbitrary parameters for the decoder
    })
    return params

  def _create_decoder(self, encoder_output, features, _labels):
    attention_class = locate(self.params["attention.class"]) or \
      getattr(decoders.attention, self.params["attention.class"])
    attention_layer = attention_class(
        params=self.params["attention.params"], mode=self.mode)

    reverse_scores_lengths = None
    if self.params["source.reverse"]:
      reverse_scores_lengths = features["source_len"]
      if self.use_beam_search:
        reverse_scores_lengths = tf.tile(
            input=reverse_scores_lengths,
            multiples=[self.params["inference.beam_search.beam_width"]])

    image_tokens = encoder_output.image_tokens
    image_num = encoder_output.image_num
    return self.decoder_class(
        params=self.params["decoder.params"],
        mode=self.mode,
        vocab_size=self.target_vocab_info.total_size,
        attention_values=(encoder_output.attention_values, image_tokens),
        attention_values_length=(encoder_output.attention_values_length, image_num),
        attention_keys=(encoder_output.attention_values, image_tokens),
        attention_fn=attention_layer,
        reverse_scores_lengths=reverse_scores_lengths)

  def encode(self, features, labels):
    source_embedded = tf.nn.embedding_lookup(self.source_embedding,
                                             features["source_ids"])
    
    caption_embedded = tf.nn.embedding_lookup(self.source_embedding,
                                             features["caption_ids"])

    encoder_fn = self.encoder_class(self.params["encoder.params"], self.mode)
    return encoder_fn(source_embedded, caption_embedded, features, embedding_dim=self.params['embedding.dim'])

  def _preprocess(self, features, labels):
    
    features, labels=super(AbsSumPic_Image_Caption_2_Hie, self)._preprocess(features, labels)
    
    source_vocab_to_id, source_id_to_vocab, source_word_to_count, _ = \
      vocab.create_vocabulary_lookup_table(self.source_vocab_info.path)
    
    features["caption_ids"] = source_vocab_to_id.lookup(features["caption_tokens"])
    
    features["caption_num"] = tf.to_int32(features["caption_num"])
    tf.summary.histogram("caption_num", tf.to_float(features["caption_num"]))

    features["caption_len"] = tf.to_int32(features["caption_len"])
    tf.summary.histogram("caption_len", tf.to_float(features["caption_len"]))

    return features, labels


