
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from pydoc import locate

import tensorflow as tf

from seq2seq import decoders
from seq2seq.models.basic_seq2seq import BasicSeq2Seq
from seq2seq import graph_utils
from seq2seq.data import vocab
from seq2seq.models import bridges

from seq2seq import losses as seq2seq_losses
from seq2seq.contrib.seq2seq import helper as tf_decode_helper
from seq2seq.models.model_base import ModelBase, _flatten_dict
from seq2seq.contrib.seq2seq.decoder import _transpose_batch_time
import collections

class ExtSumPic(BasicSeq2Seq):

  def __init__(self, params, mode, name="abs_sum_pic"):
    #params=AbsSumPic.default_params()
    super(ExtSumPic, self).__init__(params, mode, name)

  @staticmethod
  def default_params():
    params = BasicSeq2Seq.default_params().copy()
    params.update({
        "attention.class": "AttentionLayerAbsSumPicBahdanau",
        "attention.params": {}, # Arbitrary attention layer parameters
        "bridge.class": "seq2seq.models.bridges.AbsSumPicBridge",
        "encoder.class": "seq2seq.encoders.AbsSumPicRNNEncoder",
        "encoder.params": {},  # Arbitrary parameters for the encoder
        "decoder.class": "seq2seq.decoders.AbsSumPicDecoder",
        "decoder.params": {}  # Arbitrary parameters for the decoder
    })
    return params
    
  def _preprocess(self, features, labels):
    source_vocab_to_id, source_id_to_vocab, source_word_to_count, _ = \
      vocab.create_vocabulary_lookup_table(self.source_vocab_info.path)

    target_vocab_to_id, target_id_to_vocab, target_word_to_count, _ = \
      vocab.create_vocabulary_lookup_table(self.target_vocab_info.path)

    graph_utils.add_dict_to_collection({
        "source_vocab_to_id": source_vocab_to_id,
        "source_id_to_vocab": source_id_to_vocab,
        "source_word_to_count": source_word_to_count,
        "target_vocab_to_id": target_vocab_to_id,
        "target_id_to_vocab": target_id_to_vocab,
        "target_word_to_count": target_word_to_count
    }, "vocab_tables")

    '''if self.params["source.max_seq_len"] is not None:
      features["source_tokens"] = features["source_tokens"][:, :self.params[
          "source.max_seq_len"]]
      features["source_len"] = tf.minimum(features["source_len"],
                                          self.params["source.max_seq_len"])'''

    features["source_ids"] = source_vocab_to_id.lookup(features["source_tokens"])

    '''if self.params["source.reverse"] is True:
      features["source_ids"] = tf.reverse_sequence(
          input=features["source_ids"],
          seq_lengths=features["source_len"],
          seq_dim=1,
          batch_dim=0,
          name=None)'''

    features["source_doc_length"] = tf.to_int32(features["source_doc_length"])
    tf.summary.histogram("source_doc_length", tf.to_float(features["source_doc_length"]))
    
    features["source_sents_length"] = tf.to_int32(features["source_sents_length"])
    tf.summary.histogram("source_sents_length", tf.to_float(features["source_sents_length"]))

    if labels is None:
      return features, None

    labels = labels.copy()

    if self.params["target.max_seq_len"] is not None:
      labels["target_tokens"] = labels["target_tokens"][:, :self.params["target.max_seq_len"]]
      labels["target_len"] = tf.minimum(labels["target_len"],self.params["target.max_seq_len"])

    labels["target_ids"] = target_vocab_to_id.lookup(labels["target_tokens"])

    labels["target_len"] = tf.to_int32(labels["target_len"])
    tf.summary.histogram("target_len", tf.to_float(labels["target_len"]))

    num_tokens = tf.reduce_sum(labels["target_len"])
    num_tokens += tf.reduce_sum(features["source_sents_length"])
    token_counter_var = tf.Variable(0, "tokens_counter")
    total_tokens = tf.assign_add(token_counter_var, num_tokens)
    tf.summary.scalar("num_tokens", total_tokens)

    with tf.control_dependencies([total_tokens]):
      features["source_tokens"] = tf.identity(features["source_tokens"])

    graph_utils.add_dict_to_collection(features, "features")
    if labels:
      graph_utils.add_dict_to_collection(labels, "labels")

    return features, labels

  def encode(self, features, labels):
    source_embedded = tf.nn.embedding_lookup(self.source_embedding,
                                             features["source_ids"])

    encoder_fn = self.encoder_class(self.params["encoder.params"], self.mode)
    return encoder_fn(source_embedded,features)

  def _create_decoder(self, encoder_output, features, _labels):
    attention_class = locate(self.params["attention.class"]) or \
      getattr(decoders.attention, self.params["attention.class"])
    attention_layer = attention_class(
        params=self.params["attention.params"], mode=self.mode)

    reverse_scores_lengths = None
    if self.params["source.reverse"]:
      reverse_scores_lengths = features["source_len"]
      if self.use_beam_search:
        reverse_scores_lengths = tf.tile(
            input=reverse_scores_lengths,
            multiples=[self.params["inference.beam_search.beam_width"]])

    return self.decoder_class(
        params=self.params["decoder.params"],
        mode=self.mode,
        vocab_size=self.target_vocab_info.total_size,
        sents=encoder_output.attention_values,
        docs=encoder_output.final_state,
        images=encoder_output.image_tokens,
        doc_len=encoder_output.attention_values_length, 
        image_len=encoder_output.image_len, 
        attention_fn=attention_layer, 
        reverse_scores_lengths=reverse_scores_lengths)
    
  def _decode_train(self, decoder, _encoder_output, _features, labels):
    target_ids = labels["target_ids"]
    helper_train = tf_decode_helper.TrainingHelper(
        targets=target_ids,
        sents=_encoder_output.outputs,
        sequence_length=labels["target_len"])
    
    return decoder(helper_train)

  def _decode_infer(self, decoder, _encoder_output, features, labels):
    batch_size = self.batch_size(features, labels)
    if self.use_beam_search:
      batch_size = self.params["inference.beam_search.beam_width"]

    target_start_id = self.target_vocab_info.special_vocab.SEQUENCE_START
    helper_infer = tf_decode_helper.GreedyEmbeddingHelper(
        embedding=self.target_embedding,
        start_tokens=tf.fill([batch_size], target_start_id),
        end_token=self.target_vocab_info.special_vocab.SEQUENCE_END)

    return decoder(helper_infer)

  def decode(self, encoder_output, features, labels):
    decoder = self._create_decoder(encoder_output, features, labels)
    
    if self.use_beam_search:
      decoder = self._get_beam_search_decoder(decoder)
    
    if self.mode == tf.contrib.learn.ModeKeys.INFER:
      return self._decode_infer(decoder, encoder_output, features, labels)
    else:
      return self._decode_train(decoder, encoder_output, features, labels)

  def compute_loss(self, decoder_output, _features, labels):
    
    losses = seq2seq_losses.sigmoid_cross_entropy_sequence_loss(
        logits=decoder_output.logits[:, :, :],
        targets=tf.transpose(labels["target_ids"][:, :], [1, 0]),
        sequence_length=labels["target_len"])

    loss = tf.reduce_sum(losses) / tf.to_float(
        tf.reduce_sum(labels["target_len"]))

    return losses, loss

  def _create_predictions(self, decoder_output, features, labels, losses=None):

    predictions = {}

    predictions.update(_flatten_dict({"features": features}))
    if labels is not None:
      predictions.update(_flatten_dict({"labels": labels}))

    if losses is not None:
      predictions["losses"] = _transpose_batch_time(losses)

    output_dict = collections.OrderedDict(
        zip(decoder_output._fields, decoder_output))
    decoder_output_flat = _flatten_dict(output_dict)
    decoder_output_flat = {
        k: _transpose_batch_time(v)
        for k, v in decoder_output_flat.items()
    }
    predictions.update(decoder_output_flat)
    
    logits=tf.transpose(decoder_output.logits, [1, 0])
    predictions["sent_in_summary"]=tf.sigmoid(logits)

    return predictions

  def _build(self, features, labels, params):
    features, labels = self._preprocess(features, labels)

    encoder_output = self.encode(features, labels)

    decoder_output, _, = self.decode(encoder_output, features, labels)
    
    if self.mode == tf.contrib.learn.ModeKeys.INFER:
      predictions = self._create_predictions(
          decoder_output=decoder_output, features=features, labels=labels)
      loss = None
      train_op = None
    else:
      losses, loss = self.compute_loss(decoder_output, features, labels)

      train_op = None
      if self.mode == tf.contrib.learn.ModeKeys.TRAIN:
        train_op = self._build_train_op(loss)

      predictions = self._create_predictions(
          decoder_output=decoder_output,
          features=features,
          labels=labels,
          losses=losses)

    graph_utils.add_dict_to_collection(predictions, "predictions")

    return predictions, loss, train_op





