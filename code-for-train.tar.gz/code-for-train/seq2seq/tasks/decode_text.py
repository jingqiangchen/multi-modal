
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import functools
from pydoc import locate

import numpy as np

import tensorflow as tf
from tensorflow import gfile

from seq2seq.tasks.inference_task import InferenceTask, unbatch_dict
import seq2seq.data.vocab as vocab
import common

import rouge.Rouge

rouge=rouge.Rouge()

def _get_prediction_length(predictions_dict):
  """Returns the length of the prediction based on the index
  of the first SEQUENCE_END token.
  """
  tokens_iter = enumerate(predictions_dict["predicted_tokens"])
  return next(((i + 1) for i, _ in tokens_iter if _ == "SEQUENCE_END"),
              len(predictions_dict["predicted_tokens"]))


def _get_unk_mapping(filename):
  """Reads a file that specifies a mapping from source to target tokens.
  The file must contain lines of the form <source>\t<target>"

  Args:
    filename: path to the mapping file

  Returns:
    A dictionary that maps from source -> target tokens.
  """
  with gfile.GFile(filename, "r") as mapping_file:
    lines = mapping_file.readlines()
    mapping = dict([_.split("\t")[0:2] for _ in lines])
    mapping = {k.strip(): v.strip() for k, v in mapping.items()}
  return mapping


def _unk_replace(source_tokens,
                 caption_tokens,
                 predicted_tokens,
                 attention_index,
                 text_scores,
                 img_scores,
                 caption_scores,
                 has_words,
                 mapping=None):

  result = []
  for i in range(predicted_tokens):
      token=predicted_tokens[i]
      if token == "DOC_NOT_END":
          text_score=text_scores[i]
          img_score=img_scores[i]
          caption_score=caption_scores[i]
          att_index=attention_index[i]
          text_scores_shape=np.shape(text_scores)
          img_scores_shape=np.shape(img_scores)
          
          if att_index<text_scores_shape[0]:
              att_sent=source_tokens[att_index]
              img_scores[att_index]=-1
          else:
              att_index=(att_index-text_scores_shape[0]) % img_scores_shape[0]
              att_sent=caption_tokens[att_index]
              img_scores[att_index]=-1
              caption_scores[att_index]=-1
          
          new_token_index=0
          
      elif token == "UNK":
          while not has_words.has_key(att_sent[new_token_index]) and \
                        att_sent[new_token_index] not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_NOT_END", "DOC_END"]:
              new_token_index+=1
              if new_token_index>=np.shape(att_sent)[0]:
                  scores=np.concatenate([text_score,img_score,caption_score],0)
                  att_index = np.argmax(scores)
                  if att_index<text_scores_shape[0]:
                      att_sent=source_tokens[att_index]
                      img_scores[att_index]=-1
                  else:
                      att_index=(att_index-text_scores_shape[0]) % img_scores_shape[0]
                      att_sent=caption_tokens[att_index]
                      img_scores[att_index]=-1
                      caption_scores[att_index]=-1
                  new_token_index=0
          new_token=att_sent[new_token_index]
          result.append(new_token)
      else:
          result.append(token)
          
  return np.array(result)
  
  
def get_vocab():
    has_words={}
    with gfile.GFile(common.path_vocab) as file:
        for line in file:
            line=line.strip("\n")
            items=line.split("\t")
            has_words[items[0]]=True
    return has_words


class DecodeText(InferenceTask):
  """Defines inference for tasks where both the input and output sequences
  are plain text.

  Params:
    delimiter: Character by which tokens are delimited. Defaults to space.
    unk_replace: If true, enable unknown token replacement based on attention
      scores.
    unk_mapping: If `unk_replace` is true, this can be the path to a file
      defining a dictionary to improve UNK token replacement. Refer to the
      documentation for more details.
    dump_attention_dir: Save attention scores and plots to this directory.
    dump_attention_no_plot: If true, only save attention scores, not
      attention plots.
    dump_beams: Write beam search debugging information to this file.
  """

  def __init__(self, params):
    super(DecodeText, self).__init__(params)
    self._unk_mapping = None
    self._unk_replace_fn = None

    if self.params["unk_mapping"] is not None:
      self._unk_mapping = _get_unk_mapping(self.params["unk_mapping"])
    if self.params["unk_replace"]:
      self._unk_replace_fn = functools.partial(
          _unk_replace, mapping=self._unk_mapping)

    self._postproc_fn = None
    if self.params["postproc_fn"]:
      self._postproc_fn = locate(self.params["postproc_fn"])
      if self._postproc_fn is None:
        raise ValueError("postproc_fn not found: {}".format(
            self.params["postproc_fn"]))
    
    self.has_words=get_vocab()

  @staticmethod
  def default_params():
    params = {}
    params.update({
        "delimiter": " ",
        "postproc_fn": "",
        "unk_replace": False,
        "unk_mapping": None,
    })
    return params

  def before_run(self, _run_context):
    fetches = {}
    fetches["predicted_tokens"] = self._predictions["predicted_tokens"]
    fetches["attention_index"] = self._predictions["attention_index"]
    fetches["features.source_doc_length"] = self._predictions["features.source_doc_length"]
    fetches["features.source_sents_length"] = self._predictions["features.source_sents_length"]
    fetches["features.caption_tokens"] = self._predictions["features.caption_tokens"]
    fetches["features.caption_num"] = self._predictions["features.caption_num"]
    fetches["features.source_tokens"] = self._predictions["features.source_tokens"]
    fetches["labels.target_tokens"] = self._predictions["labels.target_tokens"]

    if "text_scores" in self._predictions:
      fetches["text_scores"] = self._predictions["text_scores"]
    
    if "img_scores" in self._predictions:
      fetches["img_scores"] = self._predictions["img_scores"]
    
    if "caption_scores" in self._predictions:
      fetches["caption_scores"] = self._predictions["caption_scores"]
    
    return tf.train.SessionRunArgs(fetches)

  def after_run(self, _run_context, run_values):
    fetches_batch = run_values.results
    for fetches in unbatch_dict(fetches_batch):

      fetches["predicted_tokens"] = np.char.decode(
          fetches["predicted_tokens"].astype("S"), "utf-8")
      predicted_tokens = fetches["predicted_tokens"]

      # If we're using beam search we take the first beam
      if np.ndim(predicted_tokens) > 1:
        predicted_tokens = predicted_tokens[:, 0]
        
      attention_index = fetches["attention_index"]
      
      fetches["features.caption_tokens"] = np.char.decode(
          fetches["features.caption_tokens"].astype("S"), "utf-8")
      caption_tokens = fetches["features.caption_tokens"]
      caption_num = fetches["features.caption_num"]

      fetches["features.source_tokens"] = np.char.decode(
          fetches["features.source_tokens"].astype("S"), "utf-8")
      source_tokens = fetches["features.source_tokens"]
      source_doc_length = fetches["features.source_doc_length"]
      source_sents_length = fetches["features.source_sents_length"]
      target_tokens = fetches["labels.target_tokens"]

      if self._unk_replace_fn is not None:
        text_scores = fetches["text_scores"]
        img_scores = fetches["img_scores"]
        caption_scores = fetches["caption_scores"]
        predicted_tokens = self._unk_replace_fn(
            source_tokens=source_tokens,
            caption_tokens=caption_tokens,
            predicted_tokens=predicted_tokens,
            attention_index=attention_index,
            text_score=text_scores,
            img_scores=img_scores,
            caption_scores=caption_scores,
            has_words=self.has_words)

      #sent = self.params["delimiter"].join(predicted_tokens).split("SEQUENCE_END")[0]
      summary=[]
      index=-1
      for word in predicted_tokens:
          if word=="DOC_NOT_END":
              summary.append([])
              index+=1
          elif word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END"]:
              summary[index].append(word)
              
      target=[]
      index=-1
      for word in target_tokens:
          if word=="DOC_NOT_END":
              target.append([])
              index+=1
          elif word not in ["SEQUENCE_START", "SEQUENCE_END", "DOC_END"]:
              target[index].append(word)
      #sent = sent + u'\n------------------------------------------------------\n' + (' '.join(source_tokens)) + u'\n'

      # Apply postproc
      #if self._postproc_fn:
      #  sent = self._postproc_fn(sent)

      summary=[' '.join(sent) for sent in summary].join('\n')
      target=[' '.join(sent) for sent in target].join('\n')
      print(summary)
      print('-------------------------------------')
      print(target)
      print('-------------------------------------')
      scores = rouge.get_scores([summary], [target])
      print(scores[0]['rouge-1']['f'])
      print(scores[0]['rouge-2']['f'])
      print('-------------------------------------')
      for s in source_tokens:
          print(' '.join(s))
      print()
