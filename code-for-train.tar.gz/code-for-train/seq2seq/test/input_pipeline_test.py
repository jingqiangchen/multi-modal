# -*- coding: utf-8 -*-
# Copyright 2017 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Unit tests for input-related operations.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import tensorflow as tf
import numpy as np
import yaml

from seq2seq.data import input_pipeline
from seq2seq.test import utils as test_utils
from seq2seq.training.utils import create_input_fn
from tensorflow.python.util import nest

from tensorflow.python.ops.rnn_cell_impl import GRUCell
from tensorflow.python.ops.rnn import dynamic_rnn
from tensorflow.python.ops.rnn import bidirectional_dynamic_rnn
from tensorflow.contrib.rnn.python.ops.rnn import stack_bidirectional_dynamic_rnn
from tensorflow.python.ops import array_ops
from tensorflow.python.ops import rnn

from seq2seq.data import vocab

class TestInputPipelineDef(tf.test.TestCase):
  """Tests InputPipeline string definitions"""

  def test_without_extra_args(self):
    pipeline_def = yaml.load("""
      class: ParallelTextInputPipeline
      params:
        source_files: ["file1"]
        target_files: ["file2"]
        num_epochs: 1
        shuffle: True
    """)
    pipeline = input_pipeline.make_input_pipeline_from_def(
        pipeline_def, tf.contrib.learn.ModeKeys.TRAIN)
    self.assertIsInstance(pipeline, input_pipeline.ParallelTextInputPipeline)
    #pylint: disable=W0212
    self.assertEqual(pipeline.params["source_files"], ["file1"])
    self.assertEqual(pipeline.params["target_files"], ["file2"])
    self.assertEqual(pipeline.params["num_epochs"], 1)
    self.assertEqual(pipeline.params["shuffle"], True)

  def test_with_extra_args(self):
    pipeline_def = yaml.load("""
      class: ParallelTextInputPipeline
      params:
        source_files: ["file1"]
        target_files: ["file2"]
        num_epochs: 1
        shuffle: True
    """)
    pipeline = input_pipeline.make_input_pipeline_from_def(
        def_dict=pipeline_def,
        mode=tf.contrib.learn.ModeKeys.TRAIN,
        num_epochs=5,
        shuffle=False)
    self.assertIsInstance(pipeline, input_pipeline.ParallelTextInputPipeline)
    #pylint: disable=W0212
    self.assertEqual(pipeline.params["source_files"], ["file1"])
    self.assertEqual(pipeline.params["target_files"], ["file2"])
    self.assertEqual(pipeline.params["num_epochs"], 5)
    self.assertEqual(pipeline.params["shuffle"], False)


class TFRecordsInputPipelineTest():
  """
  Tests Data Provider operations.
  """

  def setUp(self):
    #super(TFRecordsInputPipelineTest, self).setUp()
    tf.logging.set_verbosity(tf.logging.INFO)

  def test_pipeline(self):
    tfrecords_file = test_utils.create_temp_tfrecords(
        sources=["Hello World . 笑 fg 5 5 5", "1 2 3", "4 5 6 7"], targets=["Bye 泣 g","1 1 1","2 2 2 2"])
    tfrecords_file_2 = test_utils.create_temp_tfrecords(
        sources=["8 8 8", "9 9 9"], targets=["0 0 0","9 9 9"])

    pipeline = input_pipeline.TFRecordInputPipeline(
        params={
            "files": [tfrecords_file.name,tfrecords_file_2.name],
            "source_field": "source",
            "target_field": "target",
            "num_epochs": 5,
            "shuffle": False
        },
        mode=tf.contrib.learn.ModeKeys.TRAIN)
    features_batch, labels_batch=create_input_fn(pipeline=pipeline,batch_size=1,scope="train_input_fn")()
    #data_provider = pipeline.make_data_provider()
    #features_and_labels = pipeline.read_from_data_provider(data_provider)
    '''data_provider = pipeline.make_data_provider()
    coord = tf.train.Coordinator()
    features = pipeline.read_from_data_provider(data_provider)'''
    '''with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        sess.run(tf.local_variables_initializer())
        threads=tf.train.start_queue_runners(sess=sess,coord=coord)
        try:
            while not coord.should_stop():
                # Run training steps or whatever
                res = sess.run(features)
                print(res["source_len"])
                print(res["target_len"])
                print(res["source_tokens"].astype("S"))
                print(res["target_tokens"].astype("S"))
        except tf.errors.OutOfRangeError:
            print('tyty')
        finally:
            # When done, ask the threads to stop.
            coord.request_stop()
        
        # Wait for threads to finish.
        coord.join(threads)
        sess.close()'''
    
    with tf.Session() as sess:
      sess.run(tf.global_variables_initializer())
      sess.run(tf.local_variables_initializer())
      with tf.contrib.slim.queues.QueueRunners(sess):
        res = sess.run(features_batch)
        print(res)
    '''
    {u'target_tokens': array(['SEQUENCE_START', 'Bye', '\xe6\xb3\xa3', 'g', 'SEQUENCE_END'], dtype=object), u'source_tokens': array(['Hello', 'World', '.', '\xe7\xac\x91', 'fg', '5', '5', '5',
       'SEQUENCE_END'], dtype=object), 'record_key': '/tmp/tmppHk_kY:0', u'source_len': 9, u'target_len': 5}
    '''
    '''self.assertEqual(res["source_len"], 5)
    self.assertEqual(res["target_len"], 4)
    np.testing.assert_array_equal(
        np.char.decode(res["source_tokens"].astype("S"), "utf-8"),
        ["Hello", "World", ".", "笑", "SEQUENCE_END"])
    np.testing.assert_array_equal(
        np.char.decode(res["target_tokens"].astype("S"), "utf-8"),
        ["SEQUENCE_START", "Bye", "泣", "SEQUENCE_END"])'''


class ParallelTextInputPipelineTest():
  """
  Tests Data Provider operations.
  """

  def setUp(self):
    #super(ParallelTextInputPipelineTest, self).setUp()
    tf.logging.set_verbosity(tf.logging.INFO)
    
  def preprocess(self,features):
      self.source_vocab_info = vocab.get_vocab_info('/home/test/sum-pic/dailymail/test/vocab')
      source_vocab_to_id, source_id_to_vocab, source_word_to_count, _ = \
        vocab.create_vocabulary_lookup_table(self.source_vocab_info.path)
      features["source_ids"] = source_vocab_to_id.lookup(features["source_tokens"])
      
      embeddings=tf.get_variable(
        name="W",
        shape=[self.source_vocab_info.total_size, 100],
        initializer=tf.random_uniform_initializer(-0.5, 0.5))
      
      features["source_embeded"] = tf.nn.embedding_lookup(embeddings,features["source_ids"])
      
      return features
      
  def test_pipeline(self):
    from tensorflow.contrib.slim.python.slim.data import parallel_reader
    file_source, file_target = test_utils.create_temp_parallel_data(
        sources=["Hello World . 笑"], targets=["Bye 泣"])
    
    ls1=['/home/cjq/sum-pic/dailymail/test/story-texts/00a1c2c7394101bbcefe155bb793af06224f6559',
         '/home/cjq/sum-pic/dailymail/test/story-texts/00a1f3afd12e5a44025c1473f90de3d19ad2cfeb',
         ['/home/cjq/sum-pic/dailymail/test/story-texts/00a2b6bfa5d59cdc0a4eff8e87131e68777cf899',
          '/home/cjq/sum-pic/dailymail/test/story-texts/00a3d8763be4e836a9db092f7f7a9470bd5bf5d5',
          ['/home/cjq/sum-pic/dailymail/test/story-texts/00a3fbead23d83544eae11a0795717c4eb5d1921',
           '/home/cjq/sum-pic/dailymail/test/story-texts/00a4e038101945dd07baee4a020ae85adb43a54d']]]
    ls2=['/home/cjq/sum-pic/dailymail/test/image-features/00a1c2c7394101bbcefe155bb793af06224f6559',
         '/home/cjq/sum-pic/dailymail/test/image-features/00a1f3afd12e5a44025c1473f90de3d19ad2cfeb',
         ['/home/cjq/sum-pic/dailymail/test/image-features/00a2b6bfa5d59cdc0a4eff8e87131e68777cf899',
          '/home/cjq/sum-pic/dailymail/test/image-features/00a3d8763be4e836a9db092f7f7a9470bd5bf5d5',
          ['/home/cjq/sum-pic/dailymail/test/image-features/00a3fbead23d83544eae11a0795717c4eb5d1921',
           '/home/cjq/sum-pic/dailymail/test/image-features/00a4e038101945dd07baee4a020ae85adb43a54d']]]
    ls1=parallel_reader.get_data_files(ls1)
    ls2=parallel_reader.get_data_files(ls2)

    pipeline = input_pipeline.ParallelTextInputPipeline(
        params={
            "source_files": [ls1],
            "image_files": [ls2],
            "target_files": [ls1],
            "num_epochs": 5,
            "shuffle": False
        },
        mode=tf.contrib.learn.ModeKeys.TRAIN)
    features, labels=create_input_fn(pipeline=pipeline,batch_size=3,scope="train_input_fn")()
    features=self.preprocess(features)
    shape=tf.shape(features["source_embeded"])
    features["source_embeded"]=tf.reshape(features["source_embeded"],[-1,shape[2],100])
    cell=GRUCell(30)
    sents_length=tf.reshape(features['source_sents_length'],[-1])
    outputs,fw,bw=stack_bidirectional_dynamic_rnn([cell],[cell],features['source_embeded'],sequence_length=sents_length,dtype=tf.float32,scope='sent')
    outputs=tf.transpose(outputs, [1,0,2])
    
    doc_cell=GRUCell(50)
    doc_input=tf.reshape(fw,[shape[0],-1,30])
    doc_outputs,doc_fw,doc_bw=stack_bidirectional_dynamic_rnn([doc_cell],[doc_cell],doc_input,sequence_length=features['source_doc_length'],dtype=tf.float32,scope='doc')
    
    #flat_input = nest.flatten(features['source_embeded'])
    #flat_input = nest.flatten(features['source_tokens'])
    #batch_size = rnn._best_effort_input_batch_size(flat_input)
    with tf.Session() as sess:
      sess.run(tf.global_variables_initializer())
      sess.run(tf.local_variables_initializer())
      sess.run(tf.initialize_all_tables())
      with tf.contrib.slim.queues.QueueRunners(sess):
        #print(sess.run(outputs[sents_length]))#36,88,30
        print(sess.run([doc_fw]))
        #print(sess.run(tf.shape(features['source_sents_length'])))
        #print(sess.run(outputs))
        #print(sess.run(sents_length))
        #print(sess.run(features['source_sents_length']))

    '''self.assertEqual(res["source_len"], 5)
    self.assertEqual(res["target_len"], 4)
    np.testing.assert_array_equal(
        np.char.decode(res["source_tokens"].astype("S"), "utf-8"),
        ["Hello", "World", ".", "笑", "SEQUENCE_END"])
    np.testing.assert_array_equal(
        np.char.decode(res["target_tokens"].astype("S"), "utf-8"),
        ["SEQUENCE_START", "Bye", "泣", "SEQUENCE_END"])'''
          
  def test_pipeline_bak(self):
    from tensorflow.contrib.slim.python.slim.data import parallel_reader
    file_source, file_target = test_utils.create_temp_parallel_data(
        sources=["Hello World . 笑"], targets=["Bye 泣"])
    
    '''ls1=['/home/cjq/sum-pic/dailymail/test/story-texts/00a1c2c7394101bbcefe155bb793af06224f6559',
         '/home/cjq/sum-pic/dailymail/test/story-texts/00a1f3afd12e5a44025c1473f90de3d19ad2cfeb',
         ['/home/cjq/sum-pic/dailymail/test/story-texts/00a2b6bfa5d59cdc0a4eff8e87131e68777cf899',
          '/home/cjq/sum-pic/dailymail/test/story-texts/00a3d8763be4e836a9db092f7f7a9470bd5bf5d5',
          ['/home/cjq/sum-pic/dailymail/test/story-texts/00a3fbead23d83544eae11a0795717c4eb5d1921',
           '/home/cjq/sum-pic/dailymail/test/story-texts/00a4e038101945dd07baee4a020ae85adb43a54d']]]
    ls2=['/home/cjq/sum-pic/dailymail/test/image-features/00a1c2c7394101bbcefe155bb793af06224f6559',
         '/home/cjq/sum-pic/dailymail/test/image-features/00a1f3afd12e5a44025c1473f90de3d19ad2cfeb',
         ['/home/cjq/sum-pic/dailymail/test/image-features/00a2b6bfa5d59cdc0a4eff8e87131e68777cf899',
          '/home/cjq/sum-pic/dailymail/test/image-features/00a3d8763be4e836a9db092f7f7a9470bd5bf5d5',
          ['/home/cjq/sum-pic/dailymail/test/image-features/00a3fbead23d83544eae11a0795717c4eb5d1921',
           '/home/cjq/sum-pic/dailymail/test/image-features/00a4e038101945dd07baee4a020ae85adb43a54d']]]'''
      
    '''ls1=['/home/test/sum-pic/dailymail/story-texts/*']
    ls2=['/home/test/sum-pic/dailymail/image-features/*']
    ls3=['/home/test/sum-pic/dailymail/story-summaries/*']'''
      
    ls1=['/home/test/sum-pic/dailymail/story-texts/0a5a1a17961b552e31eb3baddd0c0db0d412a009']
    ls2=['/home/test/sum-pic/dailymail/image-features/0a5a1a17961b552e31eb3baddd0c0db0d412a009']
    ls3=['/home/test/sum-pic/dailymail/story-summaries/0a5a1a17961b552e31eb3baddd0c0db0d412a009']#5358179dd389f863b60e7285acc4dbf60b088450
    ls1=parallel_reader.get_data_files(ls1)
    ls2=parallel_reader.get_data_files(ls2)
    ls3=parallel_reader.get_data_files(ls3)

    pipeline = input_pipeline.ParallelTextInputPipeline(
        params={
            "source_files": [ls1],
            "image_files": [ls2],
            "target_files": [ls3],
            "num_epochs": 5,
            "shuffle": False
        },
        mode=tf.contrib.learn.ModeKeys.TRAIN)
    features, labels=create_input_fn(pipeline=pipeline,batch_size=1,scope="train_input_fn")()
    features=self.preprocess(features)
    image_tokens=features['image_tokens']
    image_len=features['image_len']
    #img=tf.divide(tf.reduce_sum(image_tokens,1),tf.expand_dims(image_len,1))

    with tf.Session() as sess:
      sess.run(tf.global_variables_initializer())
      sess.run(tf.local_variables_initializer())
      sess.run(tf.initialize_all_tables())
      with tf.contrib.slim.queues.QueueRunners(sess):
        print(sess.run([tf.shape(image_tokens)]))


if __name__ == "__main__":
  #tf.test.main()
  t=ParallelTextInputPipelineTest()
  t.setUp()
  t.test_pipeline_bak()







